# HELPBOT — ko'p kompaniyali logistika platformasi

Telegram boti + web dashboard + REST API. DSL HELP Blueprint 3.0 asosida noldan yozilgan.

## 1. Nima tayyor (kod yozilgan va avtomatik sinalgan)

| Qism | Holat |
|---|---|
| Owner tasdig'i, 13 rol / 194 ruxsat, deny-by-default, kompaniyalar ajratilishi, audit, approval | ✅ |
| Telegram guruh ↔ kompaniya (`/linkgroup`, `/updadmin`), ticketlar, driver/truck, uch til | ✅ |
| Yuklar (load): yaratish, driver biriktirish, status oqimi, BOL/POD fayl, narx faqat accounting'ga | ✅ |
| PTI: so'rov → driver rasmlari → tasdiq / qayta | ✅ |
| ELD nosozlik: ticket + 8 kunlik hisoblagich + eslatma | ✅ |
| Hujjat metadata (egalik tekshiruvi, maxfiy turlar) | ✅ (fayl baytlari Telegram'da) |
| REST API + web dashboard (uz/en/ru) | ✅ |
| Web login: Telegram bir martalik kod + 2FA (TOTP), server sessiyalar | ✅ |
| Billing: reja limitlari (driver/truck/user), to'lanmagan = faqat o'qish | ✅ (to'lov provayderi yo'q) |
| AI Manager: 3 agent (triage, kunlik xulosa, risk nazorati), faqat taklif, odam qo'llaydi | ✅ (13 tadan 3 tasi) |
| Zaxira/tiklash, migratsiyalar, CI, Render/Docker fayllari, hujjatlar | ✅ |

**Sinovlar:** 101 ta avtomatik test (izolyatsiya, RBAC, approval, API, login/2FA, Telegram oqimlari, tillar, migratsiya, zaxira). Ular SQLite'da ham, haqiqiy PostgreSQL'da ham o'tgan (`python tests/run_on_postgres.py`).

**Hali yo'q / sinalmagan:** [docs/SECURITY.md](docs/SECURITY.md) ning "Qilinmagan" bo'limi. Eng muhimlari: haqiqiy Telegram'da va haqiqiy brauzerda sinov, to'lov provayderi, AI'ning 10 ta qo'shimcha agenti, foydalanuvchi qoidalari bilan Automation Engine, PostgreSQL RLS, private fayl saqlash (S3), tashqi pentest.

## 2. Tez ishga tushirish (Windows)
1. Python 3.11/3.12 o'rnating ("Add Python to PATH").
2. PowerShell: `python -m venv venv` → `venv\Scripts\activate` → `pip install -r requirements.txt` → `copy .env.example .env`
3. `.env` ni to'ldiring: `BOT_TOKEN`, `OWNER_TELEGRAM_ID`, `SECRET_KEY` (`python -c "import secrets;print(secrets.token_urlsafe(48))"`).
4. Bot: `python main.py`. Web: `python web.py` → http://127.0.0.1:8080 (alohida oynada).

## 3. BotFather
Bot nomi HELPBOT. `Allow Groups` = ON. Group Privacy = ON qoldirsangiz bo'ladi: matn kiritiladigan amallar shaxsiy chatda. Guruhda buyruqni "/" menyusidan tanlang (`/buyruq@bot`).

## 4. Birinchi foydalanish
1. Owner botga `/start` (til) → `/newcompany Acme` → guruhga botni qo'shib `/linkgroup Acme operations`.
2. Xodim `/start` → "Ruxsat so'rash" → Owner tugma bilan tasdiqlaydi → kompaniya va rol tanlaydi.
3. Owner `/2fa` bilan authenticator'ni ulaydi → web'da: Telegram ID → "Kodni yuborish" → kod + 2FA.
4. Reja: `/billing` (admin), `/plan growth 30` (Owner). AI: `/ai on` (manager), `/airun`, `/ai`.

## 5. Production
1. PostgreSQL (Supabase/Neon). `DATABASE_URL`, `ENVIRONMENT=production`, `TRUST_PROXY=true`, `AUTO_MIGRATE=false`.
2. `render.yaml` (web + bot worker) yoki Dockerfile. Migratsiya bir marta: `python manage.py migrate`.
3. **Avval staging**: [docs/STAGING.md](docs/STAGING.md) ro'yxati. Keyin production.
4. Zaxira kuniga bir marta: `python manage.py backup` ([docs/OPERATIONS.md](docs/OPERATIONS.md)). Tiklash mashqi oyiga bir marta.
5. Botni **bitta** nusxada ishga tushiring (polling).

## 6. Buyruqlar (qisqa)
Hamma: `/menu /help /ticket /tickets /mytickets /status /loads /pti /eld /language /profile /mycompany /2fa /weblogout /cancel`
Xodimlar (ruxsatga qarab): `/newload /load /drivers /adddriver /trucks /addtruck /approvals /overview /report /users /setrole /suspenduser /eldopen /ptistatus /ai /airun /billing /groupinfo`
Owner: `/requests /plan /grant /revoke /audit /newcompany /linkgroup /updadmin /suspendcompany`
`/help` har kim uchun faqat o'ziga mumkin bo'lganlarni ko'rsatadi.

## 7. Tuzilma
`helpbot/models.py` · `db.py` (tenant guard) · `rbac.py` · `services/` (butun biznes mantiq va ruxsat tekshiruvi; bot ham, API ham shuni chaqiradi) · `bot/` (Telegram) · `api/` (Flask + dashboard) · `i18n*.py` · `alembic/` (migratsiyalar) · `ops.py` (zaxira) · `tests/` · `docs/`

## 8. Testlar
```
pip install -r requirements-dev.txt
pytest -q                                   # SQLite
python tests/run_on_postgres.py             # xuddi shu testlar haqiqiy PostgreSQL'da + migratsiya va zaxira tekshiruvi
```
