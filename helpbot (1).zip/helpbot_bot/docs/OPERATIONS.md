# Operatsiya qo'llanmasi (HELPBOT)

## 1. Zaxira (backup)
```
python manage.py backup --keep 14        # yangi zaxira + tekshiruv + eskilarini o'chirish
python manage.py verify backups/helpbot-XXXX.dump
```
- PostgreSQL uchun mashinada `pg_dump` / `pg_restore` (PostgreSQL client tools) o'rnatilgan bo'lishi kerak.
- **Kuniga kamida bir marta** ishga tushiring (cron yoki hosting scheduler). Zaxirani **boshqa joyga** ham nusxalang (S3, boshqa server). Faqat bir serverda turgan zaxira zaxira emas.
- Supabase/Neon o'zining avtomatik backup'ini ham yuritadi: uni ham yoqing, bu ikkinchi himoya.

## 2. Tiklash mashqi (oyiga bir marta, staging'da)
1. Bot va web'ni to'xtating.
2. `python manage.py restore backups/helpbot-XXXX.dump --yes` (hozirgi ma'lumot ustidan yoziladi!).
3. `python manage.py migrate`, keyin ishga tushiring.
4. `python scripts/smoke_test.py <url>` va botda `/menu`, web'da kirish.
Mashq qilinmagan tiklash jarayoni haqiqiy avariyada ishlamasligi mumkin.

## 3. Yangi versiyani chiqarish (deploy)
1. **Staging**: alohida bot tokeni + alohida baza. Testlar: `pytest`. Keyin `scripts/smoke_test.py`.
2. Production bazasini zaxiralang: `python manage.py backup`.
3. Deploy (`preDeployCommand: python manage.py migrate` bir marta ishlaydi).
4. Smoke test + botda 2-3 buyruq. Muammo bo'lsa 5-bo'limga qarang.

## 4. Monitoring
- `/healthz` (jonli), `/readyz` (baza ulanishi bilan). UptimeRobot/Render health check shularga qarasin.
- Bot xatolari Owner'ga yuboriladi (faqat xato turi, shaxsiy ma'lumotsiz). Loglarda token va shaxsiy ma'lumot yo'q.
- Audit: botda `/audit`, web'da "Audit" bo'limi (Owner).

## 5. Orqaga qaytarish (rollback)
- Kod: oldingi versiyani qayta deploy qiling.
- Sxema: `alembic downgrade -1` faqat tekshirilgan migratsiya uchun. Ishonchsiz bo'lsa, zaxiradan tiklang (2-bo'lim).
- Hech qachon production bazasida zaxirasiz migratsiya sinamang.

## 6. Hodisa (incident) tartibi
1. Zararni to'xtating: kerak bo'lsa botni/web'ni o'chiring; zarar ko'rgan foydalanuvchini `suspend`, kompaniyani `/suspendcompany` bilan to'xtating.
2. Hamma web sessiyani yoping: foydalanuvchilar `/weblogout`; xodimning sessiyalarini bazadan o'chirish (`web_sessions`).
3. Sirlar sizib chiqqan bo'lsa: BOT_TOKEN (BotFather `/revoke`), SECRET_KEY, DATABASE_URL parolini almashtiring. SECRET_KEY almashsa 2FA seedlari ochilmaydi: foydalanuvchilar `/2fa` bilan qayta yoqadi.
4. Audit logni ko'rib chiqing: kim, nima, qachon.
5. Voqeani yozib qo'ying va sababini tuzating.

## 7. Masshtablash eslatmalari
- Login rate-limit xotirada (har jarayon uchun). Ko'p nusxa ishga tushirsangiz, umumiy limiter (Redis) qo'shing.
- Eslatmalar (job) botning bitta nusxasida ishlaydi. Botni bir nechta nusxada ishga tushirmang (polling ziddiyati).
