# Xavfsizlik: nima qilingan, nima qilinmagan

## Qilingan va testlangan
- Owner faqat `OWNER_TELEGRAM_ID` dan; ro'yxatni faqat Owner tasdiqlaydi.
- Deny-by-default ruxsatlar; har xizmat funksiyasida tekshiruv (UI yashirish yetarli emas).
- Kompaniyalar ajratilishi: sessiya doirasi (o'qishni filtrlaydi, yozishni tekshiradi), doirasiz = hech narsa.
- Maxfiy ticketlar (HR, accounting) guruhga mazmuni bilan chiqmaydi; AI ularni o'qimaydi.
- Muhim amallar boshqa odam tasdig'isiz bajarilmaydi; o'zini-o'zi tasdiqlash yo'q.
- Audit log faqat qo'shiladi (ORM darajasida o'zgartirish/o'chirish taqiqlangan).
- Web: Telegram bir martalik kod (5 daqiqa, 5 urinish, bir marta), 2FA (TOTP) admin rollar uchun majburiy, 2FA seedlari shifrlangan, server-tomon sessiyalar (token hash), HttpOnly+SameSite=Strict cookie, CSRF sarlavhasi + Origin tekshiruvi, rate limit, CSP (inline skript yo'q), akkaunt mavjudligi oshkor qilinmaydi.
- Web'da barcha dinamik matn `textContent` orqali (innerHTML yo'q).
- AI: default o'chiq; faqat taklif; odam o'z ruxsati bilan qo'llaydi; kritik amal AI uchun mavjud emas.
- Billing: reja limitlari; to'lanmagan kompaniya faqat o'qish rejimida.

## Qilinmagan (xavf bilan yashash yoki keyin qo'shish kerak)
- PostgreSQL RLS (qo'shimcha himoya qatlami): blueprint avval sessiya o'zgaruvchisi strategiyasini kelishishni talab qiladi.
- Hujjat fayllari Telegram `file_id` sifatida turadi (maxfiy fayl uchun alohida private storage — S3/Supabase Storage — keyingi qadam).
- To'lov provayderi (Stripe va hokazo) integratsiyasi yo'q: Owner `/plan` bilan qo'lda boshqaradi.
- Rate limiter xotirada (bitta jarayon).
- Audit logni PostgreSQL trigger bilan ham qulflash (hozir ORM darajasida) qo'shilmagan.
- Tashqi xavfsizlik auditi (pentest) o'tkazilmagan.
