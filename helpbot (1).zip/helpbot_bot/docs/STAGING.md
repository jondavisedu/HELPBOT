# Staging tekshiruv ro'yxati

Maqsad: production'dan oldin **haqiqiy Telegram'da** sinash (bu tekshiruv avtomatik testlarda yo'q).

1. Yangi bot (BotFather) va alohida baza (Supabase "helpbot-staging"). `ENVIRONMENT=staging`.
2. `python manage.py migrate`, keyin `python main.py` va `gunicorn web:app`.
3. `python scripts/smoke_test.py https://<staging-web-url>`.
4. Botda (Owner): `/start` → `/newcompany Test Co` → guruh yaratib botni qo'shing → guruhda `/linkgroup Test Co operations`.
5. Ikkinchi akkaunt: `/start` → ruxsat so'rash → Owner tasdiqlaydi → rol (dispatcher) tanlanadi.
6. Ticket: DM'da `/ticket` → guruhda post chiqdimi? Guruhdagi tugma bilan "In progress".
7. HR kategoriyasidagi ticket guruhda **mazmunsiz** chiqayaptimi?
8. Yuk: `/newload` → driver biriktirish → driver `/loads` → POD fayl → status.
9. PTI: `/pti` → driver rasm yuboradi → "Tayyor" → tekshirish.
10. ELD: driver `/eld`.
11. Driverni bo'shatish (approval): boshqa odam tasdiqlamaguncha bajarilmasligini tekshiring.
12. Web: Owner `/2fa` → authenticator → dashboard'ga kirish (Telegram kodi + 2FA).
13. `/ai on` → `/airun` → taklifni qo'llash.
14. Zaxira va tiklash mashqi (docs/OPERATIONS.md, 2-bo'lim).
Hammasi o'tgandan keyingina production.
