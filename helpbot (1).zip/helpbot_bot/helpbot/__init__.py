"""HELPBOT — multi-company logistics platform (Telegram channel). Blueprint 3.0."""
__version__ = "0.1.0"
