"""REST API + dashboard. Same services as the Telegram bot: authorization lives in the services, not here."""
import asyncio
import logging
import os
import uuid
from functools import wraps
from types import SimpleNamespace

from flask import Flask, g, jsonify, make_response, request, send_from_directory
from sqlalchemy import select, text
from werkzeug.middleware.proxy_fix import ProxyFix

from .. import __version__, audit, config, db
from ..bot import runtime
from ..i18n import t
from ..models import Company, Driver, User, WebSession
from ..rbac import PermissionDenied, build_ctx
from ..services import access, ai, approvals, billing, fleet, loads, reports, tickets, web_auth
from ..services.errors import NotFound, ServiceError
from . import ratelimit
from .tgbot import HttpBot

log = logging.getLogger("helpbot.api")
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
COOKIE = "hb_session"
CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; "
       "base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
I18N_PREFIXES = ("err", "tk", "drv", "trk", "appr", "load", "user", "company", "reg", "assign", "truck", "billing", "ai")


def iso(dt):
    return dt.isoformat() if dt else None


def create_app(sender=None, limiter=None):
    app = Flask(__name__, static_folder=None)
    if os.environ.get("TRUST_PROXY", "false").lower() == "true":
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
    app.config["MAX_CONTENT_LENGTH"] = 256 * 1024
    app.extensions["sender"] = sender or HttpBot()
    app.extensions["limiter"] = limiter or ratelimit.Limiter()
    secure_cookie = config.ENVIRONMENT == "production"

    # ------------------------------------------------------------------ helpers
    def fail(status, key, lang=None, **params):
        msg = t(lang or config.DEFAULT_LANGUAGE, key, **params) if key.split(".")[0] in I18N_PREFIXES else key
        return jsonify({"error": key, "message": msg}), status

    def deliver(ctx):
        if ctx.outbox:
            try:
                asyncio.run(runtime.deliver(SimpleNamespace(bot=app.extensions["sender"]), ctx.outbox))
            except Exception:
                log.exception("notification delivery failed")

    def client_ip():
        return request.remote_addr or "?"

    def names(s, ids):
        ids = {i for i in ids if i}
        if not ids:
            return {}
        return {u.id: u.full_name for u in s.scalars(select(User).where(User.id.in_(ids)))}

    def denied(ctx, need):
        try:
            with db.session_scope(db.NOSCOPE) as s:
                audit.record(s, ctx=ctx, action="permission_denied", object_type="api",
                             after={"need": need, "path": request.path})
        except Exception:
            log.exception("could not audit a denial")

    def api(perm=None, need_company=True):
        def deco(fn):
            @wraps(fn)
            def wrapper(*a, **kw):
                token = request.cookies.get(COOKIE)
                with db.session_scope(db.NOSCOPE) as s0:
                    found = web_auth.session_user(s0, token)
                    if found is None:
                        return fail(401, "unauthorized")
                    user, ws = found
                    ctx = build_ctx(s0, user, ws.company_id, channel="web")
                lang = ctx.lang
                if ctx.blocked and not ctx.is_owner:
                    return fail(403, "company_blocked")
                if need_company and ctx.company_id is None:
                    return fail(409, "no_company")
                if perm and not ctx.can(perm):
                    denied(ctx, perm)
                    return fail(403, "forbidden")
                try:
                    with db.session_scope(ctx.company_id or db.NOSCOPE) as s:
                        result = fn(ctx, s, *a, **kw)
                except PermissionDenied as e:
                    denied(ctx, e.code)
                    return fail(403, "forbidden")
                except NotFound as e:
                    return fail(404, e.key, lang, **e.params)
                except ServiceError as e:
                    return fail(400, e.key, lang, **e.params)
                except Exception:
                    log.exception("api error on %s", request.path)               # details stay in the server log
                    return fail(500, "server_error")
                deliver(ctx)
                return result
            return wrapper
        return deco

    def body():
        return request.get_json(silent=True) or {}

    # ------------------------------------------------------------------ request hygiene
    @app.before_request
    def hygiene():
        if request.path.startswith("/api/") and request.method not in ("GET", "HEAD", "OPTIONS"):
            if request.headers.get("X-Requested-With") != "HELPBOT":
                return fail(403, "csrf")
            if request.get_data() and not request.is_json:
                return fail(415, "json_required")
            origin = request.headers.get("Origin")
            if origin and origin.rstrip("/") not in ({request.host_url.rstrip("/")} | config.ALLOWED_ORIGINS):
                return fail(403, "bad_origin")

    @app.after_request
    def headers(resp):
        resp.headers["Content-Security-Policy"] = CSP
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        if secure_cookie:
            resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        return resp

    # ------------------------------------------------------------------ static dashboard and health
    @app.get("/")
    def index():
        return send_from_directory(STATIC, "index.html")

    @app.get("/static/<path:name>")
    def static_files(name):
        return send_from_directory(STATIC, name)

    @app.get("/healthz")
    def healthz():
        return jsonify({"ok": True, "version": __version__})

    @app.get("/readyz")
    def readyz():
        try:
            with db.session_scope(db.NOSCOPE) as s:
                s.execute(text("SELECT 1"))
            return jsonify({"ok": True})
        except Exception:
            return jsonify({"ok": False}), 503

    # ------------------------------------------------------------------ authentication
    @app.post("/api/auth/request")
    def auth_request():
        ident = str(body().get("identifier", ""))[:100]
        lim = app.extensions["limiter"]
        if not (lim.allow(f"req_ip:{client_ip()}", 10, 600) and lim.allow(f"req_id:{ident.lower()}", 5, 600)):
            return fail(429, "rate_limited")
        sent = None
        with db.session_scope(db.NOSCOPE) as s:
            user, code = web_auth.issue_code(s, ident)
            if user:
                sent = (user.telegram_user_id, t(user.preferred_language, "web.code", code=code))
        if sent:
            try:
                asyncio.run(app.extensions["sender"].send_message(chat_id=sent[0], text=sent[1], parse_mode="HTML"))
            except Exception:
                log.warning("could not deliver the login code")
        return jsonify({"ok": True})                    # identical answer whether or not the account exists

    @app.post("/api/auth/verify")
    def auth_verify():
        data = body()
        ident = str(data.get("identifier", ""))[:100]
        lim = app.extensions["limiter"]
        if not (lim.allow(f"ver_ip:{client_ip()}", 20, 600) and lim.allow(f"ver_id:{ident.lower()}", 10, 600)):
            return fail(429, "rate_limited")
        token = payload = None
        with db.session_scope(db.NOSCOPE) as s:               # committed even on failure: keeps the attempt counter
            user, error = web_auth.verify_login(s, ident, str(data.get("code", "")), data.get("totp"))
            if user is not None:
                token = web_auth.create_session(s, user)
                payload = me_payload(s, user)
        if error == "2fa_setup_required":
            return fail(403, "2fa_setup_required")
        if error:
            return fail(401, "invalid_login")
        resp = make_response(jsonify(payload))
        resp.set_cookie(COOKIE, token, max_age=config.WEB_SESSION_HOURS * 3600, httponly=True, samesite="Strict",
                        secure=secure_cookie, path="/")
        return resp

    @app.post("/api/auth/logout")
    def auth_logout():
        with db.session_scope(db.NOSCOPE) as s:
            web_auth.destroy_session(s, request.cookies.get(COOKIE))
        resp = make_response(jsonify({"ok": True}))
        resp.delete_cookie(COOKIE, path="/")
        return resp

    def me_payload(s, user, company_id=None):
        company_id = company_id or user.active_company_id
        companies = access.list_companies(build_ctx(s, user, None), s)
        ctx = build_ctx(s, user, company_id)
        c = s.get(Company, ctx.company_id) if ctx.company_id else None
        return {"user": {"name": user.full_name, "language": user.preferred_language,
                         "totp_enabled": bool(user.totp_enabled), "roles": sorted(ctx.roles)},
                "company": {"id": c.id.hex, "name": c.name} if c else None,
                "companies": [{"id": x.id.hex, "name": x.name} for x in companies],
                "permissions": ["*"] if ctx.is_owner else sorted(ctx.perms)}

    @app.get("/api/me")
    @api(need_company=False)
    def me(ctx, s):
        return jsonify(me_payload(s, s.get(User, ctx.user_id), ctx.company_id))

    @app.post("/api/company/switch")
    @api(need_company=False)
    def switch_company(ctx, s):
        try:
            cid = uuid.UUID(str(body().get("company_id", "")))
        except ValueError:
            raise ServiceError("err.invalid")
        access.set_active_company(ctx, s, s.get(User, ctx.user_id), cid)         # membership is verified here
        ws = s.scalar(select(WebSession).where(WebSession.token_hash == web_auth._hash(request.cookies.get(COOKIE))))
        ws.company_id = cid
        return jsonify({"ok": True})

    # ------------------------------------------------------------------ tickets
    def ticket_dict(tk, nm):
        return {"number": tk.ticket_number, "subject": tk.subject, "category": tk.category, "priority": tk.priority,
                "status": tk.status, "by": nm.get(tk.created_by), "assigned_to": nm.get(tk.assigned_to),
                "created_at": iso(tk.created_at)}

    @app.get("/api/tickets")
    @api("tickets.view")
    def list_tickets(ctx, s):
        rows = tickets.list_tickets(ctx, s, request.args.get("filter", "active"), limit=50)
        nm = names(s, [x.created_by for x in rows] + [x.assigned_to for x in rows])
        return jsonify([ticket_dict(x, nm) for x in rows])

    @app.post("/api/tickets")
    @api("tickets.create")
    def create_ticket(ctx, s):
        d = body()
        tk = tickets.create_ticket(ctx, s, d.get("category"), d.get("subject"), d.get("description"),
                                   d.get("priority", "normal"))
        return jsonify({"number": tk.ticket_number}), 201

    @app.get("/api/tickets/<int:number>")
    @api("tickets.view")
    def ticket_detail(ctx, s, number):
        tk = tickets.get_ticket(ctx, s, number)
        out = ticket_dict(tk, names(s, [tk.created_by, tk.assigned_to]))
        out["description"] = tk.description
        out["messages"] = [{"who": who, "body": m.body, "internal": m.visibility == "internal",
                            "at": iso(m.created_at)} for m, who in tickets.messages(ctx, s, tk)]
        out["next_statuses"] = sorted(tickets.TRANSITIONS.get(tk.status, set())) \
            if (ctx.can("tickets.edit") and not ctx.self_scoped) else []
        return jsonify(out)

    @app.post("/api/tickets/<int:number>/status")
    @api("tickets.view")
    def ticket_status(ctx, s, number):
        d = body()
        tk = tickets.change_status(ctx, s, number, d.get("status"), d.get("reason"))
        return jsonify({"status": tk.status})

    @app.post("/api/tickets/<int:number>/messages")
    @api("tickets.view")
    def ticket_message(ctx, s, number):
        d = body()
        tickets.add_message(ctx, s, number, d.get("body"), internal=bool(d.get("internal")))
        return jsonify({"ok": True}), 201

    @app.post("/api/tickets/<int:number>/assign")
    @api("tickets.view")
    def ticket_assign(ctx, s, number):
        who = str(body().get("user_id", ""))
        uid = ctx.user_id if who == "me" else uuid.UUID(who) if len(who) == 32 else None
        if uid is None:
            raise ServiceError("err.invalid")
        tickets.assign(ctx, s, number, uid)
        return jsonify({"ok": True})

    # ------------------------------------------------------------------ fleet, loads
    @app.get("/api/drivers")
    @api("drivers.view")
    def drivers(ctx, s):
        return jsonify([{"id": d.id.hex, "name": d.full_name, "phone": d.phone, "status": d.status}
                        for d in fleet.list_drivers(ctx, s, request.args.get("status"), limit=100)])

    @app.get("/api/trucks")
    @api("fleet.view")
    def trucks(ctx, s):
        return jsonify([{"id": x.id.hex, "unit": x.unit_number, "vin": x.vin, "status": x.status}
                        for x in fleet.list_trucks(ctx, s, limit=100)])

    def load_dict(ctx, ld, drivers_by_id):
        out = {"number": ld.load_number, "status": ld.status, "broker": ld.broker, "pickup": ld.pickup_address,
               "delivery": ld.delivery_address, "driver": drivers_by_id.get(ld.driver_id)}
        if loads.rate_visible(ctx):                                  # money only for people who may see accounting
            out["rate_cents"] = ld.rate_cents
        return out

    @app.get("/api/loads")
    @api()
    def list_loads(ctx, s):
        rows = loads.list_loads(ctx, s, request.args.get("status", "active"), limit=50)
        drv = {d.id: d.full_name for d in s.scalars(select(Driver).where(Driver.company_id == ctx.company_id))}
        return jsonify([load_dict(ctx, x, drv) for x in rows])

    @app.post("/api/loads")
    @api("dispatch.create")
    def create_load(ctx, s):
        d = body()
        rate = d.get("rate_cents")
        ld = loads.create_load(ctx, s, d.get("number"), d.get("pickup"), d.get("delivery"), d.get("broker"),
                               rate_cents=int(rate) if isinstance(rate, (int, float)) else None)
        return jsonify({"number": ld.load_number}), 201

    @app.post("/api/loads/<number>/status")
    @api()
    def load_status(ctx, s, number):
        ld = loads.change_status(ctx, s, number, body().get("status"))
        return jsonify({"status": ld.status})

    # ------------------------------------------------------------------ approvals, overview, audit, members
    @app.get("/api/approvals")
    @api("approvals.view")
    def list_approvals(ctx, s):
        rows = approvals.list_pending(ctx, s)
        nm = names(s, [a.requested_by for a, _ in rows])
        return jsonify([{"id": a.id.hex, "type": a.action_type, "detail": approvals._detail(a.payload),
                         "by": nm.get(a.requested_by), "can_decide": can, "created_at": iso(a.created_at)}
                        for a, can in rows])

    @app.post("/api/approvals/<aid>/decide")
    @api("approvals.approve")
    def decide(ctx, s, aid):
        try:
            approval_id = uuid.UUID(aid)
        except ValueError:
            raise NotFound()
        a = approvals.decide(ctx, s, approval_id, bool(body().get("approve")))
        return jsonify({"status": a.status})

    @app.get("/api/overview")
    @api("overview.view")
    def overview(ctx, s):
        return jsonify(reports.overview(ctx, s))

    @app.get("/api/audit")
    @api("audit.view", need_company=False)
    def audit_log(ctx, s):
        rows = audit.latest(s, company_id=ctx.company_id, limit=min(int(request.args.get("limit", 50)), 200))
        nm = names(s, [r.actor_user_id for r in rows])
        return jsonify([{"at": iso(r.created_at), "action": r.action, "object": r.object_type,
                         "actor": nm.get(r.actor_user_id, r.actor_type), "channel": r.channel} for r in rows])

    @app.get("/api/members")
    @api("users_access.view")
    def members(ctx, s):
        return jsonify([{"name": u.full_name, "role": role, "status": st, "telegram_id": u.telegram_user_id}
                        for u, role, st in access.list_members(ctx, s)])

    # ------------------------------------------------------------------ billing and AI suggestions
    @app.get("/api/billing")
    @api("billing.view")
    def billing_info(ctx, s):
        e, u = billing.effective(s, ctx.company_id), billing.usage(s, ctx.company_id)
        return jsonify({"plan": e["plan"].name, "status": e["status"], "readonly": e["readonly"],
                        "period_end": iso(e["period_end"]), "limits": e["limits"], "usage": u})

    @app.get("/api/ai/proposals")
    @api("ai_agents.view")
    def ai_proposals(ctx, s):
        if not ai.is_enabled(s, ctx.company_id):
            return jsonify({"enabled": False, "proposals": []})
        return jsonify({"enabled": True, "proposals": [
            {"id": p.id.hex, "agent": p.agent, "text": ai.render(ctx.lang, p),
             "can_decide": ctx.can("ai_agents.approve")} for p in ai.list_proposals(ctx, s)]})

    @app.post("/api/ai/run")
    @api("ai_agents.create")
    def ai_run(ctx, s):
        return jsonify({"new": ai.run(ctx, s)})

    @app.post("/api/ai/proposals/<pid>/<action>")
    @api("ai_agents.approve")
    def ai_decide(ctx, s, pid, action):
        p = ai.by_prefix(ctx, s, pid[:8])
        if action == "apply":
            ai.apply(ctx, s, p)
        elif action == "dismiss":
            ai.dismiss(ctx, s, p)
        else:
            raise NotFound()
        return jsonify({"status": p.status})

    return app
