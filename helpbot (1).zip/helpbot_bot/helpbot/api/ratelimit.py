"""Small in-memory sliding-window limiter (per process). Put a shared limiter (Redis) in front when you scale out."""
import time
from collections import defaultdict, deque


class Limiter:
    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.hits = defaultdict(deque)

    def allow(self, key, limit, window_seconds):
        now = self.clock()
        q = self.hits[key]
        while q and now - q[0] > window_seconds:
            q.popleft()
        if len(q) >= limit:
            return False
        q.append(now)
        return True
