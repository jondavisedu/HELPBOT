"use strict";
const LANGS = ["en", "uz", "ru"];
const T = {
  en: { login: "Sign in", identifier: "Telegram ID or @username", send_code: "Send code to Telegram", code: "Code from Telegram",
    totp: "2FA code (if enabled)", sign_in: "Sign in", logout: "Log out", sent: "If the account exists, a code was sent to your Telegram.",
    overview: "Overview", tickets: "Tickets", loads: "Loads", drivers: "Drivers", trucks: "Trucks", approvals: "Approvals",
    members: "Members", audit: "Audit", open_tickets: "Open tickets", pending: "Pending approvals", number: "#", subject: "Subject",
    category: "Category", priority: "Priority", status: "Status", by: "By", assigned: "Assigned", new_ticket: "New ticket",
    description: "Description", create: "Create", reply: "Reply", internal: "Internal note", send: "Send", assign_me: "Assign to me",
    none: "Nothing here.", broker: "Broker", pickup: "Pickup", delivery: "Delivery", driver: "Driver", name: "Name", phone: "Phone",
    unit: "Unit", role: "Role", action: "Action", when: "When", actor: "Actor", approve: "Approve", reject: "Reject", type: "Type",
    detail: "Detail", rate: "Rate", new_load: "New load", load_number: "Load number", filter: "Filter", active: "Active",
    forbidden: "You do not have permission.", invalid_login: "Wrong or expired code.", rate_limited: "Too many attempts. Try later.",
    "2fa_setup_required": "Turn on 2FA in the bot first: send /2fa to the bot.", no_company: "Choose a company.", error: "Error",
    ai: "AI", apply: "Apply", dismiss: "Dismiss", run_ai: "Run AI now", ai_off: "AI is OFF for this company (turn it on in the bot: /ai on).", plan: "Plan", usage: "Usage", readonly: "Read-only: payment overdue or trial ended." },
  uz: { login: "Kirish", identifier: "Telegram ID yoki @username", send_code: "Kodni Telegramga yuborish", code: "Telegramdagi kod",
    totp: "2FA kodi (yoqilgan bo'lsa)", sign_in: "Kirish", logout: "Chiqish", sent: "Hisob mavjud bo'lsa, kod Telegramingizga yuborildi.",
    overview: "Umumiy ko'rinish", tickets: "Ticketlar", loads: "Yuklar", drivers: "Driverlar", trucks: "Truck'lar", approvals: "Tasdiqlashlar",
    members: "A'zolar", audit: "Audit", open_tickets: "Ochiq ticketlar", pending: "Kutilayotgan tasdiqlashlar", number: "#", subject: "Mavzu",
    category: "Kategoriya", priority: "Muhimlik", status: "Holat", by: "Yaratgan", assigned: "Mas'ul", new_ticket: "Yangi ticket",
    description: "Tavsif", create: "Yaratish", reply: "Javob", internal: "Ichki izoh", send: "Yuborish", assign_me: "O'zimga biriktirish",
    none: "Bu yerda hech narsa yo'q.", broker: "Broker", pickup: "Olish", delivery: "Yetkazish", driver: "Driver", name: "Ism", phone: "Telefon",
    unit: "Unit", role: "Rol", action: "Amal", when: "Qachon", actor: "Kim", approve: "Tasdiqlash", reject: "Rad etish", type: "Turi",
    detail: "Tafsilot", rate: "Narx", new_load: "Yangi yuk", load_number: "Yuk raqami", filter: "Filtr", active: "Faol",
    forbidden: "Sizda ruxsat yo'q.", invalid_login: "Kod noto'g'ri yoki eskirgan.", rate_limited: "Juda ko'p urinish. Keyinroq urinib ko'ring.",
    "2fa_setup_required": "Avval botda 2FA ni yoqing: botga /2fa yuboring.", no_company: "Kompaniyani tanlang.", error: "Xatolik",
    ai: "AI", apply: "Qo'llash", dismiss: "Rad etish", run_ai: "AI ni hozir ishga tushirish", ai_off: "Bu kompaniya uchun AI o'chirilgan (botda yoqing: /ai on).", plan: "Reja", usage: "Foydalanish", readonly: "Faqat ko'rish: to'lov kechikkan yoki sinov tugagan." },
  ru: { login: "Вход", identifier: "Telegram ID или @username", send_code: "Отправить код в Telegram", code: "Код из Telegram",
    totp: "Код 2FA (если включена)", sign_in: "Войти", logout: "Выйти", sent: "Если аккаунт существует, код отправлен в ваш Telegram.",
    overview: "Обзор", tickets: "Тикеты", loads: "Грузы", drivers: "Водители", trucks: "Траки", approvals: "Согласования",
    members: "Сотрудники", audit: "Аудит", open_tickets: "Открытые тикеты", pending: "Ожидают согласования", number: "#", subject: "Тема",
    category: "Категория", priority: "Приоритет", status: "Статус", by: "Автор", assigned: "Ответственный", new_ticket: "Новый тикет",
    description: "Описание", create: "Создать", reply: "Ответить", internal: "Внутренняя заметка", send: "Отправить", assign_me: "Назначить мне",
    none: "Здесь пока ничего нет.", broker: "Брокер", pickup: "Загрузка", delivery: "Доставка", driver: "Водитель", name: "Имя", phone: "Телефон",
    unit: "Юнит", role: "Роль", action: "Действие", when: "Когда", actor: "Кто", approve: "Одобрить", reject: "Отклонить", type: "Тип",
    detail: "Детали", rate: "Ставка", new_load: "Новый груз", load_number: "Номер груза", filter: "Фильтр", active: "Активные",
    forbidden: "Нет прав.", invalid_login: "Неверный или просроченный код.", rate_limited: "Слишком много попыток. Попробуйте позже.",
    "2fa_setup_required": "Сначала включите 2FA в боте: отправьте боту /2fa.", no_company: "Выберите компанию.", error: "Ошибка",
    ai: "AI", apply: "Применить", dismiss: "Отклонить", run_ai: "Запустить AI сейчас", ai_off: "AI выключен для этой компании (включите в боте: /ai on).", plan: "Тариф", usage: "Использование", readonly: "Только чтение: просрочена оплата или закончился пробный период." },
};
const CATEGORIES = ["dispatch", "maintenance", "eld", "safety", "hr", "accounting", "other"];
const PRIORITIES = ["low", "normal", "high", "urgent"];
const LOAD_NEXT = { assigned: ["picked_up", "cancelled"], picked_up: ["delivered", "cancelled"], delivered: ["pod_received"], pod_received: ["invoiced"] };

let lang = localStorage.getItem("hb_lang") || "en";
let me = null, tab = "overview", flash = "", selectedTicket = null;
const tr = (k) => (T[lang] && T[lang][k]) || T.en[k] || k;
const can = (p) => me && (me.permissions.includes("*") || me.permissions.includes(p));

/* All dynamic text goes through textContent / text nodes: no innerHTML anywhere (XSS-safe). */
function el(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === "class") e.className = v; else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v);
  }
  for (const kid of kids.flat()) if (kid != null) e.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return e;
}

async function api(path, method = "GET", data) {
  const opts = { method, credentials: "same-origin", headers: { "X-Requested-With": "HELPBOT" } };
  if (data !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(data); }
  const r = await fetch(path, opts);
  let j = null; try { j = await r.json(); } catch (e) { /* empty body */ }
  if (r.status === 401 && path !== "/api/auth/verify") { me = null; render(); throw new Error("unauthorized"); }
  if (!r.ok) { const err = new Error((j && j.error) || "error"); err.message_text = (j && j.message) || ""; throw err; }
  return j;
}
const say = (msg) => { flash = msg; render(); };
const fail = (e) => say(tr(e.message) !== e.message ? tr(e.message) : (e.message_text || tr("error")));

function table(cols, rows, onclick) {
  if (!rows.length) return el("p", { class: "muted" }, tr("none"));
  return el("table", {}, el("thead", {}, el("tr", {}, cols.map((c) => el("th", {}, tr(c[0]))))),
    el("tbody", {}, rows.map((r) => el("tr", onclick ? { class: "click", onclick: () => onclick(r) } : {},
      cols.map((c) => el("td", {}, c[1](r) ?? ""))))));
}

// ------------------------------------------------------------------ login
function langSelect() {
  return el("select", { onchange: (e) => { lang = e.target.value; localStorage.setItem("hb_lang", lang); render(); } },
    LANGS.map((l) => { const o = el("option", { value: l }, l.toUpperCase()); if (l === lang) o.selected = true; return o; }));
}
function loginView() {
  const root = el("div", { class: "card login" });
  const ident = el("input", { placeholder: tr("identifier"), autocomplete: "username" });
  const code = el("input", { placeholder: tr("code"), inputmode: "numeric", autocomplete: "one-time-code" });
  const totp = el("input", { placeholder: tr("totp"), inputmode: "numeric" });
  root.append(el("h1", {}, "HELPBOT"), el("p", { class: "muted" }, tr("login")), langSelect(), ident,
    el("button", { onclick: async () => { try { await api("/api/auth/request", "POST", { identifier: ident.value }); say(tr("sent")); } catch (e) { fail(e); } } }, tr("send_code")),
    code, totp,
    el("button", { class: "ok", onclick: async () => {
      try { me = await api("/api/auth/verify", "POST", { identifier: ident.value, code: code.value, totp: totp.value || undefined }); flash = ""; tab = firstTab(); render(); }
      catch (e) { fail(e); } } }, tr("sign_in")));
  if (flash) root.append(el("p", { class: "err" }, flash));
  return root;
}

// ------------------------------------------------------------------ layout
function tabs() {
  const out = [];
  if (can("overview.view")) out.push("overview");
  if (can("tickets.view")) out.push("tickets");
  if (can("dispatch.view") || can("accounting.view") || me.user.roles.includes("driver")) out.push("loads");
  if (can("drivers.view")) out.push("drivers");
  if (can("fleet.view")) out.push("trucks");
  if (can("approvals.view")) out.push("approvals");
  if (can("users_access.view")) out.push("members");
  if (can("ai_agents.view")) out.push("ai");
  if (can("audit.view")) out.push("audit");
  return out;
}
const firstTab = () => tabs()[0] || "tickets";

function layout(content) {
  const companySel = el("select", { onchange: async (e) => { try { await api("/api/company/switch", "POST", { company_id: e.target.value }); me = await api("/api/me"); selectedTicket = null; tab = firstTab(); render(); } catch (x) { fail(x); } } },
    me.companies.map((c) => { const o = el("option", { value: c.id }, c.name); if (me.company && me.company.id === c.id) o.selected = true; return o; }));
  const header = el("header", {}, el("span", { class: "brand" }, "HELPBOT"),
    el("div", { class: "tools" }, me.companies.length ? companySel : "", langSelect(), el("span", { class: "muted" }, me.user.name),
      el("button", { class: "ghost", onclick: async () => { await api("/api/auth/logout", "POST", {}); me = null; render(); } }, tr("logout"))));
  const nav = el("nav", {}, tabs().map((k) => el("button", { class: "tab ghost" + (k === tab ? " active" : ""), onclick: () => { tab = k; selectedTicket = null; render(); } }, tr(k))));
  return [header, nav, el("main", {}, flash ? el("p", { class: "err" }, flash) : "", content)];
}

// ------------------------------------------------------------------ pages
async function overviewPage() {
  const d = await api("/api/overview");
  const cards = [[tr("open_tickets"), d.open_tickets]];
  if (d.pending_approvals !== undefined) cards.push([tr("pending"), d.pending_approvals]);
  for (const [k, v] of Object.entries(d.drivers || {})) cards.push([tr("drivers") + " · " + k, v]);
  for (const [k, v] of Object.entries(d.trucks || {})) cards.push([tr("trucks") + " · " + k, v]);
  const out = [el("div", { class: "grid" }, cards.map(([k, v]) => el("div", { class: "card stat" }, el("b", {}, v), el("span", {}, k))))];
  if (can("billing.view")) {
    try {
      const b = await api("/api/billing");
      out.push(el("div", { class: "card" }, el("b", {}, tr("plan") + ": " + b.plan + " (" + b.status + ")"),
        el("p", { class: "muted" }, tr("usage") + ": " + tr("drivers") + " " + b.usage.drivers + "/" + b.limits.drivers + " · " + tr("trucks") + " " + b.usage.trucks + "/" + b.limits.trucks),
        b.readonly ? el("p", { class: "err" }, tr("readonly")) : ""));
    } catch (e) { /* billing card is optional */ }
  }
  return out;
}

async function ticketsPage() {
  const flt = localStorage.getItem("hb_flt") || "active";
  const rows = await api("/api/tickets?filter=" + encodeURIComponent(flt));
  const filter = el("select", { onchange: (e) => { localStorage.setItem("hb_flt", e.target.value); render(); } },
    ["active", "open", "in_progress", "waiting", "escalated", "done", "mine"].map((f) => { const o = el("option", { value: f }, f); if (f === flt) o.selected = true; return o; }));
  const out = [el("div", { class: "card" }, el("div", { class: "row" }, el("b", {}, tr("tickets")), filter),
    table([["number", (r) => "#" + r.number], ["subject", (r) => r.subject], ["category", (r) => r.category], ["priority", (r) => r.priority],
      ["status", (r) => r.status], ["by", (r) => r.by]], rows, (r) => { selectedTicket = r.number; render(); }))];
  if (selectedTicket) out.push(await ticketDetail(selectedTicket));
  if (can("tickets.create")) out.push(newTicketForm());
  return out;
}
async function ticketDetail(n) {
  const d = await api("/api/tickets/" + n);
  const box = el("div", { class: "card" }, el("h3", {}, "#" + d.number + " · " + d.subject),
    el("p", { class: "muted" }, [d.category, d.priority, d.status, d.by, d.assigned_to].filter(Boolean).join(" · ")),
    el("p", {}, d.description || ""));
  d.messages.forEach((m) => box.append(el("div", { class: "msg" + (m.internal ? " internal" : "") }, (m.internal ? "🔒 " : "") + m.who + ": " + m.body)));
  const row = el("div", { class: "row" });
  d.next_statuses.forEach((st) => row.append(el("button", { onclick: async () => { try { const reason = st === "open" ? prompt(tr("description")) : undefined; await api(`/api/tickets/${n}/status`, "POST", { status: st, reason }); render(); } catch (e) { fail(e); } } }, st)));
  if (can("tickets.assign")) row.append(el("button", { class: "ghost", onclick: async () => { try { await api(`/api/tickets/${n}/assign`, "POST", { user_id: "me" }); render(); } catch (e) { fail(e); } } }, tr("assign_me")));
  box.append(row);
  const body = el("textarea", { placeholder: tr("reply"), rows: "2" });
  const internal = el("input", { type: "checkbox" });
  box.append(el("div", { class: "row" }, body, can("tickets.edit") ? el("label", {}, internal, " " + tr("internal")) : "",
    el("button", { onclick: async () => { try { await api(`/api/tickets/${n}/messages`, "POST", { body: body.value, internal: internal.checked }); render(); } catch (e) { fail(e); } } }, tr("send"))));
  return box;
}
function newTicketForm() {
  const cat = el("select", {}, CATEGORIES.map((c) => el("option", { value: c }, c)));
  const pr = el("select", {}, PRIORITIES.map((c) => { const o = el("option", { value: c }, c); if (c === "normal") o.selected = true; return o; }));
  const subj = el("input", { placeholder: tr("subject") });
  const desc = el("textarea", { placeholder: tr("description"), rows: "2" });
  return el("div", { class: "card" }, el("b", {}, tr("new_ticket")), el("div", { class: "row" }, cat, pr, subj), desc,
    el("div", { class: "row" }, el("button", { class: "ok", onclick: async () => { try { await api("/api/tickets", "POST", { category: cat.value, priority: pr.value, subject: subj.value, description: desc.value }); say(""); } catch (e) { fail(e); } } }, tr("create"))));
}

async function loadsPage() {
  const rows = await api("/api/loads");
  const cols = [["load_number", (r) => r.number], ["status", (r) => r.status], ["pickup", (r) => r.pickup], ["delivery", (r) => r.delivery], ["driver", (r) => r.driver], ["broker", (r) => r.broker]];
  if (rows.length && "rate_cents" in rows[0]) cols.push(["rate", (r) => (r.rate_cents == null ? "" : "$" + (r.rate_cents / 100).toFixed(2))]);
  cols.push(["action", (r) => el("span", {}, (LOAD_NEXT[r.status] || []).map((st) => el("button", { onclick: async () => { try { await api(`/api/loads/${encodeURIComponent(r.number)}/status`, "POST", { status: st }); render(); } catch (e) { fail(e); } } }, st)))]);
  const out = [el("div", { class: "card" }, table(cols, rows))];
  if (can("dispatch.create")) {
    const num = el("input", { placeholder: tr("load_number") }), pu = el("input", { placeholder: tr("pickup") }), de = el("input", { placeholder: tr("delivery") }), br = el("input", { placeholder: tr("broker") });
    out.push(el("div", { class: "card" }, el("b", {}, tr("new_load")), el("div", { class: "row" }, num, pu, de, br),
      el("button", { class: "ok", onclick: async () => { try { await api("/api/loads", "POST", { number: num.value, pickup: pu.value, delivery: de.value, broker: br.value }); say(""); } catch (e) { fail(e); } } }, tr("create"))));
  }
  return out;
}
async function driversPage() { return el("div", { class: "card" }, table([["name", (r) => r.name], ["phone", (r) => r.phone], ["status", (r) => r.status]], await api("/api/drivers"))); }
async function trucksPage() { return el("div", { class: "card" }, table([["unit", (r) => r.unit], ["status", (r) => r.status], ["VIN", (r) => r.vin]], await api("/api/trucks"))); }
async function membersPage() { return el("div", { class: "card" }, table([["name", (r) => r.name], ["role", (r) => r.role], ["status", (r) => r.status]], await api("/api/members"))); }
async function auditPage() { return el("div", { class: "card" }, table([["when", (r) => r.at.slice(0, 16).replace("T", " ")], ["action", (r) => r.action], ["type", (r) => r.object], ["actor", (r) => r.actor]], await api("/api/audit"))); }
async function approvalsPage() {
  const rows = await api("/api/approvals");
  const decide = (id, approve) => async () => { try { await api(`/api/approvals/${id}/decide`, "POST", { approve }); render(); } catch (e) { fail(e); } };
  return el("div", { class: "card" }, table([["type", (r) => r.type], ["detail", (r) => r.detail], ["by", (r) => r.by],
    ["action", (r) => (r.can_decide ? el("span", {}, el("button", { class: "ok", onclick: decide(r.id, true) }, tr("approve")), el("button", { class: "bad", onclick: decide(r.id, false) }, tr("reject"))) : "")]], rows));
}
async function aiPage() {
  const d = await api("/api/ai/proposals");
  if (!d.enabled) return el("div", { class: "card" }, el("p", { class: "muted" }, tr("ai_off")));
  const decide = (id, action) => async () => { try { await api(`/api/ai/proposals/${id}/${action}`, "POST", {}); render(); } catch (e) { fail(e); } };
  const out = [];
  if (can("ai_agents.create")) out.push(el("div", { class: "card" }, el("button", { onclick: async () => { try { await api("/api/ai/run", "POST", {}); render(); } catch (e) { fail(e); } } }, tr("run_ai"))));
  out.push(el("div", { class: "card" }, table([["type", (r) => r.agent], ["detail", (r) => r.text],
    ["action", (r) => (r.can_decide ? el("span", {}, el("button", { class: "ok", onclick: decide(r.id, "apply") }, tr("apply")), el("button", { class: "ghost", onclick: decide(r.id, "dismiss") }, tr("dismiss"))) : "")]], d.proposals)));
  return out;
}
const PAGES = { ai: aiPage, overview: overviewPage, tickets: ticketsPage, loads: loadsPage, drivers: driversPage, trucks: trucksPage, approvals: approvalsPage, members: membersPage, audit: auditPage };

let rendering = false;
async function render() {
  if (rendering) return; rendering = true;
  const app = document.getElementById("app");
  try {
    if (!me) { app.replaceChildren(loginView()); return; }
    let content;
    try { content = await PAGES[tab](); } catch (e) { content = e.message === "unauthorized" ? "" : el("p", { class: "err" }, tr(e.message) !== e.message ? tr(e.message) : tr("error")); }
    app.replaceChildren(...layout(content));
    flash = "";
  } finally { rendering = false; }
}
(async () => { try { me = await api("/api/me"); tab = firstTab(); } catch (e) { me = null; } render(); })();
