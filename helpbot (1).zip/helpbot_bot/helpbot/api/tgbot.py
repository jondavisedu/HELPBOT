"""Minimal Telegram sender for the web process (the bot process uses python-telegram-bot)."""
import json
import logging
from types import SimpleNamespace

import httpx

from .. import config

log = logging.getLogger("helpbot.api")


class HttpBot:
    async def send_message(self, chat_id, text, parse_mode=None, reply_markup=None, disable_web_page_preview=None,
                           **_ignored):
        payload = {"chat_id": chat_id, "text": text}
        if parse_mode:
            payload["parse_mode"] = parse_mode
        if reply_markup is not None:
            payload["reply_markup"] = json.dumps(reply_markup.to_dict() if hasattr(reply_markup, "to_dict")
                                                 else reply_markup)
        if disable_web_page_preview:
            payload["disable_web_page_preview"] = True
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(f"https://api.telegram.org/bot{config.BOT_TOKEN}/sendMessage", data=payload)
        if r.status_code != 200:
            log.warning("telegram sendMessage failed: HTTP %s", r.status_code)      # never log the URL (token)
            raise RuntimeError("telegram send failed")
        return SimpleNamespace(message_id=r.json().get("result", {}).get("message_id"))
