"""Audit trail. Rows are only ever inserted."""
from sqlalchemy import select

from .models import AuditLog


def record(s, *, action, object_type, object_id=None, ctx=None, actor_user_id=None, company_id=None,
           before=None, after=None, reason=None, actor_type="user", channel="telegram"):
    if ctx is not None:
        actor_user_id = actor_user_id or ctx.user_id
        company_id = company_id or ctx.company_id
        channel = ctx.channel
    row = AuditLog(company_id=company_id, actor_user_id=actor_user_id, actor_type=actor_type, channel=channel,
                   action=action, object_type=object_type, object_id=object_id, before_data=before,
                   after_data=after, reason=reason)
    s.add(row)
    return row


def latest(s, *, company_id=None, limit=20):
    q = select(AuditLog).order_by(AuditLog.id.desc()).limit(limit)
    if company_id is not None:
        q = q.where(AuditLog.company_id == company_id)
    return list(s.scalars(q))
