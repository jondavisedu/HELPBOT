"""Startup: migrate, seed roles/permissions, create the Owner account."""
import logging

from . import config, db, migrate, rbac
from .services import access, billing

log = logging.getLogger("helpbot")


def prepare():
    with migrate.startup_lock():                 # several processes may start at once: one migrates and seeds
        if config.AUTO_MIGRATE:
            migrate.upgrade("head")
        with db.platform_session("startup seed: roles, permissions, owner") as s:
            rbac.seed_rbac(s)
            billing.seed_plans(s)
            access.ensure_owners(s)
    log.info("HELPBOT ready (env=%s, db=%s, owners=%d)", config.ENVIRONMENT,
             "PostgreSQL" if config.DATABASE_URL.startswith("postgresql") else "SQLite", len(config.OWNER_IDS))
