"""Owner/admin: registration decisions, companies, members, grants, audit."""
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from .. import audit
from ..i18n import t
from ..models import Company, RegistrationRequest, User
from ..rbac import ASSIGNABLE_BY_COMPANY_ADMIN
from ..services import access, approvals
from ..services.errors import ServiceError
from .runtime import answer, command, kb, reply, secured, show

ROLE_PICK = ["company_admin", "manager", "dispatcher", "eld_support", "safety_officer", "hr", "accountant",
             "maintenance", "driver", "client", "viewer"]


def _target(s, arg):
    """Resolve a Telegram id typed by an admin to a user (the person must have written to the bot)."""
    if not (arg or "").lstrip("-").isdigit():
        raise ServiceError("err.invalid")
    u = access.get_user_by_tg(s, int(arg))
    if u is None:
        raise ServiceError("user.unknown")
    return u


# ------------------------------------------------------------------ registration decisions (Owner only)
@secured(owner_only=True, need_company=False, dm_only=True)
async def cb_registration(update, context, ctx, s):
    _, prefix, decision = update.callback_query.data.split(":")
    req = access.find_by_prefix(s, RegistrationRequest, prefix, (RegistrationRequest.status == "pending",))
    if req is None:
        await answer(update)
        await show(update, context, t(ctx.lang, "reg.not_pending"))
        return
    approve = decision == "ok"
    req, user = access.decide_registration(ctx, s, req.id, approve)
    await answer(update)
    if not approve:
        await show(update, context, t(ctx.lang, "reg.decided_no", name=user.full_name))
        return
    companies = access.list_companies(ctx, s)
    if not companies:
        await show(update, context, t(ctx.lang, "reg.decided_ok", name=user.full_name) + "\n"
                   + t(ctx.lang, "reg.no_companies"))
        return
    rows = [[(c.name, f"ac:{user.id.hex[:8]}:{c.id.hex[:8]}")] for c in companies[:20]] + [[("btn.skip_company", "ac:x:x")]]
    await show(update, context, t(ctx.lang, "reg.decided_ok", name=user.full_name) + "\n"
               + t(ctx.lang, "reg.pick_company", name=user.full_name), kb(ctx.lang, rows))


@secured(owner_only=True, need_company=False, dm_only=True)
async def cb_pick_company(update, context, ctx, s):
    _, uprefix, cprefix = update.callback_query.data.split(":")
    await answer(update)
    if uprefix == "x":
        await show(update, context, "👍")
        return
    user = access.find_by_prefix(s, User, uprefix)
    company = access.company_by_prefix(ctx, s, cprefix)
    if user is None or company is None:
        await show(update, context, t(ctx.lang, "err.not_found"))
        return
    rows = [[(f"role.{r}", f"ar:{user.id.hex[:8]}:{company.id.hex[:8]}:{i}")] for i, r in enumerate(ROLE_PICK)]
    await show(update, context, t(ctx.lang, "reg.pick_role", name=user.full_name, company=company.name),
               kb(ctx.lang, rows))


@secured(owner_only=True, need_company=False, dm_only=True)
async def cb_pick_role(update, context, ctx, s):
    _, uprefix, cprefix, idx = update.callback_query.data.split(":")
    user = access.find_by_prefix(s, User, uprefix)
    company = access.company_by_prefix(ctx, s, cprefix)
    if user is None or company is None or not idx.isdigit() or int(idx) >= len(ROLE_PICK):
        await answer(update)
        return
    role = ROLE_PICK[int(idx)]
    access.assign_role(ctx, s, user.id, role, company.id)
    await answer(update)
    await show(update, context, t(ctx.lang, "user.role_set", name=user.full_name, role=role) + f" ({company.name})")


@command("requests", owner_only=True, need_company=False, dm_only=True)
async def cmd_requests(update, context, ctx, s):
    await answer(update)
    rows = access.pending_requests(ctx, s)
    if not rows:
        await reply(update, context, t(ctx.lang, "reg.none"))
        return
    for req, user in rows[:10]:
        await reply(update, context, t(ctx.lang, "reg.new_request", name=user.full_name,
                                       username=user.telegram_username or "-", tg_id=user.telegram_user_id,
                                       company=req.requested_company_name or "-", message=req.message or "-"),
                    kb(ctx.lang, [[("btn.approve", f"rr:{req.id.hex[:8]}:ok"), ("btn.reject", f"rr:{req.id.hex[:8]}:no")]]))


# ------------------------------------------------------------------ companies and members
@command("newcompany", need_company=False, dm_only=True)
async def cmd_newcompany(update, context, ctx, s):
    name = " ".join(context.args or [])
    if not name:
        await reply(update, context, t(ctx.lang, "company.usage"))
        return
    c = access.create_company(ctx, s, name)
    s.get(User, ctx.user_id).active_company_id = c.id
    await reply(update, context, t(ctx.lang, "company.created", name=c.name))


@command("users", "users_access.view")
async def cmd_users(update, context, ctx, s):
    lines = [t(ctx.lang, "user.list")]
    for user, role, status in access.list_members(ctx, s):
        lines.append(f"• {user.full_name} — {t(ctx.lang, 'role.' + role)}" + ("" if status == "active" else f" ({status})")
                     + f" · <code>{user.telegram_user_id}</code>")
    await reply(update, context, "\n".join(lines))


@command("setrole", "users_access.manage")
async def cmd_setrole(update, context, ctx, s):
    a = context.args or []
    if len(a) != 2:
        await reply(update, context, t(ctx.lang, "admin.usage_role"))
        return
    target = _target(s, a[0])
    access.assign_role(ctx, s, target.id, a[1])
    await reply(update, context, t(ctx.lang, "user.role_set", name=target.full_name, role=a[1]))


@command("removeuser", "users_access.manage")
async def cmd_removeuser(update, context, ctx, s):
    a = context.args or []
    if len(a) != 1:
        await reply(update, context, t(ctx.lang, "admin.usage_role"))
        return
    access.remove_member(ctx, s, _target(s, a[0]).id)
    await reply(update, context, t(ctx.lang, "user.removed"))


@command("suspenduser", "users_access.manage")
async def cmd_suspenduser(update, context, ctx, s):
    a = context.args or []
    if len(a) < 2:
        await reply(update, context, t(ctx.lang, "admin.usage_suspend"))
        return
    approvals.request_user_suspend(ctx, s, _target(s, a[0]).id, " ".join(a[1:]))
    await reply(update, context, t(ctx.lang, "appr.requested"))


@command("suspendcompany", "companies.manage")
async def cmd_suspendcompany(update, context, ctx, s):
    if not context.args:
        await reply(update, context, t(ctx.lang, "admin.company_suspend_usage"))
        return
    approvals.request_company_suspend(ctx, s, " ".join(context.args))
    await reply(update, context, t(ctx.lang, "appr.requested"))


@command("grant", owner_only=True, need_company=False)
async def cmd_grant(update, context, ctx, s):
    a = context.args or []
    if len(a) < 2:
        await reply(update, context, t(ctx.lang, "admin.usage_grant"))
        return
    target = _target(s, a[0])
    platform_level = a[1].startswith(("company.", "platform."))
    if not platform_level and ctx.company_id is None:
        raise ServiceError("err.no_company")
    expires = datetime.now(timezone.utc) + timedelta(days=int(a[2])) if len(a) > 2 and a[2].isdigit() else None
    access.grant_permission(ctx, s, target.id, a[1], None if platform_level else ctx.company_id, expires)
    await reply(update, context, t(ctx.lang, "admin.granted"))


@command("revoke", owner_only=True, need_company=False)
async def cmd_revoke(update, context, ctx, s):
    a = context.args or []
    if len(a) != 2:
        await reply(update, context, t(ctx.lang, "admin.usage_grant"))
        return
    n = access.revoke_permission(ctx, s, _target(s, a[0]).id, a[1])
    await reply(update, context, t(ctx.lang, "admin.revoked", n=n))


@command("audit", "audit.view", need_company=False)
async def cmd_audit(update, context, ctx, s):
    n = min(int((context.args or ["15"])[0]) if (context.args or ["15"])[0].isdigit() else 15, 30)
    rows = audit.latest(s, company_id=ctx.company_id, limit=n)
    if not rows:
        await reply(update, context, t(ctx.lang, "audit.none"))
        return
    actor_ids = {r.actor_user_id for r in rows if r.actor_user_id}
    names = {u.id: u.full_name for u in s.scalars(select(User).where(User.id.in_(actor_ids)))} if actor_ids else {}
    lines = [t(ctx.lang, "audit.title", n=len(rows))]
    for r in rows:
        who = names.get(r.actor_user_id, r.actor_type)
        lines.append(f"{r.created_at:%m-%d %H:%M} · {r.action} · {r.object_type} · {who}")
    await reply(update, context, "\n".join(lines))
