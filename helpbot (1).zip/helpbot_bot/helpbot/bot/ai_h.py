"""/ai: suggestions from the AI agents. They only propose; a human applies or dismisses."""
from ..i18n import t
from ..services import ai as svc
from .runtime import answer, command, kb, reply, secured, show


@command("ai", "ai_agents.view")
async def cmd_ai(update, context, ctx, s):
    await answer(update)
    a = context.args or []
    if a and a[0] in ("on", "off"):
        svc.set_enabled(ctx, s, a[0] == "on")
        await reply(update, context, t(ctx.lang, "ai.enabled" if a[0] == "on" else "ai.turned_off"))
        return
    if not svc.is_enabled(s, ctx.company_id):
        await reply(update, context, t(ctx.lang, "ai.disabled"))
        return
    rows = svc.list_proposals(ctx, s)
    if not rows:
        await reply(update, context, t(ctx.lang, "ai.none"))
        return
    await reply(update, context, t(ctx.lang, "ai.title"))
    for p in rows[:10]:
        buttons = [[("btn.apply", f"aa:{p.id.hex[:8]}:ok"), ("btn.dismiss", f"aa:{p.id.hex[:8]}:no")]] \
            if ctx.can("ai_agents.approve") else None
        await reply(update, context, f"{p.agent}: {svc.render(ctx.lang, p)}", kb(ctx.lang, buttons) if buttons else None)


@command("airun", "ai_agents.create")
async def cmd_airun(update, context, ctx, s):
    await answer(update)
    n = svc.run(ctx, s)
    await reply(update, context, t(ctx.lang, "ai.ran", n=n))


@secured("ai_agents.approve")
async def cb_decide(update, context, ctx, s):
    _, prefix, decision = update.callback_query.data.split(":")
    p = svc.by_prefix(ctx, s, prefix)
    if decision == "ok":
        svc.apply(ctx, s, p)
    else:
        svc.dismiss(ctx, s, p)
    await answer(update)
    await show(update, context, t(ctx.lang, "ai.applied" if decision == "ok" else "ai.dismissed"))
