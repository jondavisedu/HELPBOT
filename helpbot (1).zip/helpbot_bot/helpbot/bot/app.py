"""Builds the Telegram application: handlers, jobs, commands."""
import logging
from datetime import time as dtime

from telegram import BotCommand, Update
from telegram.error import TelegramError
from telegram.ext import (Application, CallbackQueryHandler, ChatMemberHandler, CommandHandler, MessageHandler,
                          filters)

from .. import config, db
from ..services import access
from . import (admin, ai_h, approvals_h, auth_h, basic, billing_h, eld_h, files_h, fleet_h, flows, groups_h, jobs, loads_h, pti_h,
               runtime, tickets_h)

log = logging.getLogger("helpbot")

PUBLIC_COMMANDS = [
    ("start", "Start / account status"), ("menu", "Main menu"), ("help", "Commands available to you"),
    ("ticket", "Create a ticket"), ("tickets", "Tickets"), ("mytickets", "My tickets"), ("status", "My status"),
    ("drivers", "Drivers"), ("trucks", "Trucks"), ("approvals", "Pending approvals"), ("overview", "Overview"),
    ("mycompany", "Switch company"), ("language", "Language"), ("profile", "My profile"), ("cancel", "Cancel"),
]


async def post_init(app):
    try:
        await app.bot.set_my_commands([BotCommand(c, d) for c, d in PUBLIC_COMMANDS])
    except TelegramError as e:
        log.warning("set_my_commands failed: %s", e)


async def on_error(update, context):
    # No user data in logs or owner alerts: only the error type and the kind of update.
    log.error("update error: %r", context.error, exc_info=context.error)
    for owner_id in config.OWNER_IDS:
        try:
            await context.bot.send_message(owner_id, f"⚠️ HELPBOT error: {type(context.error).__name__}")
        except TelegramError:
            pass


def build_application():
    app = Application.builder().token(config.BOT_TOKEN).post_init(post_init).build()
    cb = CallbackQueryHandler

    app.add_handler(CommandHandler("start", basic.cmd_start))
    app.add_handler(CommandHandler("request_access", basic.cmd_request_access))
    app.add_handler(CommandHandler("cancel", basic.cmd_cancel))
    app.add_handler(CommandHandler("linkgroup", groups_h.cmd_linkgroup))
    for name, fn in runtime.COMMANDS.items():                 # every @command(...) handler
        app.add_handler(CommandHandler(name, fn))

    app.add_handler(cb(basic.cb_lang, pattern=r"^lang:\w+$"))
    app.add_handler(cb(basic.cmd_request_access, pattern=r"^ra:go$"))
    app.add_handler(cb(basic.cb_command, pattern=r"^cmd:\w+$"))
    app.add_handler(cb(basic.cb_company, pattern=r"^co:\w+$"))
    app.add_handler(cb(basic.cb_notif_read, pattern=r"^nr:all$"))
    app.add_handler(cb(admin.cb_registration, pattern=r"^rr:\w+:(ok|no)$"))
    app.add_handler(cb(admin.cb_pick_company, pattern=r"^ac:\w+:\w+$"))
    app.add_handler(cb(admin.cb_pick_role, pattern=r"^ar:\w+:\w+:\d+$"))
    app.add_handler(cb(tickets_h.cb_new_category, pattern=r"^nt:\w+$"))
    app.add_handler(cb(tickets_h.cb_new_priority, pattern=r"^np:\w+$"))
    app.add_handler(cb(tickets_h.cb_skip_description, pattern=r"^nd:skip$"))
    app.add_handler(cb(tickets_h.cb_list, pattern=r"^tl:\w+$"))
    app.add_handler(cb(tickets_h.cb_ticket, pattern=r"^tk:\d+:\w+$"))
    app.add_handler(cb(fleet_h.cb_driver, pattern=r"^dv:\w+$"))
    app.add_handler(cb(fleet_h.cb_driver_status, pattern=r"^ds:\w+:\d+$"))
    app.add_handler(cb(fleet_h.cb_assign_pick, pattern=r"^da:\w+$"))
    app.add_handler(cb(fleet_h.cb_assign_truck, pattern=r"^at:\w+:\w+$"))
    app.add_handler(cb(fleet_h.cb_unassign, pattern=r"^du:\w+$"))
    app.add_handler(cb(fleet_h.cb_truck, pattern=r"^tr:\w+$"))
    app.add_handler(cb(fleet_h.cb_truck_status, pattern=r"^ts:\w+:\d+$"))
    app.add_handler(cb(approvals_h.cb_approval, pattern=r"^ap:\w+:[yn]$"))
    app.add_handler(cb(ai_h.cb_decide, pattern=r"^aa:\w+:(ok|no)$"))
    app.add_handler(cb(loads_h.cb_load, pattern=r"^ld:[A-Z0-9._/-]+$"))
    app.add_handler(cb(loads_h.cb_load_status, pattern=r"^ls:[A-Z0-9._/-]+:\d+$"))
    app.add_handler(cb(loads_h.cb_load_pick_driver, pattern=r"^lg:[A-Z0-9._/-]+$"))
    app.add_handler(cb(loads_h.cb_load_assign, pattern=r"^la:[A-Z0-9._/-]+:\w+$"))
    app.add_handler(cb(loads_h.cb_load_file, pattern=r"^lf:[A-Z0-9._/-]+:(BOL|POD)$"))
    app.add_handler(cb(loads_h.cb_skip_broker, pattern=r"^lb:skip$"))
    app.add_handler(cb(pti_h.cb_request, pattern=r"^pq:\w+$"))
    app.add_handler(cb(pti_h.cb_start, pattern=r"^pt:go:\w+$"))
    app.add_handler(cb(pti_h.finish, pattern=r"^pt:done$"))
    app.add_handler(cb(pti_h.cb_review, pattern=r"^pr:\w+:(ok|redo)$"))
    app.add_handler(cb(eld_h.cb_pick_driver, pattern=r"^ed:\w+$"))
    app.add_handler(cb(eld_h.cb_resolve, pattern=r"^er:\w+$"))
    app.add_handler(CommandHandler("ptidone", pti_h.finish))
    app.add_handler(MessageHandler((filters.PHOTO | filters.Document.ALL) & filters.ChatType.PRIVATE, files_h.on_file))

    app.add_handler(ChatMemberHandler(groups_h.on_my_chat_member, ChatMemberHandler.MY_CHAT_MEMBER))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, flows.on_text))     # multi-step flows: last
    app.add_error_handler(on_error)

    app.job_queue.run_repeating(jobs.ticket_reminders, interval=300, first=120)
    app.job_queue.run_repeating(jobs.eld_deadlines, interval=6 * 3600, first=300)
    app.job_queue.run_daily(jobs.ai_daily, time=dtime(7, 0, tzinfo=config.TZ))
    app.job_queue.run_daily(jobs.expire_approvals, time=dtime(3, 0, tzinfo=config.TZ))
    return app


def run(app):
    if config.WEBHOOK_URL:
        if not config.WEBHOOK_SECRET:
            raise SystemExit("WEBHOOK_SECRET is required in webhook mode")
        app.run_webhook(listen="0.0.0.0", port=config.PORT, url_path=config.BOT_TOKEN,
                        webhook_url=f"{config.WEBHOOK_URL}/{config.BOT_TOKEN}", secret_token=config.WEBHOOK_SECRET,
                        allowed_updates=Update.ALL_TYPES)
    else:
        app.run_polling(allowed_updates=Update.ALL_TYPES)
