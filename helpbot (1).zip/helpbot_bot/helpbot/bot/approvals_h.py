"""Approval Center: list and decide. Approve/Reject buttons resolve the company from the database."""
from sqlalchemy import select

from ..i18n import t
from ..models import User
from ..services import approvals
from . import runtime
from .runtime import answer, command, kb, reply, run_as, show


@command("approvals", "approvals.view")
async def cmd_approvals(update, context, ctx, s):
    await answer(update)
    rows = approvals.list_pending(ctx, s)
    if not rows:
        await reply(update, context, t(ctx.lang, "appr.none"))
        return
    await reply(update, context, t(ctx.lang, "appr.title"))
    for a, can_decide in rows[:10]:
        who = s.get(User, a.requested_by)
        text = t(ctx.lang, "appr.line", type=a.action_type, detail=approvals._detail(a.payload),
                 by=who.full_name if who else "-")
        buttons = [[("btn.approve", f"ap:{a.id.hex[:8]}:y"), ("btn.reject", f"ap:{a.id.hex[:8]}:n")]] if can_decide else None
        await reply(update, context, text, kb(ctx.lang, buttons) if buttons else None)


async def cb_approval(update, context):
    q = update.callback_query
    _, prefix, decision = q.data.split(":")
    company_id, approval_id = approvals.approval_company(prefix)
    await answer(update)
    if company_id is None:
        await show(update, context, "—")
        return

    async def work(update, context, ctx, s):
        approvals.decide(ctx, s, approval_id, decision == "y")
        await show(update, context, t(ctx.lang, "appr.done_ok" if decision == "y" else "appr.done_no"))

    await run_as(update, context, work, company_id, "approvals.approve")
