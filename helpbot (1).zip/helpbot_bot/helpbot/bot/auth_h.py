"""/2fa and /weblogout (private chat only)."""
from .. import config
from ..i18n import t
from ..models import User
from ..services import web_auth
from .runtime import answer, command, reply


@command("2fa", need_company=False, dm_only=True)
async def cmd_2fa(update, context, ctx, s):
    await answer(update)
    user = s.get(User, ctx.user_id)
    if not config.SECRET_KEY:
        await reply(update, context, t(ctx.lang, "tfa.not_configured"))
        return
    a = context.args or []
    if a and a[0] == "off" and len(a) == 2:
        ok = web_auth.totp_disable(s, user, a[1])
        await reply(update, context, t(ctx.lang, "tfa.disabled" if ok else "tfa.bad_code"))
    elif len(a) == 1 and a[0].isdigit():
        ok = web_auth.totp_confirm(s, user, a[0])
        await reply(update, context, t(ctx.lang, "tfa.enabled" if ok else "tfa.bad_code"))
    elif user.totp_enabled:
        await reply(update, context, t(ctx.lang, "tfa.status_on"))
    else:
        secret, _ = web_auth.totp_begin(s, user)
        await reply(update, context, t(ctx.lang, "tfa.intro", secret=secret))


@command("weblogout", need_company=False, dm_only=True)
async def cmd_weblogout(update, context, ctx, s):
    await answer(update)
    web_auth.destroy_all_sessions(s, ctx.user_id)
    await reply(update, context, t(ctx.lang, "weblogout.done"))
