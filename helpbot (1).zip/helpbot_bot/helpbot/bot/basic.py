"""Start, language, registration request, menu, help, profile, company switch, notifications."""
from sqlalchemy import select

from .. import config, db
from ..i18n import t
from ..models import Company, Notification, RegistrationRequest, User
from ..rbac import GroupPost
from ..services import access
from . import runtime
from .runtime import answer, anon_ctx, command, kb, reply, say, secured, show


def lang_kb():
    return kb("en", [[("🇬🇧 English", "lang:en"), ("🇺🇿 O'zbekcha", "lang:uz"), ("🇷🇺 Русский", "lang:ru")]])


def main_menu(ctx, lang):
    rows, a = [], []
    pairs = [("btn.tickets", "tickets", "tickets.view"), ("btn.mytickets", "mytickets", "tickets.view"),
             ("btn.drivers", "drivers", "drivers.view"), ("btn.trucks", "trucks", "fleet.view"),
             ("btn.approvals", "approvals", "approvals.view"), ("btn.overview", "overview", "overview.view")]
    for label, cmd, perm in pairs:
        if ctx.can(perm):
            a.append((label, f"cmd:{cmd}"))
    if ctx.can("tickets.create"):
        rows.append([("btn.new_ticket", "cmd:ticket")])
    is_driver = ctx.self_scoped and "driver" in ctx.roles
    extra = []
    if ctx.can("dispatch.view") or ctx.can("accounting.view") or is_driver:
        extra.append(("btn.loads", "cmd:loads"))
    if ctx.can("maintenance.create") or is_driver:
        extra.append(("btn.pti", "cmd:pti"))
    if ctx.can("eld_service.create") or is_driver:
        extra.append(("btn.eld_report", "cmd:eld"))
    if ctx.can("ai_agents.view"):
        extra.append(("btn.ai", "cmd:ai"))
    if extra:
        rows += [extra[i:i + 2] for i in range(0, len(extra), 2)]
    if is_driver:
        rows.append([("btn.status", "cmd:status")])
    rows += [a[i:i + 2] for i in range(0, len(a), 2)]
    rows.append([("btn.company", "cmd:mycompany"), ("btn.language", "cmd:language")])
    return kb(lang, rows)


def _company_name(s, ctx):
    c = s.get(Company, ctx.company_id) if ctx.company_id else None
    return c.name if c else "-"


# ------------------------------------------------------------------ /start and language (open to everyone)
async def cmd_start(update, context):
    chat, tg = update.effective_chat, update.effective_user
    if chat.type != "private" or tg is None or tg.is_bot:
        return
    with db.session_scope(db.NOSCOPE) as s:
        existed = access.get_user_by_tg(s, tg.id) is not None
        user = access.upsert_user(s, tg)
        lang = user.preferred_language
    if not existed:
        await say(context.bot, chat.id, t("en", "start.choose_lang") + "\n" + t("uz", "start.choose_lang").split("\n")[1],
                  lang_kb())
        return
    await send_home(update, context, context.args[0] if context.args else None)


async def send_home(update, context, payload=None):
    chat, tg = update.effective_chat, update.effective_user
    r = runtime.resolve(tg, chat)
    with db.session_scope(db.NOSCOPE) as s:
        user = access.get_user_by_tg(s, tg.id)
        lang, status, uid = user.preferred_language, user.status, user.id
        has_pending = s.scalar(select(RegistrationRequest.id).where(RegistrationRequest.user_id == uid,
                                                                    RegistrationRequest.status == "pending"))
    if status == "pending":
        rows = [] if has_pending else [[("btn.request_access", "ra:go")]]
        await say(context.bot, chat.id, t(lang, "start.pending" if has_pending else "start.new"),
                  kb(lang, rows) if rows else None)
        return
    if status in ("rejected", "suspended"):
        await say(context.bot, chat.id, t(lang, f"start.{status}"))
        return
    if r.reason != "ok":
        await runtime._reject(update, context, r, False)
        return
    if payload and payload.startswith("tk"):
        from . import tickets_h
        await tickets_h.cmd_ticket(update, context)
        return
    ctx = r.ctx
    with db.session_scope(db.NOSCOPE) as s:
        name = _company_name(s, ctx) if ctx.company_id else "-"
    await say(context.bot, chat.id, t(lang, "start.welcome", name=ctx.full_name, company=name),
              main_menu(ctx, lang))


async def cb_lang(update, context):
    q = update.callback_query
    code = q.data.split(":")[1]
    tg = q.from_user
    if code not in config.LANGUAGES:
        await answer(update)
        return
    with db.session_scope(db.NOSCOPE) as s:
        user = access.get_user_by_tg(s, tg.id)
        if user is None:
            await answer(update)
            return
        access.set_language(s, user, code)
    await answer(update)
    await show(update, context, t(code, "lang.set"))
    if update.effective_chat.type == "private":
        await send_home(update, context)


@command("language", need_company=False)
async def cmd_language(update, context, ctx, s):
    await answer(update)
    await reply(update, context, t(ctx.lang, "lang.pick"), lang_kb())


# ------------------------------------------------------------------ requesting access
async def cmd_request_access(update, context):
    chat, tg = update.effective_chat, update.effective_user
    if chat.type != "private":
        return
    await answer(update)
    with db.session_scope(db.NOSCOPE) as s:
        user = access.get_user_by_tg(s, tg.id)
        if user is None:
            await say(context.bot, chat.id, t("en", "start.unknown"))
            return
        lang, status = user.preferred_language, user.status
    if status == "active":
        await say(context.bot, chat.id, t(lang, "reg.already_active"))
        return
    runtime.set_state(tg.id, chat.id, "ra", {})
    await say(context.bot, chat.id, t(lang, "ra.ask"))


async def finish_request_access(update, context, text):
    chat, tg = update.effective_chat, update.effective_user
    runtime.clear_state(tg.id, chat.id)
    with db.session_scope(db.NOSCOPE) as s:
        user = access.get_user_by_tg(s, tg.id)
        lang = user.preferred_language
        ctx = anon_ctx(user)
        try:
            req, created = access.request_access(s, user, (text or "").split("\n")[0][:200], text)
            if created:
                access.notify_owners_of_request(s, ctx, req, user)
        except access.ServiceError as e:
            await say(context.bot, chat.id, t(lang, e.key))
            return
    await say(context.bot, chat.id, t(lang, "reg.sent" if created else "reg.already_pending"))
    await runtime.deliver(context, ctx.outbox)


# ------------------------------------------------------------------ menu, help, profile
@command("menu", need_company=False)
async def cmd_menu(update, context, ctx, s):
    await answer(update)
    title = t(ctx.lang, "menu.title", company=_company_name(s, ctx)) if ctx.company_id \
        else t(ctx.lang, "menu.no_company")
    await reply(update, context, title, main_menu(ctx, ctx.lang))


HELP = [("/menu", None), ("/ticket", "tickets.create"), ("/tickets", "tickets.view"), ("/mytickets", "tickets.view"),
        ("/status", None), ("/drivers", "drivers.view"), ("/adddriver Name", "drivers.create"),
        ("/trucks", "fleet.view"), ("/addtruck UNIT [VIN]", "fleet.create"), ("/loads", None), ("/newload", "dispatch.create"), ("/pti", None), ("/ptistatus", "maintenance.view"),
        ("/eld", None), ("/eldopen", "eld_service.view"), ("/approvals", "approvals.view"),
        ("/overview", "overview.view"), ("/report", "reports.view"), ("/users", "users_access.view"),
        ("/setrole ID role", "users_access.manage"), ("/removeuser ID", "users_access.manage"),
        ("/suspenduser ID reason", "users_access.manage"), ("/groupinfo", "telegram.view"),
        ("/linkgroup Company [type]", "telegram.link_group"), ("/updadmin", "telegram.update_admin"),
        ("/newcompany Name", "company.create"), ("/mycompany", None), ("/language", None), ("/profile", None),
        ("/ai", "ai_agents.view"), ("/airun", "ai_agents.create"), ("/billing", "billing.view"), ("/plan CODE", "owner"),
        ("/notifications", None), ("/2fa", None), ("/weblogout", None), ("/privacy", None), ("/cancel", None), ("/requests", "owner"),
        ("/grant ID perm", "owner"), ("/revoke ID perm", "owner"), ("/audit", "audit.view"),
        ("/suspendcompany reason", "companies.manage")]


@command("help", need_company=False)
async def cmd_help(update, context, ctx, s):
    lines = [t(ctx.lang, "help.title")]
    for text, perm in HELP:
        if perm is None or (perm == "owner" and ctx.is_owner) or (perm != "owner" and ctx.can(perm)):
            lines.append(text)
    await reply(update, context, "\n".join(lines))


@command("profile", need_company=False)
async def cmd_profile(update, context, ctx, s):
    roles = ", ".join(t(ctx.lang, "role." + r) for r in sorted(ctx.roles)) or "-"
    await reply(update, context, t(ctx.lang, "profile.text", name=ctx.full_name, lang=ctx.lang,
                                   company=_company_name(s, ctx), roles=roles))


@command("privacy", need_company=False)
async def cmd_privacy(update, context, ctx, s):
    await reply(update, context, t(ctx.lang, "privacy.text"))


async def cmd_cancel(update, context):
    chat, tg = update.effective_chat, update.effective_user
    action, _ = runtime.get_state(tg.id, chat.id)
    runtime.clear_state(tg.id, chat.id)
    with db.session_scope(db.NOSCOPE) as s:
        user = access.get_user_by_tg(s, tg.id)
        lang = user.preferred_language if user else config.DEFAULT_LANGUAGE
    await say(context.bot, chat.id, t(lang, "cancel.done" if action else "cancel.nothing"))


# ------------------------------------------------------------------ companies the user belongs to
@command("mycompany", need_company=False, dm_only=True)
async def cmd_mycompany(update, context, ctx, s):
    await answer(update)
    companies = access.list_companies(ctx, s)
    if not companies:
        await reply(update, context, t(ctx.lang, "company.none"))
        return
    rows = [[(("✅ " if c.id == ctx.company_id else "") + c.name, f"co:{c.id.hex[:8]}")] for c in companies[:20]]
    await reply(update, context, t(ctx.lang, "company.pick"), kb(ctx.lang, rows))


@secured(need_company=False, dm_only=True)
async def cb_company(update, context, ctx, s):
    c = access.company_by_prefix(ctx, s, update.callback_query.data.split(":")[1])
    if c is None:
        await answer(update)
        return
    access.set_active_company(ctx, s, s.get(User, ctx.user_id), c.id)
    await answer(update)
    await show(update, context, t(ctx.lang, "company.switched", name=c.name))


# ------------------------------------------------------------------ notifications inbox
@command("notifications", need_company=False, dm_only=True)
async def cmd_notifications(update, context, ctx, s):
    await answer(update)
    rows = list(s.scalars(select(Notification).where(Notification.user_id == ctx.user_id)
                          .order_by(Notification.created_at.desc()).limit(10)))
    if not rows:
        await reply(update, context, t(ctx.lang, "notif.none"))
        return
    lines = [t(ctx.lang, "notif.title")] + [("• " if n.is_read else "🔔 ") + t(ctx.lang, n.key, **(n.params or {}))
                                             for n in rows]
    await reply(update, context, "\n".join(lines), kb(ctx.lang, [[("btn.read_all", "nr:all")]]))


@secured(need_company=False, dm_only=True)
async def cb_notif_read(update, context, ctx, s):
    for n in s.scalars(select(Notification).where(Notification.user_id == ctx.user_id,
                                                  Notification.is_read.is_(False))):
        n.is_read = True
    await answer(update, "✔")


async def cb_command(update, context):
    """Menu buttons run the same command handler (which does its own permission check)."""
    name = update.callback_query.data.split(":")[1]
    handler = runtime.COMMANDS.get(name)
    await answer(update)
    if handler is not None:
        await handler(update, context)
