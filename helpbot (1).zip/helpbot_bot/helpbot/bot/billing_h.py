"""/billing (company admins and the Owner) and /plan (Owner only)."""
from ..i18n import t
from ..models import Company
from ..services import billing as svc
from .runtime import answer, command, reply


def billing_text(ctx, s):
    e = svc.effective(s, ctx.company_id)
    u = svc.usage(s, ctx.company_id)
    lim = e["limits"]
    text = t(ctx.lang, "billing.title", company=s.get(Company, ctx.company_id).name, plan=e["plan"].name,
             bstatus=e["status"], end=f"{e['period_end']:%Y-%m-%d}" if e["period_end"] else "-",
             d=u["drivers"], dl=lim["drivers"], t=u["trucks"], tl=lim["trucks"], u=u["users"], ul=lim["users"])
    if e["readonly"]:
        text += "\n" + t(ctx.lang, "billing.readonly_note")
    return text


@command("billing", "billing.view")
async def cmd_billing(update, context, ctx, s):
    await answer(update)
    await reply(update, context, billing_text(ctx, s))


@command("plan", owner_only=True)
async def cmd_plan(update, context, ctx, s):
    a = context.args or []
    if not a:
        await reply(update, context, t(ctx.lang, "billing.plan_usage"))
        return
    days = int(a[1]) if len(a) > 1 and a[1].isdigit() else 30
    svc.set_plan(ctx, s, ctx.company_id, a[0], days)
    await reply(update, context, t(ctx.lang, "billing.plan_set", plan=a[0]) + "\n" + billing_text(ctx, s))
