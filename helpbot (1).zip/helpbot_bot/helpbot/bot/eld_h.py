"""ELD problems: a driver (or the ELD team) reports; the 8-day limit is tracked."""
import uuid

from ..i18n import t
from ..services import eld as svc, fleet
from . import runtime
from .runtime import answer, command, kb, reply, run_as, secured, show


@command("eld")
async def cmd_eld(update, context, ctx, s):
    await answer(update)
    tg, chat = update.effective_user, update.effective_chat
    if chat.type != "private":
        await reply(update, context, t(ctx.lang, "err.dm_only"))
        return
    if ctx.can("eld_service.create"):
        rows = [[(d.full_name, f"ed:{d.id.hex[:8]}")] for d in fleet.list_drivers(ctx, s)[:25]]
        await reply(update, context, t(ctx.lang, "eld.pick_driver"), kb(ctx.lang, rows) if rows else None)
        return
    d = fleet.my_driver(ctx, s)                      # a driver reports for himself
    runtime.set_state(tg.id, chat.id, "eld_new", {"company": ctx.company_id.hex, "driver": d.id.hex})
    await reply(update, context, t(ctx.lang, "eld.ask"))


@secured("eld_service.create", dm_only=True)
async def cb_pick_driver(update, context, ctx, s):
    d = fleet.driver_by_prefix(ctx, s, update.callback_query.data.split(":")[1])
    await answer(update)
    tg, chat = update.effective_user, update.effective_chat
    runtime.set_state(tg.id, chat.id, "eld_new", {"company": ctx.company_id.hex, "driver": d.id.hex})
    await reply(update, context, t(ctx.lang, "eld.ask"))


async def finish_report(update, context, data):
    tg, chat = update.effective_user, update.effective_chat
    fault = (update.effective_message.text or "").strip()

    async def work(update, context, ctx, s):
        m, tk = svc.report_malfunction(ctx, s, uuid.UUID(data["driver"]), fault)
        runtime.clear_state(tg.id, chat.id)
        await reply(update, context, t(ctx.lang, "eld.reported", n=tk.ticket_number,
                                       deadline=f"{svc.deadline(m):%Y-%m-%d}"))

    await run_as(update, context, work, uuid.UUID(data["company"]))


@command("eldopen", "eld_service.view")
async def cmd_open(update, context, ctx, s):
    await answer(update)
    rows = svc.list_open(ctx, s)
    if not rows:
        await reply(update, context, t(ctx.lang, "eld.none"))
        return
    await reply(update, context, t(ctx.lang, "eld.open_title"))
    for m, name in rows[:10]:
        text = t(ctx.lang, "eld.line", driver=name, since=f"{m.started_at:%m-%d}",
                 deadline=f"{svc.deadline(m):%Y-%m-%d}")
        markup = kb(ctx.lang, [[("btn.resolve", f"er:{m.id.hex[:8]}")]]) if ctx.can("eld_service.edit") else None
        await reply(update, context, text, markup)


@secured("eld_service.edit")
async def cb_resolve(update, context, ctx, s):
    svc.resolve(ctx, s, svc.by_prefix(ctx, s, update.callback_query.data.split(":")[1]))
    await answer(update)
    await show(update, context, t(ctx.lang, "eld.resolved"))
