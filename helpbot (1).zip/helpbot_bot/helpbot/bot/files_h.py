"""Photos and PDFs sent in a private chat: attached to the record the user is working on (BOL/POD/PTI)."""
import uuid

from .. import db
from ..i18n import t
from ..services import access, documents, pti as pti_svc
from . import runtime
from .runtime import kb, reply, run_as

MAX_BYTES = 20 * 1024 * 1024


def extract(msg):
    """(file_ref, name, mime, size) of an accepted photo/PDF, else None. Never trust the file name for anything."""
    if msg.photo:
        p = msg.photo[-1]
        return p.file_id, None, "image/jpeg", p.file_size
    d = msg.document
    if d and ((d.mime_type or "").startswith("image/") or d.mime_type == "application/pdf"):
        if d.file_size is None or d.file_size <= MAX_BYTES:
            return d.file_id, d.file_name, d.mime_type, d.file_size
    return None


async def on_file(update, context):
    chat, tg, msg = update.effective_chat, update.effective_user, update.effective_message
    if chat.type != "private" or tg is None or tg.is_bot or msg is None:
        return
    action, data = runtime.get_state(tg.id, chat.id)
    if action not in ("doc_wait", "pti_photos"):
        return
    f = extract(msg)
    if f is None:
        with db.session_scope(db.NOSCOPE) as s:
            lang = access.get_user_by_tg(s, tg.id).preferred_language
        await reply(update, context, t(lang, "doc.bad_file"))
        return
    ref, name, mime, size = f
    company = uuid.UUID(data["company"])

    async def work(update, context, ctx, s):
        if action == "doc_wait":
            documents.add_document(ctx, s, data["type"], data["related_type"], uuid.UUID(data["related"]), ref, name,
                                   mime, size)
            runtime.clear_state(tg.id, chat.id)
            await reply(update, context, t(ctx.lang, "doc.saved", doctype=data["type"]))
            return
        req = pti_svc.by_prefix(ctx, s, data["req"])
        pti_svc.attach_photo(ctx, s, req, ref, name, mime, size)
        n = pti_svc.photo_count(ctx, s, req)
        mg = msg.media_group_id
        if mg and data.get("mg") == mg:                    # one reply per album, not per photo
            return
        data["mg"] = mg
        runtime.set_state(tg.id, chat.id, "pti_photos", data)
        await reply(update, context, t(ctx.lang, "pti.saved", n=n), kb(ctx.lang, [[("btn.done_sending", "pt:done")]]))

    await run_as(update, context, work, company)
