"""Drivers, trucks, assignments and the driver's own /status."""
import uuid

from ..i18n import t
from ..services import fleet, reports
from ..services.errors import ServiceError
from . import runtime
from .runtime import answer, command, kb, reply, run_as, secured, show


def _fmt_summary(ctx, mapping, prefix):
    return ", ".join(f"{t(ctx.lang, prefix + k)} {v}" for k, v in mapping.items()) or "-"


def _driver_view(ctx, s, d):
    cur = fleet.current_assignment(ctx, s, d.id)
    hist = []
    for h in fleet.status_history(ctx, s, d.id):
        hist.append(t(ctx.lang, "drv.hist_line", when=f"{h.created_at:%m-%d}", dstatus=h.to_status,
                      reason=f" — {h.reason}" if h.reason and h.reason != "created" else ""))
    text = t(ctx.lang, "drv.view", name=d.full_name, dstatus=d.status, truck=cur[1].unit_number if cur else "-",
             phone=d.phone or "-", history="\n".join(hist) or "-")
    p, rows = d.id.hex[:8], []
    if ctx.can("drivers.edit"):
        sts = [(f"dstatus.{st}", f"ds:{p}:{i}") for i, st in enumerate(fleet.DRIVER_STATUSES) if st != d.status]
        rows += [sts[i:i + 2] for i in range(0, len(sts), 2)]
    if ctx.can("fleet.assign"):
        rows.append([("btn.assign_truck", f"da:{p}")] + ([("btn.unassign", f"du:{p}")] if cur else []))
    return text, kb(ctx.lang, rows)


# ------------------------------------------------------------------ drivers
@command("drivers", "drivers.view")
async def cmd_drivers(update, context, ctx, s):
    await answer(update)
    rows = fleet.list_drivers(ctx, s, (context.args or [None])[0])
    if not rows:
        await reply(update, context, t(ctx.lang, "drv.none"))
        return
    buttons = [[(f"{d.full_name} · {t(ctx.lang, 'dstatus.' + d.status)}", f"dv:{d.id.hex[:8]}")] for d in rows[:25]]
    await reply(update, context, t(ctx.lang, "drv.title"), kb(ctx.lang, buttons))


@command("adddriver", "drivers.create")
async def cmd_adddriver(update, context, ctx, s):
    a = context.args or []
    if not a:
        await reply(update, context, t(ctx.lang, "drv.usage"))
        return
    phone = a[-1] if len(a) > 1 and any(ch.isdigit() for ch in a[-1]) else None
    name = " ".join(a[:-1] if phone else a)
    d = fleet.add_driver(ctx, s, name, phone)
    await reply(update, context, t(ctx.lang, "drv.created", name=d.full_name))


@secured("drivers.view")
async def cb_driver(update, context, ctx, s):
    d = fleet.driver_by_prefix(ctx, s, update.callback_query.data.split(":")[1])
    await answer(update)
    text, markup = _driver_view(ctx, s, d)
    await show(update, context, text, markup)


@secured("drivers.edit", dm_only=True)
async def cb_driver_status(update, context, ctx, s):
    _, prefix, idx = update.callback_query.data.split(":")
    d = fleet.driver_by_prefix(ctx, s, prefix)
    await answer(update)
    if not idx.isdigit() or int(idx) >= len(fleet.DRIVER_STATUSES):
        return
    tg, chat = update.effective_user, update.effective_chat
    runtime.set_state(tg.id, chat.id, "ds_reason", {"driver": d.id.hex, "status": fleet.DRIVER_STATUSES[int(idx)],
                                                    "company": ctx.company_id.hex})
    await reply(update, context, t(ctx.lang, "drv.ask_reason"))


async def finish_driver_status(update, context, data):
    tg, chat = update.effective_user, update.effective_chat
    reason = (update.effective_message.text or "").strip()

    async def work(update, context, ctx, s):
        d, ap = fleet.change_driver_status(ctx, s, uuid.UUID(data["driver"]), data["status"], reason)
        runtime.clear_state(tg.id, chat.id)
        await reply(update, context, t(ctx.lang, "drv.needs_approval") if ap else
                    t(ctx.lang, "drv.status_set", dstatus=d.status))

    await run_as(update, context, work, uuid.UUID(data["company"]), "drivers.edit")


# ------------------------------------------------------------------ assignments
@secured("fleet.assign")
async def cb_assign_pick(update, context, ctx, s):
    """Button 'Assign truck' on a driver: choose the truck."""
    d = fleet.driver_by_prefix(ctx, s, update.callback_query.data.split(":")[1])
    await answer(update)
    trucks = [x for x in fleet.list_trucks(ctx, s) if x.status == "active"]
    if not trucks:
        await reply(update, context, t(ctx.lang, "trk.none"))
        return
    rows = [[(x.unit_number, f"at:{d.id.hex[:8]}:{x.id.hex[:8]}")] for x in trucks[:25]]
    await show(update, context, t(ctx.lang, "trk.pick"), kb(ctx.lang, rows))


@secured("fleet.assign", dm_only=True)
async def cb_assign_truck(update, context, ctx, s):
    _, dp, tp = update.callback_query.data.split(":")
    d, trk = fleet.driver_by_prefix(ctx, s, dp), fleet.truck_by_prefix(ctx, s, tp)
    await answer(update)
    tg, chat = update.effective_user, update.effective_chat
    runtime.set_state(tg.id, chat.id, "as_reason", {"driver": d.id.hex, "truck": trk.id.hex,
                                                    "company": ctx.company_id.hex})
    await reply(update, context, t(ctx.lang, "assign.ask_reason"))


async def finish_assignment(update, context, data):
    tg, chat = update.effective_user, update.effective_chat
    reason = (update.effective_message.text or "").strip()

    async def work(update, context, ctx, s):
        a, ap = fleet.assign_truck(ctx, s, uuid.UUID(data["driver"]), uuid.UUID(data["truck"]), reason)
        runtime.clear_state(tg.id, chat.id)
        await reply(update, context, t(ctx.lang, "appr.requested") if ap else t(ctx.lang, "assign.done"))

    await run_as(update, context, work, uuid.UUID(data["company"]), "fleet.assign")


@secured("fleet.assign", dm_only=True)
async def cb_unassign(update, context, ctx, s):
    d = fleet.driver_by_prefix(ctx, s, update.callback_query.data.split(":")[1])
    await answer(update)
    tg, chat = update.effective_user, update.effective_chat
    runtime.set_state(tg.id, chat.id, "un_reason", {"driver": d.id.hex, "company": ctx.company_id.hex})
    await reply(update, context, t(ctx.lang, "assign.ask_reason"))


async def finish_unassign(update, context, data):
    tg, chat = update.effective_user, update.effective_chat
    reason = (update.effective_message.text or "").strip()

    async def work(update, context, ctx, s):
        fleet.unassign_truck(ctx, s, uuid.UUID(data["driver"]), reason)
        runtime.clear_state(tg.id, chat.id)
        await reply(update, context, t(ctx.lang, "assign.unassigned"))

    await run_as(update, context, work, uuid.UUID(data["company"]), "fleet.assign")


# ------------------------------------------------------------------ trucks
@command("trucks", "fleet.view")
async def cmd_trucks(update, context, ctx, s):
    await answer(update)
    rows = fleet.list_trucks(ctx, s)
    if not rows:
        await reply(update, context, t(ctx.lang, "trk.none"))
        return
    buttons = [[(t(ctx.lang, "trk.line", unit=x.unit_number, tstatus=x.status), f"tr:{x.id.hex[:8]}")] for x in rows[:25]]
    await reply(update, context, t(ctx.lang, "trk.title"), kb(ctx.lang, buttons))


@command("addtruck", "fleet.create")
async def cmd_addtruck(update, context, ctx, s):
    a = context.args or []
    if not a:
        await reply(update, context, t(ctx.lang, "trk.usage"))
        return
    x = fleet.add_truck(ctx, s, a[0], a[1] if len(a) > 1 else None)
    await reply(update, context, t(ctx.lang, "trk.created", unit=x.unit_number))


@secured("fleet.view")
async def cb_truck(update, context, ctx, s):
    x = fleet.truck_by_prefix(ctx, s, update.callback_query.data.split(":")[1])
    await answer(update)
    rows = []
    if ctx.can("fleet.edit"):
        sts = [(f"tstatus.{st}", f"ts:{x.id.hex[:8]}:{i}") for i, st in enumerate(fleet.TRUCK_STATUSES) if st != x.status]
        rows = [sts[i:i + 2] for i in range(0, len(sts), 2)]
    await show(update, context, t(ctx.lang, "trk.view", unit=x.unit_number, vin=x.vin or "-", tstatus=x.status),
               kb(ctx.lang, rows) if rows else None)


@secured("fleet.edit")
async def cb_truck_status(update, context, ctx, s):
    _, prefix, idx = update.callback_query.data.split(":")
    x = fleet.truck_by_prefix(ctx, s, prefix)
    if not idx.isdigit() or int(idx) >= len(fleet.TRUCK_STATUSES):
        await answer(update)
        return
    x = fleet.change_truck_status(ctx, s, x.id, fleet.TRUCK_STATUSES[int(idx)])
    await answer(update)
    await show(update, context, t(ctx.lang, "trk.status_set", tstatus=x.status))


# ------------------------------------------------------------------ /status (driver: own profile, staff: summary)
@command("status")
async def cmd_status(update, context, ctx, s):
    await answer(update)
    if ctx.self_scoped:
        d, truck = fleet.my_status(ctx, s)
        await reply(update, context, t(ctx.lang, "drv.my_status", name=d.full_name, dstatus=d.status,
                                       truck=truck.unit_number if truck else "-"))
        return
    await send_overview(update, context, ctx, s)


async def send_overview(update, context, ctx, s):
    from .basic import _company_name
    data = reports.overview(ctx, s)
    lines = [t(ctx.lang, "ov.title", company=_company_name(s, ctx)),
             t(ctx.lang, "ov.open_tickets", n=data["open_tickets"])]
    if "drivers" in data:
        lines.append(t(ctx.lang, "ov.drivers", text=_fmt_summary(ctx, data["drivers"], "dstatus.")))
    if "trucks" in data:
        lines.append(t(ctx.lang, "ov.trucks", text=_fmt_summary(ctx, data["trucks"], "tstatus.")))
    if "pending_approvals" in data:
        lines.append(t(ctx.lang, "ov.pending", n=data["pending_approvals"]))
    await reply(update, context, "\n".join(lines))


@command("overview", "overview.view")
async def cmd_overview(update, context, ctx, s):
    await answer(update)
    await send_overview(update, context, ctx, s)


@command("report", "reports.view")
async def cmd_report(update, context, ctx, s):
    from .basic import _company_name
    await answer(update)
    data = reports.report(ctx, s)
    lines = [t(ctx.lang, "rep.title", company=_company_name(s, ctx)),
             t(ctx.lang, "rep.by_status", text=_fmt_summary(ctx, data["tickets_by_status"], "tkstatus.")),
             t(ctx.lang, "rep.by_cat", text=_fmt_summary(ctx, data["tickets_by_category"], "cat."))]
    await reply(update, context, "\n".join(lines))
