"""Routes free-text messages to the multi-step flow the user is currently in (private chats only)."""
from . import basic, eld_h, fleet_h, loads_h, runtime, tickets_h


async def on_text(update, context):
    chat, tg, msg = update.effective_chat, update.effective_user, update.effective_message
    if chat.type != "private" or tg is None or tg.is_bot or not msg or not msg.text:
        return
    action, data = runtime.get_state(tg.id, chat.id)
    if not action:
        return
    if action == "ra":
        await basic.finish_request_access(update, context, msg.text)
    elif action == "tk_subject":
        await tickets_h.st_subject(update, context, data)
    elif action == "tk_desc":
        await tickets_h.st_description(update, context, data)
    elif action in ("tk_reply", "tk_note"):
        await tickets_h.finish_message(update, context, data, internal=(action == "tk_note"))
    elif action == "tk_reason":
        await tickets_h.finish_reopen(update, context, data)
    elif action == "ds_reason":
        await fleet_h.finish_driver_status(update, context, data)
    elif action == "as_reason":
        await fleet_h.finish_assignment(update, context, data)
    elif action == "un_reason":
        await fleet_h.finish_unassign(update, context, data)
    elif action in ("ld_number", "ld_pickup", "ld_delivery", "ld_broker"):
        await loads_h.st_load_step(update, context, action, data)
    elif action == "eld_new":
        await eld_h.finish_report(update, context, data)
