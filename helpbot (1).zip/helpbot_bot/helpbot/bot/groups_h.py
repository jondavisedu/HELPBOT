"""Telegram groups: link a group to ONE company, roster refresh, bot added/removed."""
from sqlalchemy import select

from .. import db
from ..i18n import t
from ..models import Company
from ..rbac import build_ctx
from ..services import access, groups
from ..services.errors import ServiceError
from . import runtime
from .runtime import answer, command, reply, say


def _split_args(args):
    """/linkgroup Company Name [type]"""
    args = list(args or [])
    gtype = "operations"
    if args and args[-1].lower() in groups.GROUP_TYPES and len(args) > 1:
        gtype = args.pop().lower()
    return " ".join(args), gtype


async def cmd_linkgroup(update, context):
    """Works in a group that is NOT linked yet, so it cannot use the normal group resolution.
    The caller must be an approved user; the service then requires the Owner or the explicit grant."""
    chat, tg = update.effective_chat, update.effective_user
    if chat.type not in ("group", "supergroup"):
        r = runtime.resolve(tg, chat)
        if r.ctx:
            await reply(update, context, t(r.ctx.lang, "group.use_in_group"))
        return
    r = runtime.resolve(tg, chat, ignore_group=True)
    if r.reason != "ok" or r.ctx is None:
        return                                                      # strangers get no answer
    name, gtype = _split_args(context.args)
    lang = r.ctx.lang
    if not name:
        await reply(update, context, t(lang, "group.usage"))
        return
    with db.session_scope(db.NOSCOPE) as s:
        company = access.company_by_name(r.ctx, s, name)
    if company is None:
        runtime._record_denied(r.ctx, "telegram.link_group", update)
        await reply(update, context, t(lang, "err.denied"))
        return
    r2 = runtime.resolve(tg, chat, company_override=company.id, ignore_group=True)
    ctx = r2.ctx
    if r2.reason != "ok" or ctx is None or ctx.company_id != company.id:
        await reply(update, context, t(lang, "err.denied"))
        return

    async def work(update, context, ctx, s):
        groups.link_group(ctx, s, chat.id, chat.title or "", gtype)
        await reply(update, context, t(ctx.lang, "group.linked", company=company.name, gtype=gtype))

    await runtime._run(work, update, context, ctx)


@command("unlinkgroup", "telegram.link_group")
async def cmd_unlinkgroup(update, context, ctx, s):
    groups.unlink_group(ctx, s, update.effective_chat.id)
    await reply(update, context, t(ctx.lang, "group.unlinked"))


@command("groupinfo", "telegram.view")
async def cmd_groupinfo(update, context, ctx, s):
    if update.effective_chat.type == "private":
        await reply(update, context, t(ctx.lang, "group.use_in_group"))
        return
    info = groups.resolve_group(update.effective_chat.id)
    admins = groups.group_admins(ctx, s, update.effective_chat.id)
    company = s.get(Company, ctx.company_id)
    await reply(update, context, t(ctx.lang, "group.info", title=info[2] or "-", company=company.name,
                                   gtype=info[1], n=len(admins)))


@command("updadmin", "telegram.update_admin", group_ok=True)
async def cmd_updadmin(update, context, ctx, s):
    """Refresh the roster of Telegram admins of THIS verified group. It never grants anything."""
    chat = update.effective_chat
    if chat.type == "private":
        await reply(update, context, t(ctx.lang, "group.use_in_group"))
        return
    members = await context.bot.get_chat_administrators(chat.id)
    roster = [(m.user.id, m.user.full_name, m.status == "creator") for m in members if not m.user.is_bot]
    total, known = groups.update_admins(ctx, s, chat.id, roster)
    await reply(update, context, t(ctx.lang, "group.admins_updated", total=total, known=known))


async def on_my_chat_member(update, context):
    """The bot was added to / removed from a chat."""
    cm = update.my_chat_member
    chat = cm.chat
    if chat.type not in ("group", "supergroup"):
        return
    new = cm.new_chat_member.status
    owners_text = None
    if new in ("left", "kicked"):
        if groups.deactivate_if_linked(chat.id, "bot removed") is not None:
            owners_text = "group.bot_removed"
    elif cm.old_chat_member.status in ("left", "kicked") and groups.resolve_group(chat.id) is None:
        owners_text = "group.bot_added"
    if owners_text:
        with db.session_scope(db.NOSCOPE) as s:
            for o in access.owners(s):
                await say(context.bot, o.telegram_user_id,
                          t(o.preferred_language, owners_text, title=chat.title or "-", chat=chat.id))
