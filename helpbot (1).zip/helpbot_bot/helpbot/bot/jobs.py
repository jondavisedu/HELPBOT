"""Scheduled work: reminders for unassigned tickets, expiring stale approvals."""
import logging

from .. import db
from ..i18n import t
from ..services import ai, approvals, eld, groups, tickets
from .. import config as cfg
from .runtime import say

log = logging.getLogger("helpbot")


async def ticket_reminders(context):
    with db.platform_session("reminder job: due tickets") as s:
        due = [(tk.company_id, tk.category, tk.ticket_number, tk.subject) for tk in tickets.due_reminders(s)]
    for company_id, category, number, subject in due:
        with db.session_scope(company_id) as s:
            chat_id = groups.group_chat_for(s, company_id, "operations" if category == "other" else category)
        if chat_id:
            from ..rbac import CONFIDENTIAL_CATEGORIES
            shown = "🔒" if category in CONFIDENTIAL_CATEGORIES else subject
            await say(context.bot, chat_id, t(cfg.DEFAULT_LANGUAGE, "tk.unassigned_reminder", n=number, subject=shown))


async def expire_approvals(context):
    with db.platform_session("job: expire stale approvals") as s:
        n = approvals.expire_stale(s)
    if n:
        log.info("expired %s approvals", n)


async def eld_deadlines(context):
    with db.platform_session("job: ELD malfunction deadlines") as s:
        due = eld.due_reminders(s)
    for company_id, driver, days, deadline in due:
        for gtype in ("eld", "safety"):
            with db.session_scope(company_id) as s:
                chat_id = groups.group_chat_for(s, company_id, gtype)
            if chat_id:
                await say(context.bot, chat_id, t(cfg.DEFAULT_LANGUAGE, "eld.reminder", driver=driver, days=days,
                                                  deadline=deadline))


async def ai_daily(context):
    """Once a day: let the agents prepare suggestions for every company that switched AI on."""
    with db.platform_session("job: list companies with AI enabled") as s:
        companies = ai.enabled_company_ids(s)
    for company_id in companies:
        try:
            with db.session_scope(company_id) as s:
                ai.run_for_company(s, company_id)
        except Exception:
            log.exception("AI daily run failed for one company")
