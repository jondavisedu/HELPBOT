"""Dispatch loads: guided creation, list, details, status, driver assignment, BOL/POD upload requests."""
import uuid

from .. import db
from ..i18n import t
from ..rbac import PermissionDenied
from ..services import access, documents, fleet, loads as svc
from . import runtime
from .runtime import answer, command, kb, reply, run_as, secured, show


def _money(cents):
    return "-" if cents is None else f"${cents / 100:,.2f}"


def view(ctx, s, ld):
    from ..models import Driver
    d = s.get(Driver, ld.driver_id) if ld.driver_id else None
    can_docs = ctx.can("dispatch.view") or ctx.can("accounting.view") or ctx.can("documents.view")
    docs = documents.list_documents(ctx, s, "load", ld.id) if can_docs else []
    text = t(ctx.lang, "load.view", number=ld.load_number, lstatus=ld.status, broker=ld.broker or "-",
             pickup=ld.pickup_address or "-", delivery=ld.delivery_address or "-", driver=d.full_name if d else "-",
             rate=_money(ld.rate_cents) if svc.rate_visible(ctx) else "—",
             docs=", ".join(sorted({x.doc_type for x in docs})) or "-")
    n, rows = ld.load_number, []
    moves = [(f"lstatus.{st}", f"ls:{n}:{svc.STATUSES.index(st)}") for st in svc.TRANSITIONS[ld.status]]
    if moves:
        rows += [moves[i:i + 2] for i in range(0, len(moves), 2)]
    rows.append([("btn.add_bol", f"lf:{n}:BOL"), ("btn.add_pod", f"lf:{n}:POD")])
    if ctx.can("dispatch.assign"):
        rows.append([("btn.assign_driver", f"lg:{n}")])
    return text, kb(ctx.lang, rows)


@command("loads")
async def cmd_loads(update, context, ctx, s):
    await answer(update)
    rows = svc.list_loads(ctx, s, "active")
    if not rows:
        await reply(update, context, t(ctx.lang, "load.none"))
        return
    buttons = [[(t(ctx.lang, "load.line", number=x.load_number, lstatus=x.status,
                   delivery=x.delivery_address or "-")[:60], f"ld:{x.load_number}")] for x in rows]
    await reply(update, context, t(ctx.lang, "load.title"), kb(ctx.lang, buttons))


@command("load")
async def cmd_load(update, context, ctx, s):
    if not context.args:
        await reply(update, context, t(ctx.lang, "load.usage"))
        return
    ld = svc.get_by_number(ctx, s, context.args[0])
    text, markup = view(ctx, s, ld)
    await reply(update, context, text, markup)


@secured()
async def cb_load(update, context, ctx, s):
    ld = svc.get_by_number(ctx, s, update.callback_query.data.split(":")[1])
    await answer(update)
    text, markup = view(ctx, s, ld)
    await show(update, context, text, markup)


@secured()
async def cb_load_status(update, context, ctx, s):
    _, number, idx = update.callback_query.data.split(":")
    if not idx.isdigit() or int(idx) >= len(svc.STATUSES):
        await answer(update)
        return
    ld = svc.change_status(ctx, s, number, svc.STATUSES[int(idx)])
    await answer(update)
    text, markup = view(ctx, s, ld)
    await show(update, context, text, markup)


@secured("dispatch.assign")
async def cb_load_pick_driver(update, context, ctx, s):
    number = update.callback_query.data.split(":")[1]
    svc.get_by_number(ctx, s, number)
    await answer(update)
    rows = [[(d.full_name, f"la:{number}:{d.id.hex[:8]}")] for d in fleet.list_drivers(ctx, s, "active")[:25]]
    await show(update, context, t(ctx.lang, "load.pick_driver"), kb(ctx.lang, rows) if rows else None)


@secured("dispatch.assign")
async def cb_load_assign(update, context, ctx, s):
    _, number, prefix = update.callback_query.data.split(":")
    d = fleet.driver_by_prefix(ctx, s, prefix)
    ld = svc.assign_driver(ctx, s, number, d.id)
    await answer(update)
    text, markup = view(ctx, s, ld)
    await show(update, context, text, markup)


@secured(dm_only=True)
async def cb_load_file(update, context, ctx, s):
    _, number, doc_type = update.callback_query.data.split(":")
    ld = svc.get_by_number(ctx, s, number)
    if not documents.can_attach(ctx, s, doc_type, "load", ld.id):
        raise PermissionDenied("documents.create")
    await answer(update)
    tg, chat = update.effective_user, update.effective_chat
    runtime.set_state(tg.id, chat.id, "doc_wait", {"company": ctx.company_id.hex, "type": doc_type,
                                                   "related_type": "load", "related": ld.id.hex})
    await reply(update, context, t(ctx.lang, "doc.ask_file", doctype=doc_type))


# ------------------------------------------------------------------ guided creation
@command("newload", "dispatch.create", dm_only=True)
async def cmd_newload(update, context, ctx, s):
    await answer(update)
    tg, chat = update.effective_user, update.effective_chat
    runtime.set_state(tg.id, chat.id, "ld_number", {"company": ctx.company_id.hex})
    await reply(update, context, t(ctx.lang, "load.ask_number"))


def _lang(tg_id):
    with db.session_scope(db.NOSCOPE) as s:
        return access.get_user_by_tg(s, tg_id).preferred_language


async def st_load_step(update, context, action, data):
    tg, chat = update.effective_user, update.effective_chat
    text = (update.effective_message.text or "").strip()
    nxt = {"ld_number": ("number", "ld_pickup", "load.ask_pickup"),
           "ld_pickup": ("pickup", "ld_delivery", "load.ask_delivery"),
           "ld_delivery": ("delivery", "ld_broker", "load.ask_broker")}
    if action in nxt:
        key, new_action, prompt = nxt[action]
        data[key] = text[:300]
        runtime.set_state(tg.id, chat.id, new_action, data)
        lang = _lang(tg.id)
        rows = [[("btn.skip", "lb:skip")]] if new_action == "ld_broker" else None
        await runtime.say(context.bot, chat.id, t(lang, prompt), kb(lang, rows) if rows else None)
        return
    await finish_load(update, context, data, text)


async def finish_load(update, context, data, broker):
    tg, chat = update.effective_user, update.effective_chat

    async def work(update, context, ctx, s):
        ld = svc.create_load(ctx, s, data["number"], data.get("pickup"), data.get("delivery"), broker or None)
        runtime.clear_state(tg.id, chat.id)
        text, markup = view(ctx, s, ld)
        await reply(update, context, t(ctx.lang, "load.created", number=ld.load_number) + "\n\n" + text, markup)

    await run_as(update, context, work, uuid.UUID(data["company"]), "dispatch.create")


async def cb_skip_broker(update, context):
    tg, chat = update.effective_user, update.effective_chat
    action, data = runtime.get_state(tg.id, chat.id)
    await answer(update)
    if action == "ld_broker":
        await finish_load(update, context, data, None)
