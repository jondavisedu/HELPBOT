"""PTI: maintenance requests, drivers send photos, maintenance approves or asks for a redo."""
import uuid

from ..i18n import t
from ..services import fleet, pti as svc
from . import runtime
from .runtime import answer, command, kb, reply, run_as, secured, show


@command("pti")
async def cmd_pti(update, context, ctx, s):
    await answer(update)
    if ctx.can("maintenance.create"):
        drivers = [d for d in fleet.list_drivers(ctx, s) if d.status in ("active", "returned")][:15]
        rows = [[("btn.pti_all", "pq:all")]] + [[(d.full_name, f"pq:{d.id.hex[:8]}")] for d in drivers]
        await reply(update, context, t(ctx.lang, "pti.pick"), kb(ctx.lang, rows))
        return
    mine = svc.my_open_requests(ctx, s)
    if not mine:
        await reply(update, context, t(ctx.lang, "pti.none_pending"))
        return
    await reply(update, context, t(ctx.lang, "pti.requested"),
                kb(ctx.lang, [[("btn.pti_start", f"pt:go:{mine[0].id.hex[:8]}")]]))


@secured("maintenance.create")
async def cb_request(update, context, ctx, s):
    who = update.callback_query.data.split(":")[1]
    ids = None if who == "all" else [fleet.driver_by_prefix(ctx, s, who).id]
    reqs = svc.request_pti(ctx, s, ids)
    await answer(update)
    await show(update, context, t(ctx.lang, "pti.sent", n=len(reqs)))


async def cb_start(update, context):
    """'Start PTI' button (arrives in the driver's private chat): the company comes from the request itself."""
    prefix = update.callback_query.data.split(":")[2]
    company_id = svc.request_company(prefix)
    await answer(update)
    if company_id is None:
        return

    async def work(update, context, ctx, s):
        svc.by_prefix(ctx, s, prefix)
        tg, chat = update.effective_user, update.effective_chat
        runtime.set_state(tg.id, chat.id, "pti_photos", {"company": ctx.company_id.hex, "req": prefix})
        await reply(update, context, t(ctx.lang, "pti.ask_photos"), kb(ctx.lang, [[("btn.done_sending", "pt:done")]]))

    await run_as(update, context, work, company_id)


async def finish(update, context):
    tg, chat = update.effective_user, update.effective_chat
    action, data = runtime.get_state(tg.id, chat.id)
    await answer(update)
    if action != "pti_photos":
        return

    async def work(update, context, ctx, s):
        svc.submit(ctx, s, svc.by_prefix(ctx, s, data["req"]))
        runtime.clear_state(tg.id, chat.id)
        await reply(update, context, t(ctx.lang, "pti.submitted"))

    await run_as(update, context, work, uuid.UUID(data["company"]))


@secured("maintenance.edit")
async def cb_review(update, context, ctx, s):
    _, prefix, decision = update.callback_query.data.split(":")
    svc.review(ctx, s, svc.by_prefix(ctx, s, prefix), decision == "ok")
    await answer(update)
    await show(update, context, t(ctx.lang, "pti.reviewed_ok" if decision == "ok" else "pti.reviewed_redo"))


@command("ptistatus", "maintenance.view")
async def cmd_status(update, context, ctx, s):
    await answer(update)
    sm = svc.status_summary(ctx, s)
    if sm is None:
        await reply(update, context, t(ctx.lang, "pti.none_yet"))
        return
    text = t(ctx.lang, "pti.status", ok=sm["ok"], review=sm["review"], wait=len(sm["wait"]))
    if sm["wait"]:
        text += "\n" + t(ctx.lang, "pti.waiting", names=", ".join(sm["wait"][:20]))
    await reply(update, context, text)
