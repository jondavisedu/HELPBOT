"""Shared bot plumbing: who is this, which company, may they do it (deny by default), run the handler in a
company-scoped DB session, then deliver notifications AFTER the commit."""
import logging
import uuid
from dataclasses import dataclass
from datetime import timedelta
from functools import wraps

from sqlalchemy import select
from telegram import InlineKeyboardButton as IB, InlineKeyboardMarkup as IM
from telegram.error import BadRequest, TelegramError

from .. import audit, config, db, i18n
from ..i18n import t
from ..models import BotState, CompanyUser, Notification, User, as_utc, utcnow
from ..rbac import Ctx, GroupPost, Notify, PermissionDenied, build_ctx
from ..services import access, groups
from ..services.errors import ServiceError

log = logging.getLogger("helpbot")
COMMANDS = {}                      # name -> wrapped handler (also used by menu buttons: "cmd:<name>")
STATE_TTL = timedelta(minutes=30)


# ------------------------------------------------------------------ keyboards and sending
def kb(lang, rows):
    """rows: [[(label, callback_data | 'url:https://...')]]. Labels that are i18n keys are translated."""
    out = []
    for row in rows:
        line = []
        for label, data in row:
            text = t(lang, label) if label in i18n.S["en"] else label
            line.append(IB(text, url=data[4:]) if data.startswith("url:") else IB(text, callback_data=data))
        out.append(line)
    return IM(out)


async def say(bot, chat_id, text, markup=None):
    try:
        return await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=markup,
                                      disable_web_page_preview=True)
    except TelegramError as e:
        log.warning("send to %s failed: %s", chat_id, e)
        return None


async def reply(update, context, text, markup=None):
    return await say(context.bot, update.effective_chat.id, text, markup)


async def show(update, context, text, markup=None):
    """Edit the message a button was pressed on; otherwise send a new message."""
    q = update.callback_query
    if q and q.message:
        try:
            await context.bot.edit_message_text(chat_id=q.message.chat.id, message_id=q.message.message_id,
                                                text=text, parse_mode="HTML", reply_markup=markup,
                                                disable_web_page_preview=True)
            return
        except BadRequest as e:
            if "not modified" in str(e).lower():
                return
        except TelegramError:
            pass
    await reply(update, context, text, markup)


async def answer(update, text=None, alert=False):
    if update.callback_query:
        try:
            await update.callback_query.answer(text, show_alert=alert)
        except TelegramError:
            pass


# ------------------------------------------------------------------ conversation state (persistent)
def set_state(tg_id, chat_id, action, data=None):
    with db.session_scope(db.NOSCOPE) as s:
        row = s.get(BotState, (tg_id, chat_id))
        if row is None:
            s.add(BotState(telegram_user_id=tg_id, chat_id=chat_id, action=action, data=data or {}))
        else:
            row.action, row.data, row.updated_at = action, data or {}, utcnow()


def get_state(tg_id, chat_id):
    with db.session_scope(db.NOSCOPE) as s:
        row = s.get(BotState, (tg_id, chat_id))
        if row is None:
            return None, {}
        if utcnow() - as_utc(row.updated_at) > STATE_TTL:
            s.delete(row)
            return None, {}
        return row.action, dict(row.data or {})


def clear_state(tg_id, chat_id):
    with db.session_scope(db.NOSCOPE) as s:
        row = s.get(BotState, (tg_id, chat_id))
        if row is not None:
            s.delete(row)


# ------------------------------------------------------------------ identity
@dataclass
class Resolved:
    reason: str                    # ok | unknown | pending | rejected | suspended | group_unlinked | no_access | blocked
    ctx: Ctx | None
    lang: str


def anon_ctx(user):
    return Ctx(user_id=user.id, telegram_user_id=user.telegram_user_id, full_name=user.full_name,
               lang=user.preferred_language, company_id=None)


def resolve(tg, chat, company_override=None, ignore_group=False):
    """Telegram user + chat -> verified context. The company comes from the LINKED GROUP or the user's own
    active company: never from anything the client sends."""
    is_group = chat.type in ("group", "supergroup")
    group = groups.resolve_group(chat.id) if (is_group and not ignore_group) else None
    with db.session_scope(db.NOSCOPE) as s:
        user = access.get_user_by_tg(s, tg.id)
        if user is None:
            return Resolved("unknown", None, config.DEFAULT_LANGUAGE)
        lang = user.preferred_language
        if user.status != "active":
            return Resolved(user.status, None, lang)
        if is_group and not ignore_group:
            if group is None:
                return Resolved("group_unlinked", None, lang)
            company_id = group[0]
        else:
            company_id = company_override or user.active_company_id
            if company_id is None and user.platform_role != "owner":
                mine = {r for r in s.scalars(select(CompanyUser.company_id).where(
                    CompanyUser.user_id == user.id, CompanyUser.status == "active"))}
                if len(mine) == 1:
                    company_id = next(iter(mine))
                    user.active_company_id = company_id
        ctx = build_ctx(s, user, company_id, chat.id)
        if company_id is not None and ctx.company_id is None and user.platform_role != "owner":
            if not is_group and company_override is None and user.active_company_id == company_id:
                user.active_company_id = None                     # stale selection: forget it
            return Resolved("no_access", ctx, lang)
        if ctx.blocked and not ctx.is_owner:
            return Resolved("blocked", ctx, lang)
        return Resolved("ok", ctx, lang)


async def _reject(update, context, r, is_group):
    if is_group:
        return                                                   # never answer strangers in groups
    key = {"unknown": "start.unknown", "pending": "start.pending", "rejected": "start.rejected",
           "suspended": "start.suspended", "no_access": "status.no_access",
           "blocked": "status.company_blocked"}.get(r.reason)
    if key:
        await reply(update, context, t(r.lang, key))


def _record_denied(ctx, need, update):
    try:
        with db.session_scope(db.NOSCOPE) as s:
            audit.record(s, ctx=ctx, action="permission_denied", object_type="command",
                         after={"need": need, "chat": update.effective_chat.type})
    except Exception:
        log.exception("could not audit a denial")


async def _deny(update, context, ctx, need):
    _record_denied(ctx, need, update)
    await answer(update, t(ctx.lang, "err.denied"), alert=True)
    await reply(update, context, t(ctx.lang, "err.denied")) if not update.callback_query else None


async def _run(fn, update, context, ctx):
    scope = ctx.company_id if ctx.company_id else db.NOSCOPE
    try:
        with db.session_scope(scope) as s:
            await fn(update, context, ctx, s)
    except PermissionDenied as e:
        ctx.outbox.clear()
        _record_denied(ctx, e.code, update)
        await answer(update, t(ctx.lang, "err.denied"), alert=True)
        await reply(update, context, t(ctx.lang, "err.denied"))
        return
    except ServiceError as e:
        ctx.outbox.clear()
        await answer(update)
        await reply(update, context, t(ctx.lang, e.key, **e.params))
        return
    except Exception:
        ctx.outbox.clear()
        log.exception("handler %s failed", getattr(fn, "__name__", fn))
        await answer(update)
        await reply(update, context, t(ctx.lang, "err.generic"))
        return
    await deliver(context, ctx.outbox)


def secured(perm=None, *, owner_only=False, dm_only=False, need_company=True, group_ok=True):
    """Wrap a handler fn(update, context, ctx, s). Deny by default: the user must be an approved member with the
    permission; strangers get nothing in groups. Hiding a button is never the only protection."""
    def deco(fn):
        @wraps(fn)
        async def wrapper(update, context):
            tg, chat = update.effective_user, update.effective_chat
            if tg is None or chat is None or tg.is_bot:
                return
            is_group = chat.type in ("group", "supergroup")
            r = resolve(tg, chat)
            if r.reason != "ok":
                await _reject(update, context, r, is_group)
                return
            ctx = r.ctx
            if is_group and (dm_only or not group_ok):
                await reply(update, context, t(ctx.lang, "err.dm_only"))
                return
            if owner_only and not ctx.is_owner:
                await _deny(update, context, ctx, "owner")
                return
            if need_company and ctx.company_id is None:
                await answer(update)
                await reply(update, context, t(ctx.lang, "err.no_company"))
                return
            if perm and not ctx.can(perm):
                await _deny(update, context, ctx, perm)
                return
            await _run(fn, update, context, ctx)
        return wrapper
    return deco


def command(name, perm=None, **opts):
    """Register a command (also reachable from menu buttons as callback 'cmd:<name>')."""
    def deco(fn):
        wrapped = secured(perm, **opts)(fn)
        COMMANDS[name] = wrapped
        return wrapped
    return deco


# ------------------------------------------------------------------ delivering notifications (after commit)
async def deliver(context, outbox):
    items, outbox[:] = list(outbox), []
    for item in items:
        try:
            if isinstance(item, Notify):
                await _send_notify(context, item)
            elif isinstance(item, GroupPost):
                await _send_group(context, item)
        except Exception:
            log.exception("delivery failed")


def _jsonable(params):
    return {k: (str(v) if isinstance(v, uuid.UUID) else v) for k, v in params.items()}


async def _send_notify(context, item):
    with db.session_scope(db.NOSCOPE) as s:
        user = s.get(User, item.user_id)
        if user is None or not user.telegram_user_id:
            return
        s.add(Notification(user_id=user.id, key=item.key, params=_jsonable(item.params), category="general"))
        tg_id, lang = user.telegram_user_id, user.preferred_language
    await say(context.bot, tg_id, t(lang, item.key, **item.params), kb(lang, [item.buttons]) if item.buttons else None)


async def _send_group(context, item):
    with db.session_scope(item.company_id) as s:
        chat_id = groups.group_chat_for(s, item.company_id, item.group_type)
    if chat_id is None:
        return
    lang = config.DEFAULT_LANGUAGE
    await say(context.bot, chat_id, t(lang, item.key, **item.params),
              kb(lang, [item.buttons]) if item.buttons else None)


async def run_as(update, context, work, company_id=None, perm=None):
    """Run work(update, context, ctx, s) for a verified context in a specific company (used by multi-step flows
    and by buttons whose company is resolved from the database, never from the button itself)."""
    tg, chat = update.effective_user, update.effective_chat
    r = resolve(tg, chat, company_override=company_id, ignore_group=True)
    if r.reason != "ok":
        await _reject(update, context, r, chat.type != "private")
        return
    ctx = r.ctx
    if company_id is not None and ctx.company_id != company_id and not ctx.is_owner:
        await _deny(update, context, ctx, "company")
        return
    if perm and not ctx.can(perm):
        await _deny(update, context, ctx, perm)
        return
    await _run(work, update, context, ctx)
