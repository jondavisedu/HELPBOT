"""Tickets: guided creation in a private chat, lists, details, replies, internal notes, status, assignment."""
import uuid

from sqlalchemy import select

from ..i18n import t
from ..models import User
from ..rbac import CONFIDENTIAL_CATEGORIES
from ..services import access, tickets as svc
from . import runtime
from .runtime import answer, command, kb, reply, run_as, secured, show

FILTERS = ["active", "open", "in_progress", "waiting", "escalated", "done"]


def _name(s, uid):
    u = s.get(User, uid) if uid else None
    return u.full_name if u else "-"


def _line(ctx, tk, in_group):
    subject = "🔒" if (in_group and tk.category in CONFIDENTIAL_CATEGORIES) else tk.subject[:60]
    return t(ctx.lang, "tk.line", n=tk.ticket_number, status=tk.status, cat=tk.category, subject=subject)


def view(ctx, s, tk, in_group):
    lang = ctx.lang
    if in_group and tk.category in CONFIDENTIAL_CATEGORIES:
        return t(lang, "tk.confidential_here"), None
    text = t(lang, "tk.view", n=tk.ticket_number, subject=tk.subject, cat=tk.category, prio=tk.priority,
             status=tk.status, by=_name(s, tk.created_by), assignee=_name(s, tk.assigned_to),
             desc=tk.description or "-")
    for m, who in svc.messages(ctx, s, tk)[-6:]:
        text += "\n" + t(lang, "tk.msg_internal" if m.visibility == "internal" else "tk.msg_public",
                         who=who, body=m.body[:300])
    n, rows = tk.ticket_number, []
    if not ctx.self_scoped and ctx.can("tickets.edit"):
        moves = [(f"tkstatus.{st}", f"tk:{n}:{st}") for st in ("in_progress", "waiting", "escalated", "done", "open")
                 if st in svc.TRANSITIONS.get(tk.status, set())]
        rows += [moves[i:i + 2] for i in range(0, len(moves), 2)]
        extra = []
        if ctx.can("tickets.assign"):
            extra.append(("btn.assign_me", f"tk:{n}:me"))
        extra.append(("btn.note", f"tk:{n}:note"))
        rows.append(extra)
    rows.append([("btn.reply", f"tk:{n}:reply")])
    return text, kb(lang, rows)


# ------------------------------------------------------------------ guided creation (private chat)
@command("ticket", "tickets.create")
async def cmd_ticket(update, context, ctx, s):
    args = context.args or []
    chat, tg = update.effective_chat, update.effective_user
    if args and args[0].isdigit():
        await answer(update)
        tk = svc.get_ticket(ctx, s, int(args[0]))
        text, markup = view(ctx, s, tk, chat.type != "private")
        await reply(update, context, text, markup)
        return
    await answer(update)
    if chat.type != "private":                       # never collect text in a group: continue in private
        url = f"https://t.me/{context.bot.username}?start=tk_{ctx.company_id.hex[:8]}"
        await reply(update, context, t(ctx.lang, "tk.dm_hint"), kb(ctx.lang, [[("btn.continue_dm", "url:" + url)]]))
        return
    company = ctx.company_id.hex
    if args and args[0].startswith("tk_"):
        match = access.company_by_prefix(ctx, s, args[0][3:])
        company = match.id.hex if match else company
    runtime.set_state(tg.id, chat.id, "tk_new", {"company": company})
    rows = [[(f"cat.{c}", f"nt:{c}")] for c in svc.CATEGORIES]
    await reply(update, context, t(ctx.lang, "tk.pick_cat"), kb(ctx.lang, rows))


@secured("tickets.create", dm_only=True)
async def cb_new_category(update, context, ctx, s):
    tg, chat = update.effective_user, update.effective_chat
    action, data = runtime.get_state(tg.id, chat.id)
    cat = update.callback_query.data.split(":")[1]
    await answer(update)
    if action != "tk_new" or cat not in svc.CATEGORIES:
        await show(update, context, t(ctx.lang, "state.expired"))
        return
    data["category"] = cat
    runtime.set_state(tg.id, chat.id, "tk_new", data)
    rows = [[(f"prio.{p}", f"np:{p}")] for p in svc.PRIORITIES]
    await show(update, context, t(ctx.lang, "tk.pick_prio"), kb(ctx.lang, rows))


@secured("tickets.create", dm_only=True)
async def cb_new_priority(update, context, ctx, s):
    tg, chat = update.effective_user, update.effective_chat
    action, data = runtime.get_state(tg.id, chat.id)
    prio = update.callback_query.data.split(":")[1]
    await answer(update)
    if action != "tk_new" or "category" not in data or prio not in svc.PRIORITIES:
        await show(update, context, t(ctx.lang, "state.expired"))
        return
    data["priority"] = prio
    runtime.set_state(tg.id, chat.id, "tk_subject", data)
    await show(update, context, t(ctx.lang, "tk.ask_subject"))


async def st_subject(update, context, data):
    tg, chat = update.effective_user, update.effective_chat
    data["subject"] = (update.effective_message.text or "").strip()[:300]
    if len(data["subject"]) < 3:
        return
    runtime.set_state(tg.id, chat.id, "tk_desc", data)
    with runtime.db.session_scope(runtime.db.NOSCOPE) as s:
        lang = access.get_user_by_tg(s, tg.id).preferred_language
    await runtime.say(context.bot, chat.id, t(lang, "tk.ask_desc"), kb(lang, [[("btn.skip", "nd:skip")]]))


async def _create(update, context, data, description):
    tg, chat = update.effective_user, update.effective_chat

    async def work(update, context, ctx, s):
        tk = svc.create_ticket(ctx, s, data["category"], data["subject"], description, data["priority"])
        runtime.clear_state(tg.id, chat.id)
        await reply(update, context, t(ctx.lang, "tk.created", n=tk.ticket_number))

    await run_as(update, context, work, uuid.UUID(data["company"]), "tickets.create")


async def st_description(update, context, data):
    await _create(update, context, data, (update.effective_message.text or "").strip())


async def cb_skip_description(update, context):
    tg, chat = update.effective_user, update.effective_chat
    action, data = runtime.get_state(tg.id, chat.id)
    await answer(update)
    if action == "tk_desc":
        await _create(update, context, data, None)


# ------------------------------------------------------------------ lists
async def _list(update, context, ctx, s, flt):
    in_group = update.effective_chat.type != "private"
    rows = svc.list_tickets(ctx, s, flt)
    label = t(ctx.lang, "btn.mytickets") if flt == "mine" else (t(ctx.lang, "tkstatus." + flt) if flt in FILTERS else flt)
    head = t(ctx.lang, "tk.list_title") + f" ({label})"
    if not rows:
        text, markup = head + "\n" + t(ctx.lang, "tk.none"), None
    else:
        text = head + "\n" + "\n".join(_line(ctx, tk, in_group) for tk in rows)
        buttons = [(f"#{tk.ticket_number}", f"tk:{tk.ticket_number}:view") for tk in rows[:10]]
        keyboard = [buttons[i:i + 5] for i in range(0, len(buttons), 5)]
        keyboard.append([(f"tkstatus.{f}", f"tl:{f}") for f in ("active", "waiting", "done")])
        markup = kb(ctx.lang, keyboard)
    await show(update, context, text, markup)


@command("tickets", "tickets.view")
async def cmd_tickets(update, context, ctx, s):
    await answer(update)
    flt = (context.args or ["active"])[0]
    await _list(update, context, ctx, s, flt if flt in FILTERS + ["mine", "assigned"] else "active")


@command("mytickets", "tickets.view")
async def cmd_mytickets(update, context, ctx, s):
    await answer(update)
    await _list(update, context, ctx, s, "mine")


@secured("tickets.view")
async def cb_list(update, context, ctx, s):
    await answer(update)
    await _list(update, context, ctx, s, update.callback_query.data.split(":")[1])


# ------------------------------------------------------------------ one ticket
@secured("tickets.view")
async def cb_ticket(update, context, ctx, s):
    _, n, action = update.callback_query.data.split(":")
    n, in_group = int(n), update.effective_chat.type != "private"
    tg, chat = update.effective_user, update.effective_chat
    tk = svc.get_ticket(ctx, s, n)
    if action in ("reply", "note"):
        await answer(update)
        if in_group:
            await reply(update, context, t(ctx.lang, "err.dm_only"))
            return
        if action == "note" and (ctx.self_scoped or not ctx.can("tickets.edit")):
            runtime._record_denied(ctx, "tickets.internal", update)
            await reply(update, context, t(ctx.lang, "err.denied"))
            return
        runtime.set_state(tg.id, chat.id, "tk_reply" if action == "reply" else "tk_note",
                          {"n": n, "company": ctx.company_id.hex})
        await reply(update, context, t(ctx.lang, "tk.ask_reply" if action == "reply" else "tk.ask_note"))
        return
    if action in svc.STATUSES:
        if tk.status == "done" and action == "open":
            await answer(update)
            if in_group:
                await reply(update, context, t(ctx.lang, "err.dm_only"))
                return
            runtime.set_state(tg.id, chat.id, "tk_reason", {"n": n, "status": "open", "company": ctx.company_id.hex})
            await reply(update, context, t(ctx.lang, "tk.ask_reason"))
            return
        svc.change_status(ctx, s, n, action)
    elif action == "me":
        svc.assign(ctx, s, n, ctx.user_id)
    await answer(update)
    tk = svc.get_ticket(ctx, s, n)
    text, markup = view(ctx, s, tk, in_group)
    await show(update, context, text, markup)


async def finish_message(update, context, data, internal):
    tg, chat = update.effective_user, update.effective_chat
    body = (update.effective_message.text or "").strip()

    async def work(update, context, ctx, s):
        svc.add_message(ctx, s, data["n"], body, internal=internal)
        runtime.clear_state(tg.id, chat.id)
        tk = svc.get_ticket(ctx, s, data["n"])
        text, markup = view(ctx, s, tk, False)
        await reply(update, context, t(ctx.lang, "tk.reply_sent") + "\n\n" + text, markup)

    await run_as(update, context, work, uuid.UUID(data["company"]), "tickets.view")


async def finish_reopen(update, context, data):
    tg, chat = update.effective_user, update.effective_chat
    reason = (update.effective_message.text or "").strip()

    async def work(update, context, ctx, s):
        svc.change_status(ctx, s, data["n"], data["status"], reason)
        runtime.clear_state(tg.id, chat.id)
        tk = svc.get_ticket(ctx, s, data["n"])
        text, markup = view(ctx, s, tk, False)
        await reply(update, context, text, markup)

    await run_as(update, context, work, uuid.UUID(data["company"]), "tickets.edit")
