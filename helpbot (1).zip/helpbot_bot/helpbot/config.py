"""Settings come from environment variables only. Never hardcode secrets."""
import os
from zoneinfo import ZoneInfo

try:                                        # optional: read a local .env file (handy on Windows)
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


def _ids(name):
    return {int(x) for x in os.environ.get(name, "").replace(" ", "").split(",") if x.strip("-").isdigit()}


def _db_url():
    url = os.environ.get("DATABASE_URL", "").strip() or "sqlite:///helpbot.db"
    for prefix in ("postgres://", "postgresql://"):
        if url.startswith(prefix):
            return "postgresql+psycopg://" + url[len(prefix):]
    return url


BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
BOT_NAME = "HELPBOT"
DATABASE_URL = _db_url()
ENVIRONMENT = os.environ.get("ENVIRONMENT", "staging")        # staging | production
OWNER_IDS = _ids("OWNER_TELEGRAM_ID")                         # only these accounts are the platform Owner
DEFAULT_LANGUAGE = os.environ.get("DEFAULT_LANGUAGE", "uz")
TZ = ZoneInfo(os.environ.get("TIMEZONE", "America/New_York"))
AUTO_MIGRATE = os.environ.get("AUTO_MIGRATE", "true").lower() == "true"
WEBHOOK_URL = os.environ.get("WEBHOOK_URL", "").rstrip("/")
WEBHOOK_SECRET = os.environ.get("WEBHOOK_SECRET", "")
PORT = int(os.environ.get("PORT", "8080"))
REMINDER_MINUTES = int(os.environ.get("REMINDER_MINUTES", "30"))
APPROVAL_EXPIRY_DAYS = int(os.environ.get("APPROVAL_EXPIRY_DAYS", "7"))
# Policy switch: by default nobody (even the Owner) can approve their own critical action.
ALLOW_OWNER_SELF_APPROVAL = os.environ.get("ALLOW_OWNER_SELF_APPROVAL", "false").lower() == "true"
LANGUAGES = ("en", "uz", "ru")

# ---- web (REST API + dashboard) ----
SECRET_KEY = os.environ.get("SECRET_KEY", "")                       # encrypts 2FA secrets at rest; keep it safe
WEB_SESSION_HOURS = int(os.environ.get("WEB_SESSION_HOURS", "12"))
WEB_REQUIRE_2FA = {r for r in os.environ.get("WEB_REQUIRE_2FA", "owner,super_admin,company_admin").split(",") if r}
ALLOWED_ORIGINS = {o.strip().rstrip("/") for o in os.environ.get("ALLOWED_ORIGINS", "").split(",") if o.strip()}

# ---- AI manager (optional external model; the default is built-in rules and sends nothing anywhere) ----
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
AI_MODEL = os.environ.get("AI_MODEL", "claude-haiku-4-5")
