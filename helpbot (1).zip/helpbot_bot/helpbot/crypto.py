"""Encryption of small secrets at rest (2FA seeds). Key comes from SECRET_KEY, never from the database."""
import base64
import hashlib

from cryptography.fernet import Fernet, InvalidToken

from . import config


def _fernet():
    if not config.SECRET_KEY:
        raise RuntimeError("SECRET_KEY is not set")
    key = base64.urlsafe_b64encode(hashlib.sha256(config.SECRET_KEY.encode()).digest())
    return Fernet(key)


def encrypt(text):
    return _fernet().encrypt(text.encode()).decode()


def decrypt(token):
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken:
        raise RuntimeError("cannot decrypt: wrong SECRET_KEY")
