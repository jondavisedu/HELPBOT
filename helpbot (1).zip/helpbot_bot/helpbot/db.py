"""Engine, sessions and the TENANT GUARD.

Every session has a *scope*:
  - a company id : tenant tables are filtered by that company (reads) and validated (writes)
  - NOSCOPE      : deny by default - tenant tables return nothing and cannot be written
  - PLATFORM     : unrestricted; only for trusted platform code (see platform_session)
Client-supplied company ids are never trusted: the scope is derived from the verified context."""
import logging
import uuid
from contextlib import contextmanager

from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, sessionmaker, with_loader_criteria

from . import config
from .models import AuditLog, TenantMixin

log = logging.getLogger("helpbot.db")


class _Scope:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return self.name


NOSCOPE = _Scope("NOSCOPE")
PLATFORM = _Scope("PLATFORM")


class TenantViolation(Exception):
    """A write tried to touch another company's data."""


class AuditImmutable(Exception):
    """Audit logs are append-only."""


_engine = None
_SessionLocal = None


def init_engine(url=None):
    global _engine, _SessionLocal
    url = url or config.DATABASE_URL
    kwargs = {"future": True}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False}
        if ":memory:" in url or url == "sqlite://":
            from sqlalchemy.pool import StaticPool
            kwargs["poolclass"] = StaticPool
    else:
        kwargs["pool_pre_ping"] = True
    _engine = create_engine(url, **kwargs)
    _SessionLocal = sessionmaker(bind=_engine, class_=Session, expire_on_commit=False)
    return _engine


def engine():
    if _engine is None:
        init_engine()
    return _engine


def _new_session(scope):
    engine()
    s = _SessionLocal()
    s.info["scope"] = scope
    return s


@contextmanager
def session_scope(scope=NOSCOPE):
    """Open a session limited to `scope` (a company UUID, NOSCOPE or PLATFORM). Commits on success."""
    s = _new_session(scope)
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


@contextmanager
def platform_session(reason):
    """Unrestricted access for trusted platform code. `reason` documents why (grep for this function)."""
    log.debug("platform_session: %s", reason)
    with session_scope(PLATFORM) as s:
        yield s


# ------------------------------------------------------------------ guards
@event.listens_for(Session, "do_orm_execute")
def _tenant_filter(state):
    if state.is_column_load or state.is_relationship_load:
        return
    if not (state.is_select or state.is_update or state.is_delete):
        return
    scope = state.session.info.get("scope", NOSCOPE)
    if scope is PLATFORM:
        return
    company_id = scope if isinstance(scope, uuid.UUID) else None      # None => matches no rows
    state.statement = state.statement.options(
        with_loader_criteria(TenantMixin, lambda cls: cls.company_id == company_id, include_aliases=True))


@event.listens_for(Session, "before_flush")
def _write_guard(session, flush_context, instances):
    scope = session.info.get("scope", NOSCOPE)
    for obj in list(session.new) + [o for o in session.dirty if session.is_modified(o)]:
        if isinstance(obj, AuditLog) and obj in session.dirty:
            raise AuditImmutable("audit_logs is append-only")
        if isinstance(obj, TenantMixin) and scope is not PLATFORM:
            if not isinstance(scope, uuid.UUID) or obj.company_id != scope:
                raise TenantViolation(f"{type(obj).__name__} write outside the active company scope")
    for obj in session.deleted:
        if isinstance(obj, AuditLog):
            raise AuditImmutable("audit_logs is append-only")
        if isinstance(obj, TenantMixin) and scope is not PLATFORM:
            if not isinstance(scope, uuid.UUID) or obj.company_id != scope:
                raise TenantViolation(f"{type(obj).__name__} delete outside the active company scope")
