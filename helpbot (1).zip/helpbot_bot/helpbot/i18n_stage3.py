EN = {
 "web.code": "🔐 Your HELPBOT web login code: <b>{code}</b>\nValid for 5 minutes. If this was not you, ignore this message and never share the code.",
 "tfa.intro": "🔐 <b>Two-factor authentication</b>\nAdd this secret to Google Authenticator / Authy (manual entry):\n<code>{secret}</code>\nThen confirm with /2fa 123456 (the 6-digit code from the app). Delete this message afterwards.",
 "tfa.status_on": "🔐 2FA is ON. To disable: /2fa off 123456", "tfa.enabled": "✅ 2FA enabled.",
 "tfa.bad_code": "Wrong code.", "tfa.disabled": "✅ 2FA disabled; web sessions were closed.",
 "tfa.not_configured": "2FA is not configured on this server (SECRET_KEY is missing).",
 "weblogout.done": "✅ All web sessions were closed.",
}
UZ = {
 "web.code": "🔐 HELPBOT web kirish kodingiz: <b>{code}</b>\n5 daqiqa amal qiladi. Agar bu siz bo'lmasangiz, xabarga e'tibor bermang va kodni hech kimga bermang.",
 "tfa.intro": "🔐 <b>Ikki bosqichli himoya</b>\nBu maxfiy kalitni Google Authenticator / Authy ga qo'lda kiriting:\n<code>{secret}</code>\nKeyin /2fa 123456 bilan tasdiqlang (ilovadagi 6 xonali kod). Shundan so'ng bu xabarni o'chiring.",
 "tfa.status_on": "🔐 2FA yoqilgan. O'chirish: /2fa off 123456", "tfa.enabled": "✅ 2FA yoqildi.",
 "tfa.bad_code": "Kod noto'g'ri.", "tfa.disabled": "✅ 2FA o'chirildi; web sessiyalar yopildi.",
 "tfa.not_configured": "Bu serverda 2FA sozlanmagan (SECRET_KEY yo'q).",
 "weblogout.done": "✅ Barcha web sessiyalar yopildi.",
}
RU = {
 "web.code": "🔐 Ваш код для входа в веб-версию HELPBOT: <b>{code}</b>\nДействует 5 минут. Если это были не вы, проигнорируйте сообщение и никому не передавайте код.",
 "tfa.intro": "🔐 <b>Двухфакторная аутентификация</b>\nДобавьте этот ключ в Google Authenticator / Authy (ввод вручную):\n<code>{secret}</code>\nЗатем подтвердите командой /2fa 123456 (6-значный код из приложения). После этого удалите это сообщение.",
 "tfa.status_on": "🔐 2FA включена. Отключить: /2fa off 123456", "tfa.enabled": "✅ 2FA включена.",
 "tfa.bad_code": "Неверный код.", "tfa.disabled": "✅ 2FA отключена; веб-сессии закрыты.",
 "tfa.not_configured": "2FA не настроена на этом сервере (нет SECRET_KEY).",
 "weblogout.done": "✅ Все веб-сессии закрыты.",
}
