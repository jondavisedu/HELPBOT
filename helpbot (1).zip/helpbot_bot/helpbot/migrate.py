"""Programmatic Alembic helpers (used by main.py and manage.py)."""
import hashlib
import os
import tempfile
import time
from contextlib import contextmanager

from alembic import command
from alembic.config import Config

from . import config

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def alembic_config():
    cfg = Config(os.path.join(ROOT, "alembic.ini"))
    cfg.set_main_option("script_location", os.path.join(ROOT, "alembic"))
    cfg.set_main_option("sqlalchemy.url", config.DATABASE_URL.replace("%", "%%"))
    return cfg


def upgrade(revision="head"):
    command.upgrade(alembic_config(), revision)


LOCK_KEY = 727274                      # arbitrary constant for the PostgreSQL advisory lock


@contextmanager
def startup_lock(timeout=120):
    """Only ONE process at a time may migrate/seed (gunicorn workers, web + bot starting together).
    PostgreSQL: advisory lock (works across machines). Other databases: an atomic lock directory."""
    if config.DATABASE_URL.startswith("postgresql"):
        from sqlalchemy import create_engine, text
        engine = create_engine(config.DATABASE_URL, isolation_level="AUTOCOMMIT")
        with engine.connect() as conn:
            conn.execute(text("SELECT pg_advisory_lock(:k)"), {"k": LOCK_KEY})
            try:
                yield
            finally:
                conn.execute(text("SELECT pg_advisory_unlock(:k)"), {"k": LOCK_KEY})
        engine.dispose()
        return
    path = os.path.join(tempfile.gettempdir(), "helpbot-" + hashlib.sha256(config.DATABASE_URL.encode()).hexdigest()[:16])
    deadline = time.time() + timeout
    while True:
        try:
            os.mkdir(path)                              # atomic: exactly one process wins
            break
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(path) > timeout:      # stale lock from a crashed process
                    os.rmdir(path)
                    continue
            except OSError:
                pass
            if time.time() > deadline:
                raise TimeoutError("could not get the startup lock")
            time.sleep(0.2)
    try:
        yield
    finally:
        try:
            os.rmdir(path)
        except OSError:
            pass
