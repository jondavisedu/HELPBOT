"""Database models (PostgreSQL in production, SQLite for local tests).

Tenant rule: every business table carries `company_id` through TenantMixin. The session guard in db.py
filters all reads and validates all writes by the session's company scope (deny by default)."""
import uuid
from datetime import datetime, timezone

from sqlalchemy import (JSON, BigInteger, Boolean, CheckConstraint, DateTime, ForeignKey, Integer, String, Text,
                        UniqueConstraint, Uuid)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

JSONType = JSON().with_variant(JSONB(), "postgresql")
BigPK = BigInteger().with_variant(Integer, "sqlite")


def utcnow():
    return datetime.now(timezone.utc)


def as_utc(dt):
    """SQLite returns naive datetimes: treat them as UTC."""
    if dt is not None and dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


class Base(DeclarativeBase):
    pass


class IdMixin:
    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)


class TimeMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class TenantMixin:
    """Marks a company-scoped table. Filtered and validated automatically (see db.py)."""
    company_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("companies.id"), nullable=False, index=True)


# ------------------------------------------------------------------ identity & access (not tenant-filtered)
class Company(IdMixin, TimeMixin, Base):
    __tablename__ = "companies"
    __table_args__ = (CheckConstraint("status IN ('active','trial','past_due','suspended','archived')",
                                      name="ck_company_status"),)
    name: Mapped[str] = mapped_column(String(200), unique=True)
    legal_name: Mapped[str | None] = mapped_column(String(300))
    status: Mapped[str] = mapped_column(String(20), default="active")
    created_by: Mapped[uuid.UUID | None] = mapped_column(Uuid)


class User(IdMixin, TimeMixin, Base):
    __tablename__ = "users"
    __table_args__ = (
        CheckConstraint("status IN ('pending','active','rejected','suspended')", name="ck_user_status"),
        CheckConstraint("preferred_language IN ('en','uz','ru')", name="ck_user_lang"),
        CheckConstraint("platform_role IS NULL OR platform_role IN ('owner','super_admin')", name="ck_user_prole"),
    )
    telegram_user_id: Mapped[int | None] = mapped_column(BigInteger, unique=True)
    telegram_username: Mapped[str | None] = mapped_column(String(64))
    email: Mapped[str | None] = mapped_column(String(200), unique=True)
    full_name: Mapped[str] = mapped_column(String(200))
    phone: Mapped[str | None] = mapped_column(String(40))
    password_hash: Mapped[str | None] = mapped_column(String(255))
    preferred_language: Mapped[str] = mapped_column(String(2), default="en")
    status: Mapped[str] = mapped_column(String(20), default="pending")
    platform_role: Mapped[str | None] = mapped_column(String(20))
    active_company_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("companies.id"))
    totp_secret_enc: Mapped[str | None] = mapped_column(Text)            # 2FA secret, encrypted (see crypto.py)
    totp_enabled: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")


class RegistrationRequest(IdMixin, Base):
    __tablename__ = "registration_requests"
    __table_args__ = (CheckConstraint("status IN ('pending','approved','rejected')", name="ck_regreq_status"),)
    user_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("users.id"), index=True)
    requested_company_name: Mapped[str | None] = mapped_column(String(200))
    message: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    reviewed_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    review_note: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Role(IdMixin, Base):
    __tablename__ = "roles"
    __table_args__ = (CheckConstraint("scope IN ('platform','company','self','client')", name="ck_role_scope"),)
    name: Mapped[str] = mapped_column(String(40), unique=True)
    scope: Mapped[str] = mapped_column(String(20))


class Permission(IdMixin, Base):
    __tablename__ = "permissions"
    code: Mapped[str] = mapped_column(String(80), unique=True)
    module: Mapped[str] = mapped_column(String(40))
    action: Mapped[str] = mapped_column(String(40))


class RolePermission(Base):
    __tablename__ = "role_permissions"
    role_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("roles.id"), primary_key=True)
    permission_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("permissions.id"), primary_key=True)


class CompanyUser(IdMixin, Base):
    """Membership: a user belongs to one or more companies, each with one or more roles."""
    __tablename__ = "company_users"
    __table_args__ = (UniqueConstraint("company_id", "user_id", "role_id", name="uq_company_user_role"),
                      CheckConstraint("status IN ('active','suspended','removed')", name="ck_cu_status"))
    company_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("companies.id"), index=True)
    user_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("users.id"), index=True)
    role_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("roles.id"))
    status: Mapped[str] = mapped_column(String(20), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class UserPermission(IdMixin, Base):
    """Extra permission granted by the Owner (company_id NULL = platform level, e.g. company.create)."""
    __tablename__ = "user_permissions"
    company_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("companies.id"))
    user_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("users.id"), index=True)
    permission_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("permissions.id"))
    granted_by: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("users.id"))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class BotState(Base):
    """Short multi-step conversations (survive restarts)."""
    __tablename__ = "bot_states"
    telegram_user_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    action: Mapped[str] = mapped_column(String(40))
    data: Mapped[dict] = mapped_column(JSONType, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Notification(IdMixin, Base):
    __tablename__ = "notifications"
    user_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("users.id"), index=True)
    company_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("companies.id"))
    category: Mapped[str] = mapped_column(String(40), default="general")
    key: Mapped[str] = mapped_column(String(80))
    params: Mapped[dict] = mapped_column(JSONType, default=dict)
    is_read: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AuditLog(Base):
    """Append-only (enforced in db.py)."""
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(BigPK, primary_key=True, autoincrement=True)
    company_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("companies.id"), index=True)
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    actor_type: Mapped[str] = mapped_column(String(20), default="user")
    channel: Mapped[str] = mapped_column(String(20), default="telegram")
    action: Mapped[str] = mapped_column(String(80), index=True)
    object_type: Mapped[str] = mapped_column(String(40))
    object_id: Mapped[uuid.UUID | None] = mapped_column(Uuid)
    before_data: Mapped[dict | None] = mapped_column(JSONType)
    after_data: Mapped[dict | None] = mapped_column(JSONType)
    reason: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


# ------------------------------------------------------------------ business tables (tenant-filtered)
class TelegramGroup(IdMixin, TimeMixin, TenantMixin, Base):
    __tablename__ = "telegram_groups"
    telegram_chat_id: Mapped[int] = mapped_column(BigInteger, unique=True)     # a chat belongs to ONE company
    title: Mapped[str | None] = mapped_column(String(300))
    group_type: Mapped[str] = mapped_column(String(30), default="operations")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    linked_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))


class TelegramGroupAdmin(IdMixin, TenantMixin, Base):
    """Roster written by /updadmin. Informational only: it never grants permissions."""
    __tablename__ = "telegram_group_admins"
    __table_args__ = (UniqueConstraint("group_id", "telegram_user_id", name="uq_group_admin"),)
    group_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("telegram_groups.id"), index=True)
    telegram_user_id: Mapped[int] = mapped_column(BigInteger)
    user_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    display_name: Mapped[str | None] = mapped_column(String(200))
    is_creator: Mapped[bool] = mapped_column(Boolean, default=False)
    synced_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Driver(IdMixin, TimeMixin, TenantMixin, Base):
    __tablename__ = "drivers"
    user_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))   # driver's own account
    full_name: Mapped[str] = mapped_column(String(200))
    phone: Mapped[str | None] = mapped_column(String(40))
    email: Mapped[str | None] = mapped_column(String(200))
    license_number: Mapped[str | None] = mapped_column(String(60))
    license_state: Mapped[str | None] = mapped_column(String(10))
    status: Mapped[str] = mapped_column(String(20), default="onboarding")


class DriverStatusHistory(IdMixin, TenantMixin, Base):
    __tablename__ = "driver_status_history"
    driver_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("drivers.id"), index=True)
    from_status: Mapped[str | None] = mapped_column(String(20))
    to_status: Mapped[str] = mapped_column(String(20))
    reason: Mapped[str | None] = mapped_column(Text)
    changed_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Truck(IdMixin, TimeMixin, TenantMixin, Base):
    __tablename__ = "trucks"
    __table_args__ = (UniqueConstraint("company_id", "unit_number", name="uq_truck_unit"),
                      UniqueConstraint("company_id", "vin", name="uq_truck_vin"))
    unit_number: Mapped[str] = mapped_column(String(40))
    vin: Mapped[str | None] = mapped_column(String(40))
    year: Mapped[int | None] = mapped_column(Integer)
    make: Mapped[str | None] = mapped_column(String(60))
    model: Mapped[str | None] = mapped_column(String(60))
    status: Mapped[str] = mapped_column(String(20), default="active")


class DriverAssignment(IdMixin, TenantMixin, Base):
    __tablename__ = "driver_assignments"
    driver_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("drivers.id"), index=True)
    truck_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("trucks.id"), index=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    changed_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    change_reason: Mapped[str | None] = mapped_column(Text)


class Ticket(IdMixin, TimeMixin, TenantMixin, Base):
    __tablename__ = "tickets"
    __table_args__ = (UniqueConstraint("company_id", "ticket_number", name="uq_ticket_number"),)
    ticket_number: Mapped[int] = mapped_column(Integer)                       # per company: #1, #2 ...
    created_by: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("users.id"), index=True)
    client_account_id: Mapped[uuid.UUID | None] = mapped_column(Uuid)
    category: Mapped[str] = mapped_column(String(20))
    priority: Mapped[str] = mapped_column(String(10), default="normal")
    status: Mapped[str] = mapped_column(String(20), default="open")
    subject: Mapped[str] = mapped_column(String(300))
    description: Mapped[str | None] = mapped_column(Text)
    assigned_to: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    last_reminder_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class TicketMessage(IdMixin, TenantMixin, Base):
    __tablename__ = "ticket_messages"
    __table_args__ = (CheckConstraint("visibility IN ('public','internal')", name="ck_tm_visibility"),)
    ticket_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("tickets.id"), index=True)
    sender_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("users.id"))
    body: Mapped[str] = mapped_column(Text)
    visibility: Mapped[str] = mapped_column(String(10), default="public")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Approval(IdMixin, TenantMixin, Base):
    __tablename__ = "approvals"
    __table_args__ = (CheckConstraint("status IN ('pending','approved','rejected','changes_requested','expired')",
                                      name="ck_approval_status"),)
    requested_by: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("users.id"))
    approver_role: Mapped[str] = mapped_column(String(80))                    # roles allowed to decide (policy)
    action_type: Mapped[str] = mapped_column(String(40), index=True)
    target_type: Mapped[str] = mapped_column(String(40))
    target_id: Mapped[uuid.UUID] = mapped_column(Uuid)
    payload: Mapped[dict] = mapped_column(JSONType, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    decision_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    decision_note: Mapped[str | None] = mapped_column(Text)
    execution_result: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


# ------------------------------------------------------------------ business modules (stage 2)
class Load(IdMixin, TimeMixin, TenantMixin, Base):
    __tablename__ = "loads"
    __table_args__ = (UniqueConstraint("company_id", "load_number", name="uq_load_number"),
                      CheckConstraint("status IN ('assigned','picked_up','delivered','pod_received','invoiced',"
                                      "'cancelled')", name="ck_load_status"))
    load_number: Mapped[str] = mapped_column(String(40))
    broker: Mapped[str | None] = mapped_column(String(200))
    pickup_address: Mapped[str | None] = mapped_column(String(300))
    delivery_address: Mapped[str | None] = mapped_column(String(300))
    pickup_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    delivery_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    driver_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("drivers.id"), index=True)
    truck_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("trucks.id"))
    status: Mapped[str] = mapped_column(String(20), default="assigned")
    rate_cents: Mapped[int | None] = mapped_column(BigInteger)          # money: visible only with accounting.view
    created_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))


class Document(IdMixin, TenantMixin, Base):
    """Metadata of a file. The bytes stay in the storage backend (Telegram's private file store for now)."""
    __tablename__ = "documents"
    doc_type: Mapped[str] = mapped_column(String(20), index=True)       # BOL POD PTI RC CDL MEDICAL RECEIPT OTHER
    related_type: Mapped[str] = mapped_column(String(20))              # load driver truck ticket pti
    related_id: Mapped[uuid.UUID] = mapped_column(Uuid, index=True)
    storage: Mapped[str] = mapped_column(String(20), default="telegram")
    file_ref: Mapped[str] = mapped_column(String(300))                 # backend reference (Telegram file_id)
    file_name: Mapped[str | None] = mapped_column(String(300))
    mime_type: Mapped[str | None] = mapped_column(String(100))
    size_bytes: Mapped[int | None] = mapped_column(BigInteger)
    confidential: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)     # superseded files are kept, not shown
    uploaded_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class PtiRequest(IdMixin, TenantMixin, Base):
    __tablename__ = "pti_requests"
    __table_args__ = (CheckConstraint("status IN ('requested','submitted','approved','redo')", name="ck_pti_status"),)
    driver_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("drivers.id"), index=True)
    requested_by: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("users.id"))
    batch: Mapped[str | None] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(20), default="requested")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reviewed_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class EldMalfunction(IdMixin, TenantMixin, Base):
    __tablename__ = "eld_malfunctions"
    __table_args__ = (CheckConstraint("status IN ('open','resolved')", name="ck_eld_status"),)
    driver_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("drivers.id"), index=True)
    truck_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("trucks.id"))
    fault: Mapped[str] = mapped_column(Text)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    status: Mapped[str] = mapped_column(String(20), default="open")
    ticket_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("tickets.id"))
    reported_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    last_reminder_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


# ------------------------------------------------------------------ web login (stage 3)
class LoginCode(IdMixin, Base):
    """One-time code sent to the user's Telegram. Only a hash is stored."""
    __tablename__ = "login_codes"
    user_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("users.id"), index=True)
    code_hash: Mapped[str] = mapped_column(String(64))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    used: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class WebSession(IdMixin, Base):
    """Server-side session; the browser holds a random token, we store its hash."""
    __tablename__ = "web_sessions"
    user_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("users.id"), index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    company_id: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("companies.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


# ------------------------------------------------------------------ billing (stage 4)
class Plan(IdMixin, Base):
    __tablename__ = "plans"
    code: Mapped[str] = mapped_column(String(30), unique=True)
    name: Mapped[str] = mapped_column(String(60))
    max_drivers: Mapped[int] = mapped_column(Integer)
    max_trucks: Mapped[int] = mapped_column(Integer)
    max_users: Mapped[int] = mapped_column(Integer)
    price_cents: Mapped[int] = mapped_column(BigInteger, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class Subscription(IdMixin, TimeMixin, Base):
    __tablename__ = "subscriptions"
    __table_args__ = (CheckConstraint("status IN ('trial','active','past_due','canceled')", name="ck_sub_status"),)
    company_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("companies.id"), unique=True)
    plan_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("plans.id"))
    status: Mapped[str] = mapped_column(String(20), default="active")
    period_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


# ------------------------------------------------------------------ AI manager (stage 5)
class AiSetting(Base):
    """AI is OFF for every company until someone with ai_agents.edit turns it on."""
    __tablename__ = "ai_settings"
    company_id: Mapped[uuid.UUID] = mapped_column(Uuid, ForeignKey("companies.id"), primary_key=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    updated_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AiProposal(IdMixin, TenantMixin, Base):
    """What an AI agent SUGGESTS. Nothing happens until a human applies it with his own permissions."""
    __tablename__ = "ai_proposals"
    __table_args__ = (CheckConstraint("status IN ('proposed','applied','dismissed')", name="ck_aip_status"),)
    agent: Mapped[str] = mapped_column(String(40), index=True)
    kind: Mapped[str] = mapped_column(String(20))                      # priority | summary | reminder
    payload: Mapped[dict] = mapped_column(JSONType, default=dict)
    status: Mapped[str] = mapped_column(String(20), default="proposed")
    risk: Mapped[str] = mapped_column(String(10), default="low")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    decided_by: Mapped[uuid.UUID | None] = mapped_column(Uuid, ForeignKey("users.id"))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
