"""Backup, restore and verification. SQLite: file copy through the sqlite backup API. PostgreSQL: pg_dump/pg_restore
(must be installed on the machine that runs the command)."""
import glob
import os
import shutil
import sqlite3
import subprocess
from datetime import datetime, timezone
from urllib.parse import urlsplit

from . import config

BACKUP_DIR = os.environ.get("BACKUP_DIR", "backups")


class OpsError(Exception):
    pass


def _is_sqlite():
    return config.DATABASE_URL.startswith("sqlite")


def _sqlite_path():
    return urlsplit(config.DATABASE_URL).path.lstrip("/") if config.DATABASE_URL.count("/") <= 3 \
        else config.DATABASE_URL.split("sqlite:///", 1)[1]


def _pg_url():
    return config.DATABASE_URL.replace("postgresql+psycopg://", "postgresql://", 1)


def _tool(name):
    path = shutil.which(name)
    if not path:
        raise OpsError(f"{name} is not installed on this machine (install the PostgreSQL client tools)")
    return path


def backup(keep=14):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    if _is_sqlite():
        target = os.path.join(BACKUP_DIR, f"helpbot-{stamp}.db")
        src, dst = sqlite3.connect(_sqlite_path()), sqlite3.connect(target)
        with dst:
            src.backup(dst)
        src.close()
        dst.close()
    else:
        target = os.path.join(BACKUP_DIR, f"helpbot-{stamp}.dump")
        subprocess.run([_tool("pg_dump"), "--format=custom", "--no-owner", "--file", target, _pg_url()], check=True,
                       capture_output=True)
    verify(target)
    old = sorted(glob.glob(os.path.join(BACKUP_DIR, "helpbot-*")))[:-max(keep, 1)]
    for f in old:                                                            # simple retention
        os.remove(f)
    return target


def verify(path):
    """A backup that was never verified is not a backup."""
    if not os.path.exists(path) or os.path.getsize(path) == 0:
        raise OpsError("backup file is missing or empty")
    if path.endswith(".db"):
        con = sqlite3.connect(path)
        try:
            if con.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise OpsError("sqlite integrity check failed")
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            con.close()
        if not {"users", "companies", "audit_logs"} <= tables:
            raise OpsError("backup does not contain the expected tables")
    else:
        out = subprocess.run([_tool("pg_restore"), "--list", path], check=True, capture_output=True, text=True).stdout
        if "audit_logs" not in out:
            raise OpsError("backup does not contain the expected tables")
    return True


def restore(path, confirmed=False):
    """DESTRUCTIVE: replaces the current data. Stop the bot and the web process first."""
    if not confirmed:
        raise OpsError("restore replaces ALL current data: run again with --yes after stopping the app")
    verify(path)
    if _is_sqlite():
        dest = _sqlite_path()
        if os.path.exists(dest):
            shutil.copy2(dest, dest + ".before-restore")                      # safety copy
        shutil.copy2(path, dest)
    else:
        subprocess.run([_tool("pg_restore"), "--clean", "--if-exists", "--no-owner", "--dbname", _pg_url(), path],
                       check=True, capture_output=True)
