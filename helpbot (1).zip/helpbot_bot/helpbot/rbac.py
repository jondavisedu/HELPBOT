"""Roles, permissions and the request context (Ctx).

DENY BY DEFAULT: a permission exists only if a role grants it, the Owner granted it to the user, or the user is
the platform Owner. UI visibility is never authorization: every service function calls ctx.require()."""
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

from sqlalchemy import or_, select

from .models import (Company, CompanyUser, Permission, Role, RolePermission, User, UserPermission, as_utc)


class PermissionDenied(Exception):
    def __init__(self, code=""):
        super().__init__(code)
        self.code = code


MODULES = ["overview", "companies", "users_access", "drivers", "fleet", "dispatch", "maintenance", "eld_service",
           "safety", "hr", "accounting", "documents", "tickets", "ai_agents", "automation", "approvals", "billing",
           "reports", "audit", "settings", "telegram"]
ACTIONS = ["view", "create", "edit", "delete", "approve", "export", "manage", "assign", "invite"]
SPECIAL_PERMISSIONS = {                       # granted only by the Owner (never by a role default)
    "company.create": ("platform", "create"),
    "platform.cross_company": ("platform", "view"),
    "telegram.link_group": ("telegram", "manage"),
    "telegram.update_admin": ("telegram", "manage"),
    "ai.visibility": ("ai_agents", "view"),
}

PLATFORM_ROLES = {"owner", "super_admin"}
SELF_ROLES = {"driver", "client"}             # see only their own records
ROLES = {                                     # name -> scope   (blueprint 03; `maintenance` role added: it was
    "owner": "platform", "super_admin": "platform",           # used by module_defaults but missing from roles)
    "company_admin": "company", "manager": "company", "dispatcher": "company", "eld_support": "company",
    "safety_officer": "company", "hr": "company", "accountant": "company", "maintenance": "company",
    "driver": "self", "client": "client", "viewer": "company",
}
ASSIGNABLE_BY_COMPANY_ADMIN = {"manager", "dispatcher", "eld_support", "safety_officer", "hr", "accountant",
                               "maintenance", "driver", "client", "viewer"}

_STAFF = ["owner", "super_admin", "company_admin", "manager"]
MODULE_ROLES = {                              # blueprint 03 module_defaults (+ overview/telegram)
    "overview": _STAFF + ["viewer"],
    "companies": ["owner", "super_admin"],
    "users_access": ["owner", "super_admin", "company_admin"],
    "drivers": _STAFF + ["hr", "dispatcher", "eld_support", "safety_officer"],
    "fleet": _STAFF + ["dispatcher", "maintenance", "eld_support"],
    "dispatch": _STAFF + ["dispatcher"],
    "maintenance": _STAFF + ["maintenance", "eld_support"],
    "eld_service": _STAFF + ["eld_support"],
    "safety": _STAFF + ["safety_officer"],
    "hr": _STAFF + ["hr"],
    "accounting": _STAFF + ["accountant"],
    "documents": _STAFF + ["hr", "safety_officer", "accountant"],
    "tickets": _STAFF + ["dispatcher", "eld_support", "safety_officer", "hr", "accountant", "maintenance",
                         "driver", "client"],
    "ai_agents": ["owner", "super_admin", "manager"],
    "automation": ["owner", "super_admin", "company_admin"],
    "approvals": ["owner", "super_admin", "manager", "company_admin"],
    "billing": ["owner", "super_admin", "company_admin"],
    "reports": _STAFF + ["accountant"],
    "audit": ["owner", "super_admin"],
    "settings": ["owner", "super_admin", "company_admin"],
    "telegram": ["owner", "super_admin", "company_admin", "manager"],
}
ROLE_ACTIONS = {                              # what a role may do inside the modules it can access
    "company_admin": set(ACTIONS),
    "manager": {"view", "create", "edit", "assign", "approve", "export"},
    "dispatcher": {"view", "create", "edit", "assign"}, "eld_support": {"view", "create", "edit", "assign"},
    "safety_officer": {"view", "create", "edit", "assign"}, "hr": {"view", "create", "edit", "assign"},
    "accountant": {"view", "create", "edit", "assign"}, "maintenance": {"view", "create", "edit", "assign"},
    "driver": {"view", "create"}, "client": {"view", "create"}, "viewer": {"view"},
    "super_admin": set(),                     # only explicit Owner grants
}
# Tickets: which module's *view* permission is needed to see a ticket of this category
CATEGORY_MODULE = {"dispatch": "dispatch", "maintenance": "maintenance", "eld": "eld_service", "safety": "safety",
                   "hr": "hr", "accounting": "accounting", "other": "tickets"}
CONFIDENTIAL_CATEGORIES = {"hr", "accounting"}   # never echoed into Telegram groups


def all_permission_codes():
    codes = {f"{m}.{a}": (m, a) for m in MODULES for a in ACTIONS}
    codes.update(SPECIAL_PERMISSIONS)
    return codes


def role_permission_codes(role):
    """Default permission codes of a role (owner = everything, handled as a wildcard elsewhere)."""
    actions = ROLE_ACTIONS.get(role, set())
    out = set()
    for module, roles in MODULE_ROLES.items():
        if role in roles:
            out |= {f"{module}.{a}" for a in actions}
    if role in SELF_ROLES:                    # drivers/clients: tickets only
        out = {f"tickets.{a}" for a in actions}
    return out


def seed_rbac(s):
    """Idempotently create roles, permissions and their links."""
    roles = {r.name: r for r in s.scalars(select(Role))}
    for name, scope in ROLES.items():
        if name not in roles:
            roles[name] = Role(name=name, scope=scope)
            s.add(roles[name])
    perms = {p.code: p for p in s.scalars(select(Permission))}
    for code, (module, action) in all_permission_codes().items():
        if code not in perms:
            perms[code] = Permission(code=code, module=module, action=action)
            s.add(perms[code])
    s.flush()
    existing = {(rp.role_id, rp.permission_id) for rp in s.scalars(select(RolePermission))}
    for name in ROLES:
        if name in PLATFORM_ROLES:
            continue
        for code in role_permission_codes(name):
            key = (roles[name].id, perms[code].id)
            if key not in existing:
                s.add(RolePermission(role_id=key[0], permission_id=key[1]))
                existing.add(key)
    s.flush()


# ------------------------------------------------------------------ request context
@dataclass
class Ctx:
    user_id: uuid.UUID | None
    telegram_user_id: int | None
    full_name: str
    lang: str
    company_id: uuid.UUID | None
    is_owner: bool = False
    platform_role: str | None = None
    roles: frozenset = frozenset()
    perms: frozenset = frozenset()
    blocked: bool = False                     # company suspended/archived: everything denied (data is kept)
    readonly: bool = False                    # unpaid / expired plan: only *.view permissions work
    chat_id: int | None = None
    channel: str = "telegram"
    outbox: list = field(default_factory=list)

    def can(self, code):
        if self.is_owner:
            return True
        if self.blocked:
            return False
        if self.readonly and not code.endswith(".view"):
            return False
        return code in self.perms

    def require(self, code):
        if not self.can(code):
            raise PermissionDenied(code)

    def require_owner(self):
        if not self.is_owner:
            raise PermissionDenied("owner")

    @property
    def self_scoped(self):
        """True for accounts that only ever see their own records (driver/client)."""
        return bool(self.roles) and self.roles <= SELF_ROLES and not self.platform_role


@dataclass
class Notify:
    user_id: uuid.UUID
    key: str
    params: dict
    buttons: list | None = None               # [(label_key, callback_data)]


@dataclass
class GroupPost:
    company_id: uuid.UUID
    group_type: str
    key: str
    params: dict
    buttons: list | None = None


def build_ctx(s, user, company_id=None, chat_id=None, channel="telegram"):
    """Build the verified context of `user` for `company_id` (None = no company).
    Returns a Ctx whose permissions are empty unless the user is active and a member of the company."""
    base = dict(user_id=user.id, telegram_user_id=user.telegram_user_id, full_name=user.full_name,
                lang=user.preferred_language, chat_id=chat_id, channel=channel)
    if user.status != "active":
        return Ctx(company_id=None, **base)
    is_owner = user.platform_role == "owner"
    if is_owner:
        return Ctx(company_id=company_id, is_owner=True, platform_role="owner", roles=frozenset({"owner"}), **base)
    perms, roles, blocked, readonly = set(), set(), False, False
    if company_id is not None:
        company = s.get(Company, company_id)
        if company is None:
            return Ctx(company_id=None, **base)
        rows = s.execute(select(Role.name, Role.id).join(CompanyUser, CompanyUser.role_id == Role.id)
                         .where(CompanyUser.user_id == user.id, CompanyUser.company_id == company_id,
                                CompanyUser.status == "active")).all()
        if not rows and not user.platform_role:
            return Ctx(company_id=None, **base)            # not a member: no access, nothing disclosed
        roles = {r[0] for r in rows}
        role_ids = [r[1] for r in rows]
        if role_ids:
            perms |= set(s.scalars(select(Permission.code).join(RolePermission,
                                                                RolePermission.permission_id == Permission.id)
                                   .where(RolePermission.role_id.in_(role_ids))))
        blocked = company.status in ("suspended", "archived")
        from .services import billing
        readonly = billing.is_readonly(s, company_id)
    now = datetime.now(timezone.utc)
    grants = s.execute(select(Permission.code, UserPermission.expires_at)
                       .join(UserPermission, UserPermission.permission_id == Permission.id)
                       .where(UserPermission.user_id == user.id,
                              or_(UserPermission.company_id == company_id, UserPermission.company_id.is_(None)))).all()
    for code, expires in grants:
        if expires is None or as_utc(expires) > now:
            perms.add(code)
    return Ctx(company_id=company_id if (roles or user.platform_role) else None,
               platform_role=user.platform_role, roles=frozenset(roles), perms=frozenset(perms), blocked=blocked, readonly=readonly,
               **base)
