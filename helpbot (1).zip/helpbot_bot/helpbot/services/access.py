"""Identity & access: users, registration (Owner approval only), companies, memberships, permission grants."""
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select

from .. import audit, config
from ..models import (Company, CompanyUser, Permission, RegistrationRequest, Role, User, UserPermission, as_utc,
                      utcnow)
from ..rbac import (ASSIGNABLE_BY_COMPANY_ADMIN, ROLES, Ctx, Notify, PermissionDenied, all_permission_codes)
from .errors import NotFound, ServiceError

REGISTRATION_COOLDOWN = timedelta(minutes=10)


# ------------------------------------------------------------------ users
def detect_language(code):
    code = (code or "").lower()
    return "uz" if code.startswith("uz") else "ru" if code.startswith("ru") else "en"


def get_user_by_tg(s, tg_id):
    return s.scalar(select(User).where(User.telegram_user_id == tg_id))


def upsert_user(s, tg_user, language=None):
    """Create (status 'pending') or refresh the account of a Telegram user. Owner ids become the Owner."""
    user = get_user_by_tg(s, tg_user.id)
    name = " ".join(p for p in (tg_user.first_name, tg_user.last_name) if p) or "User"
    if user is None:
        user = User(telegram_user_id=tg_user.id, full_name=name, telegram_username=tg_user.username,
                    preferred_language=language or detect_language(getattr(tg_user, "language_code", None)),
                    status="pending")
        s.add(user)
        s.flush()
        audit.record(s, action="user_created", object_type="user", object_id=user.id, actor_user_id=user.id,
                     actor_type="system")
    else:
        user.full_name, user.telegram_username = name, tg_user.username
    if tg_user.id in config.OWNER_IDS and (user.platform_role != "owner" or user.status != "active"):
        user.platform_role, user.status = "owner", "active"
        audit.record(s, action="owner_bootstrap", object_type="user", object_id=user.id, actor_type="system")
    return user


def ensure_owners(s):
    """Create the Owner accounts named in OWNER_TELEGRAM_ID (idempotent)."""
    for tg_id in config.OWNER_IDS:
        user = get_user_by_tg(s, tg_id)
        if user is None:
            user = User(telegram_user_id=tg_id, full_name="Owner", preferred_language=config.DEFAULT_LANGUAGE,
                        status="active", platform_role="owner")
            s.add(user)
        elif user.platform_role != "owner":
            user.platform_role, user.status = "owner", "active"
    s.flush()


def owners(s):
    return list(s.scalars(select(User).where(User.platform_role == "owner", User.status == "active")))


def set_language(s, user, lang):
    if lang not in config.LANGUAGES:
        raise ServiceError("err.invalid")
    user.preferred_language = lang


# ------------------------------------------------------------------ registration: only the Owner decides
def request_access(s, user, company_name=None, message=None):
    """Returns (request, created). Rate limited; one open request at a time."""
    if user.status == "active":
        raise ServiceError("reg.already_active")
    if user.status == "suspended":
        raise ServiceError("err.denied")
    pending = s.scalar(select(RegistrationRequest).where(RegistrationRequest.user_id == user.id,
                                                         RegistrationRequest.status == "pending"))
    if pending:
        return pending, False
    last = s.scalar(select(RegistrationRequest).where(RegistrationRequest.user_id == user.id)
                    .order_by(RegistrationRequest.created_at.desc()))
    if last and datetime.now(timezone.utc) - as_utc(last.created_at) < REGISTRATION_COOLDOWN:
        raise ServiceError("reg.rate_limited")
    req = RegistrationRequest(user_id=user.id, requested_company_name=(company_name or "")[:200] or None,
                              message=(message or "")[:1000] or None)
    s.add(req)
    s.flush()
    audit.record(s, action="registration_requested", object_type="registration_request", object_id=req.id,
                 actor_user_id=user.id)
    return req, True


def notify_owners_of_request(s, ctx, req, user):
    for o in owners(s):
        ctx.outbox.append(Notify(o.id, "reg.new_request", {
            "name": user.full_name, "username": user.telegram_username or "-", "tg_id": user.telegram_user_id,
            "company": req.requested_company_name or "-", "message": req.message or "-"},
            [("btn.approve", f"rr:{req.id.hex[:8]}:ok"), ("btn.reject", f"rr:{req.id.hex[:8]}:no")]))


def find_by_prefix(s, model, prefix, extra=()):
    """Resolve an 8-char id prefix from a Telegram button to one row (None if absent or ambiguous)."""
    rows = [r for r in s.scalars(select(model).where(*extra)) if r.id.hex.startswith(prefix)]
    return rows[0] if len(rows) == 1 else None


def pending_requests(ctx, s):
    ctx.require_owner()
    return list(s.execute(select(RegistrationRequest, User).join(User, User.id == RegistrationRequest.user_id)
                          .where(RegistrationRequest.status == "pending")
                          .order_by(RegistrationRequest.created_at)).all())


def decide_registration(ctx, s, req_id, approve, note=None):
    """OWNER ONLY. Approve activates the account; the Owner then assigns a company and role."""
    ctx.require_owner()
    req = s.get(RegistrationRequest, req_id)
    if req is None or req.status != "pending":
        raise NotFound("reg.not_pending")
    user = s.get(User, req.user_id)
    req.status = "approved" if approve else "rejected"
    req.reviewed_by, req.reviewed_at, req.review_note = ctx.user_id, utcnow(), note
    user.status = "active" if approve else "rejected"
    audit.record(s, ctx=ctx, action="registration_approved" if approve else "registration_rejected",
                 object_type="user", object_id=user.id, before={"status": "pending"}, after={"status": user.status},
                 reason=note)
    ctx.outbox.append(Notify(user.id, "reg.approved" if approve else "reg.rejected", {}))
    return req, user


# ------------------------------------------------------------------ companies
def has_company_create_grant(s, user_id):
    now = datetime.now(timezone.utc)
    rows = s.execute(select(UserPermission.expires_at).join(Permission, Permission.id == UserPermission.permission_id)
                     .where(UserPermission.user_id == user_id, Permission.code == "company.create",
                            UserPermission.company_id.is_(None))).all()
    return any(r[0] is None or as_utc(r[0]) > now for r in rows)


def create_company(ctx, s, name):
    """Owner, or a Company Admin holding the Owner-granted `company.create` permission."""
    name = " ".join((name or "").split())
    if not (ctx.is_owner or has_company_create_grant(s, ctx.user_id)):
        raise PermissionDenied("company.create")
    if len(name) < 2:
        raise ServiceError("err.invalid")
    if s.scalar(select(Company).where(func.lower(Company.name) == name.lower())):
        raise ServiceError("company.exists")
    c = Company(name=name, status="active", created_by=ctx.user_id)
    s.add(c)
    s.flush()
    if not ctx.is_owner:                                    # creator administers the new company
        role = s.scalar(select(Role).where(Role.name == "company_admin"))
        s.add(CompanyUser(company_id=c.id, user_id=ctx.user_id, role_id=role.id))
    audit.record(s, ctx=ctx, company_id=c.id, action="company_created", object_type="company", object_id=c.id,
                 after={"name": name})
    return c


def list_companies(ctx, s):
    """Owner: every company. Others: only companies they are an active member of."""
    if ctx.is_owner:
        return list(s.scalars(select(Company).order_by(Company.name)))
    return list(s.scalars(select(Company).join(CompanyUser, CompanyUser.company_id == Company.id)
                          .where(CompanyUser.user_id == ctx.user_id, CompanyUser.status == "active")
                          .distinct().order_by(Company.name)))


def company_by_prefix(ctx, s, prefix):
    return next((c for c in list_companies(ctx, s) if c.id.hex.startswith(prefix)), None)


def company_by_name(ctx, s, name):
    name = (name or "").strip().lower()
    return next((c for c in list_companies(ctx, s) if c.name.lower() == name), None)


def set_active_company(ctx, s, user, company_id):
    if not any(c.id == company_id for c in list_companies(ctx, s)):
        raise PermissionDenied("company.switch")
    user.active_company_id = company_id


# ------------------------------------------------------------------ memberships and permissions
def list_members(ctx, s):
    ctx.require("users_access.view")
    return list(s.execute(select(User, Role.name, CompanyUser.status)
                          .join(CompanyUser, CompanyUser.user_id == User.id).join(Role, Role.id == CompanyUser.role_id)
                          .where(CompanyUser.company_id == ctx.company_id, CompanyUser.status != "removed")
                          .order_by(User.full_name)).all())


def assign_role(ctx, s, target_user_id, role_name, company_id=None):
    """Owner: any company-scope role anywhere. Company Admin: only inside their company, never admin/platform roles."""
    company_id = company_id or ctx.company_id
    if company_id is None:
        raise ServiceError("err.no_company")
    if not ctx.is_owner:
        ctx.require("users_access.manage")
        if company_id != ctx.company_id or role_name not in ASSIGNABLE_BY_COMPANY_ADMIN:
            raise PermissionDenied("users_access.manage")
    role = s.scalar(select(Role).where(Role.name == role_name))
    if role is None or ROLES.get(role_name) == "platform":
        raise ServiceError("err.invalid")
    target = s.get(User, target_user_id)
    if target is None or target.status != "active":
        raise ServiceError("user.not_active")
    if s.get(Company, company_id) is None:
        raise NotFound()
    cu = s.scalar(select(CompanyUser).where(CompanyUser.company_id == company_id, CompanyUser.user_id == target.id,
                                            CompanyUser.role_id == role.id))
    already_member = s.scalar(select(CompanyUser.id).where(CompanyUser.company_id == company_id,
                                                            CompanyUser.user_id == target.id,
                                                            CompanyUser.status == "active"))
    if not already_member:
        from . import billing
        billing.check_limit(s, company_id, "users")
    if cu is None:
        s.add(CompanyUser(company_id=company_id, user_id=target.id, role_id=role.id))
    else:
        cu.status = "active"
    if target.active_company_id is None:
        target.active_company_id = company_id
    audit.record(s, ctx=ctx, company_id=company_id, action="role_assigned", object_type="user",
                 object_id=target.id, after={"role": role_name})
    ctx.outbox.append(Notify(target.id, "user.role_assigned", {"role": role_name}))
    return target


def remove_member(ctx, s, target_user_id):
    ctx.require("users_access.manage")
    rows = list(s.scalars(select(CompanyUser).where(CompanyUser.company_id == ctx.company_id,
                                                    CompanyUser.user_id == target_user_id,
                                                    CompanyUser.status != "removed")))
    if not rows:
        raise NotFound()
    for cu in rows:
        cu.status = "removed"
    audit.record(s, ctx=ctx, action="member_removed", object_type="user", object_id=target_user_id)


def grant_permission(ctx, s, target_user_id, code, company_id=None, expires_at=None):
    """OWNER ONLY. Extra permissions are the only way to exceed a role (e.g. company.create, telegram.link_group)."""
    ctx.require_owner()
    if code not in all_permission_codes():
        raise ServiceError("err.invalid")
    perm = s.scalar(select(Permission).where(Permission.code == code))
    target = s.get(User, target_user_id)
    if perm is None or target is None:
        raise NotFound()
    s.add(UserPermission(company_id=company_id, user_id=target.id, permission_id=perm.id, granted_by=ctx.user_id,
                         expires_at=expires_at))
    audit.record(s, ctx=ctx, company_id=company_id, action="permission_granted", object_type="user",
                 object_id=target.id, after={"code": code})
    ctx.outbox.append(Notify(target.id, "user.perm_granted", {"code": code}))


def revoke_permission(ctx, s, target_user_id, code):
    ctx.require_owner()
    perm = s.scalar(select(Permission).where(Permission.code == code))
    rows = list(s.scalars(select(UserPermission).where(UserPermission.user_id == target_user_id,
                                                       UserPermission.permission_id == (perm.id if perm else None))))
    for r in rows:
        s.delete(r)
    audit.record(s, ctx=ctx, action="permission_revoked", object_type="user", object_id=target_user_id,
                 after={"code": code, "count": len(rows)})
    return len(rows)


def suspend_platform_user(ctx, s, target_user_id, reason):
    """OWNER ONLY (the Owner is the top authority). The Owner account itself can never be suspended here."""
    ctx.require_owner()
    target = s.get(User, target_user_id)
    if target is None:
        raise NotFound()
    if target.platform_role == "owner":
        raise PermissionDenied("owner.protected")
    before = target.status
    target.status = "suspended"
    audit.record(s, ctx=ctx, action="user_suspended", object_type="user", object_id=target.id,
                 before={"status": before}, after={"status": "suspended"}, reason=reason)
