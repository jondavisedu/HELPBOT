"""AI Manager. HARD RULES:
 - AI is OFF for a company until someone with ai_agents.edit turns it on.
 - An agent only creates PROPOSALS. Nothing changes until a human applies one, and applying runs with the human's own
   permissions (AI can never do more than the person who clicked).
 - Confidential categories (HR, accounting) are never read by any agent or sent to any provider.
 - Only the ticket SUBJECT may leave the system, and only when an external provider is configured.
 - No critical action exists for AI (no terminate, suspend, payments, permission changes)."""
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from .. import audit, config
from ..models import (AiProposal, AiSetting, Approval, EldMalfunction, Load, Ticket, as_utc, utcnow)
from ..rbac import CONFIDENTIAL_CATEGORIES, GroupPost
from . import tickets
from .errors import NotFound, ServiceError

log = logging.getLogger("helpbot.ai")
AGENTS = ("ticket_triage", "daily_summary", "risk_watch")
URGENT = ("accident", "crash", "stranded", "fire", "injur", "emergency", "авари", "срочно", "пожар", "avariya",
          "shoshilinch", "yong'in")
HIGH = ("breakdown", "broke", "broken", "late", "delay", "flat tire", "stuck", "поломк", "слом", "опозда", "задерж",
        "buzil", "kechik", "yo'lda qoldi")


# ------------------------------------------------------------------ providers
class RuleProvider:
    """Built-in keyword rules. Nothing leaves the server."""
    name = "rules"

    def classify_priority(self, subject):
        low = (subject or "").lower()
        if any(k in low for k in URGENT):
            return "urgent"
        if any(k in low for k in HIGH):
            return "high"
        return None


class AnthropicProvider(RuleProvider):
    """Optional: asks a Claude model to classify ONE ticket subject. Any failure falls back to the rules."""
    name = "claude"

    def classify_priority(self, subject):
        try:
            import httpx
            r = httpx.post("https://api.anthropic.com/v1/messages", timeout=15,
                           headers={"x-api-key": config.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01"},
                           json={"model": config.AI_MODEL, "max_tokens": 5,
                                 "system": "Classify the urgency of a trucking support ticket subject. "
                                           "Answer with exactly one word: urgent, high or normal.",
                                 "messages": [{"role": "user", "content": (subject or "")[:300]}]})
            word = r.json()["content"][0]["text"].strip().lower()
            if word in ("urgent", "high", "normal"):
                return None if word == "normal" else word
        except Exception:
            log.warning("AI provider failed; using rules")
        return super().classify_priority(subject)


def get_provider():
    return AnthropicProvider() if config.ANTHROPIC_API_KEY else RuleProvider()


# ------------------------------------------------------------------ settings
def is_enabled(s, company_id):
    row = s.get(AiSetting, company_id)
    return bool(row and row.enabled)


def set_enabled(ctx, s, enabled):
    ctx.require("ai_agents.edit")
    row = s.get(AiSetting, ctx.company_id)
    if row is None:
        row = AiSetting(company_id=ctx.company_id, enabled=bool(enabled), updated_by=ctx.user_id)
        s.add(row)
    else:
        row.enabled, row.updated_by, row.updated_at = bool(enabled), ctx.user_id, utcnow()
    audit.record(s, ctx=ctx, action="ai_enabled" if enabled else "ai_disabled", object_type="company",
                 object_id=ctx.company_id)


# ------------------------------------------------------------------ agents (they only PROPOSE)
def _exists(s, company_id, agent, key):
    for p in s.scalars(select(AiProposal).where(AiProposal.company_id == company_id, AiProposal.agent == agent,
                                                AiProposal.status.in_(["proposed", "applied"]))):
        if p.payload.get("key") == key:
            return True
    return False


def _propose(s, company_id, agent, kind, payload):
    p = AiProposal(company_id=company_id, agent=agent, kind=kind, payload=payload, risk="low")
    s.add(p)
    audit.record(s, company_id=company_id, action="ai_proposal_created", object_type="ai_proposal",
                 actor_type="ai", after={"agent": agent, "kind": kind})
    return p


def _triage(s, company_id, provider):
    n = 0
    for tk in s.scalars(select(Ticket).where(Ticket.company_id == company_id, Ticket.status == "open",
                                             Ticket.assigned_to.is_(None), Ticket.priority.in_(["low", "normal"]),
                                             Ticket.category.notin_(list(CONFIDENTIAL_CATEGORIES)))):
        key = f"prio:{tk.ticket_number}"
        if _exists(s, company_id, "ticket_triage", key):
            continue
        prio = provider.classify_priority(tk.subject)             # the subject only, nothing else
        if prio in ("high", "urgent") and prio != tk.priority:
            _propose(s, company_id, "ticket_triage", "priority",
                     {"key": key, "ticket": tk.ticket_number, "priority": prio, "reason": provider.name})
            n += 1
    return n


def _summary(s, company_id):
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    key = f"summary:{today}"
    if _exists(s, company_id, "daily_summary", key):
        return 0
    open_t = list(s.scalars(select(Ticket).where(Ticket.company_id == company_id, Ticket.status != "done",
                                                 Ticket.category.notin_(list(CONFIDENTIAL_CATEGORIES)))))
    pending = len(list(s.scalars(select(Approval.id).where(Approval.company_id == company_id,
                                                           Approval.status == "pending"))))
    delivered = list(s.scalars(select(Load).where(Load.company_id == company_id, Load.status == "delivered")))
    eld = len(list(s.scalars(select(EldMalfunction.id).where(EldMalfunction.company_id == company_id,
                                                             EldMalfunction.status == "open"))))
    _propose(s, company_id, "daily_summary", "summary",
             {"key": key, "open": len(open_t), "unassigned": sum(1 for t in open_t if t.assigned_to is None),
              "approvals": pending, "nopod": len(delivered), "eld": eld, "group": "operations"})
    return 1


def _risk(s, company_id):
    n, now = 0, datetime.now(timezone.utc)
    today = now.strftime("%Y-%m-%d")
    for m in s.scalars(select(EldMalfunction).where(EldMalfunction.company_id == company_id,
                                                    EldMalfunction.status == "open")):
        days = (now - as_utc(m.started_at)).days
        key = f"eld:{m.id.hex[:8]}:{today}"
        if days >= 5 and not _exists(s, company_id, "risk_watch", key):
            _propose(s, company_id, "risk_watch", "reminder", {"key": key, "what": "eld", "days": days, "group": "eld"})
            n += 1
    for ld in s.scalars(select(Load).where(Load.company_id == company_id, Load.status == "delivered")):
        key = f"pod:{ld.load_number}:{today}"
        if now - as_utc(ld.updated_at) > timedelta(hours=24) and not _exists(s, company_id, "risk_watch", key):
            _propose(s, company_id, "risk_watch", "reminder",
                     {"key": key, "what": "pod", "load": ld.load_number, "group": "dispatch"})
            n += 1
    for tk in s.scalars(select(Ticket).where(Ticket.company_id == company_id, Ticket.status == "open",
                                             Ticket.assigned_to.is_(None),
                                             Ticket.category.notin_(list(CONFIDENTIAL_CATEGORIES)))):
        key = f"unassigned:{tk.ticket_number}:{today}"
        if now - as_utc(tk.created_at) > timedelta(hours=24) and not _exists(s, company_id, "risk_watch", key):
            _propose(s, company_id, "risk_watch", "reminder",
                     {"key": key, "what": "ticket", "n": tk.ticket_number, "group": "operations"})
            n += 1
    return n


def run_for_company(s, company_id, provider=None):
    """Create proposals (no side effects besides proposals). Used by the human command and by the daily job."""
    if not is_enabled(s, company_id):
        raise ServiceError("ai.disabled")
    provider = provider or get_provider()
    return _triage(s, company_id, provider) + _summary(s, company_id) + _risk(s, company_id)


def run(ctx, s, provider=None):
    ctx.require("ai_agents.create")
    n = run_for_company(s, ctx.company_id, provider)
    audit.record(s, ctx=ctx, action="ai_run", object_type="company", object_id=ctx.company_id, after={"new": n})
    return n


# ------------------------------------------------------------------ humans decide
def list_proposals(ctx, s, status="proposed", limit=20):
    ctx.require("ai_agents.view")
    return list(s.scalars(select(AiProposal).where(AiProposal.company_id == ctx.company_id,
                                                   AiProposal.status == status)
                          .order_by(AiProposal.created_at.desc()).limit(limit)))


def by_prefix(ctx, s, prefix):
    rows = [p for p in s.scalars(select(AiProposal).where(AiProposal.company_id == ctx.company_id))
            if p.id.hex.startswith(prefix)]
    if len(rows) != 1:
        raise NotFound()
    return rows[0]


def render(lang, p):
    from ..i18n import t
    d = p.payload
    if p.kind == "priority":
        return t(lang, "ai.line_priority", n=d["ticket"], prio=d["priority"], reason=d.get("reason", "-"))
    if p.kind == "summary":
        return t(lang, "ai.line_summary", open=d["open"], unassigned=d["unassigned"], approvals=d["approvals"],
                 nopod=d["nopod"], eld=d["eld"])
    return {"eld": lambda: t(lang, "ai.line_eld", days=d.get("days")),
            "pod": lambda: t(lang, "ai.line_pod", load=d.get("load")),
            "ticket": lambda: t(lang, "ai.line_ticket", n=d.get("n"))}[d["what"]]()


def apply(ctx, s, proposal):
    """Runs with the HUMAN's permissions. A priority change needs tickets.edit, exactly as if he did it by hand."""
    ctx.require("ai_agents.approve")
    if proposal.status != "proposed":
        raise ServiceError("ai.not_proposed")
    d = proposal.payload
    if proposal.kind == "priority":
        tickets.set_priority(ctx, s, d["ticket"], d["priority"])
    else:
        from ..i18n import t
        ctx.outbox.append(GroupPost(ctx.company_id, d.get("group", "operations"), "ai.group_text",
                                    {"text": render(config.DEFAULT_LANGUAGE, proposal)}))
    proposal.status, proposal.decided_by, proposal.decided_at = "applied", ctx.user_id, utcnow()
    audit.record(s, ctx=ctx, action="ai_proposal_applied", object_type="ai_proposal", object_id=proposal.id,
                 after={"agent": proposal.agent, "kind": proposal.kind})


def dismiss(ctx, s, proposal):
    ctx.require("ai_agents.approve")
    if proposal.status != "proposed":
        raise ServiceError("ai.not_proposed")
    proposal.status, proposal.decided_by, proposal.decided_at = "dismissed", ctx.user_id, utcnow()
    audit.record(s, ctx=ctx, action="ai_proposal_dismissed", object_type="ai_proposal", object_id=proposal.id)


def enabled_company_ids(s_platform):
    return [r.company_id for r in s_platform.scalars(select(AiSetting).where(AiSetting.enabled.is_(True)))]
