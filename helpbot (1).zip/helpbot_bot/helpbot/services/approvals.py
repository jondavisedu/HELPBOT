"""Approval Center: critical actions stop here until an authorized human decides.
No self-approval (unless the Owner explicitly enables the policy switch). The executor re-checks everything."""
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from .. import audit, config
from ..models import (Approval, Company, CompanyUser, Driver, DriverAssignment, Permission, Role, Truck, User,
                      UserPermission, as_utc, utcnow)
from ..rbac import Notify, PermissionDenied
from .errors import NotFound, ServiceError

POLICY = {                                                   # action -> roles allowed to decide
    "driver_terminate": {"owner", "company_admin", "manager"},
    "driver_truck_reassignment": {"owner", "company_admin", "manager"},
    "user_suspend": {"owner", "company_admin"},
    "company_suspend": {"owner"},
    "permission_escalation": {"owner"},
}


def eligible(ctx, action_type):
    roles = POLICY.get(action_type, set())
    return ctx.is_owner or bool(ctx.roles & roles)


def request(ctx, s, action_type, target_type, target_id, payload, company_id=None):
    if action_type not in POLICY:
        raise ServiceError("err.invalid")
    company_id = company_id or ctx.company_id
    a = Approval(company_id=company_id, requested_by=ctx.user_id, approver_role=",".join(sorted(POLICY[action_type])),
                 action_type=action_type, target_type=target_type, target_id=target_id, payload=payload,
                 status="pending")
    s.add(a)
    s.flush()
    audit.record(s, ctx=ctx, company_id=company_id, action="approval_requested", object_type="approval",
                 object_id=a.id, after={"type": action_type})
    # tell everybody who may decide (never the requester)
    recipients = {u.id for u in s.scalars(select(User).where(User.platform_role == "owner",
                                                             User.status == "active"))}
    roles = POLICY[action_type] - {"owner"}
    if roles:
        recipients |= set(s.scalars(select(CompanyUser.user_id).join(Role, Role.id == CompanyUser.role_id)
                                    .where(CompanyUser.company_id == company_id, CompanyUser.status == "active",
                                           Role.name.in_(roles))))
    for uid in recipients - {ctx.user_id}:
        ctx.outbox.append(Notify(uid, "appr.new", {"type": action_type, "by": ctx.full_name,
                                                   "detail": _detail(payload)},
                                 [("btn.approve", f"ap:{a.id.hex[:8]}:y"), ("btn.reject", f"ap:{a.id.hex[:8]}:n")]))
    return a


def _detail(payload):
    return payload.get("name") or payload.get("driver") or payload.get("reason") or ""


def request_user_suspend(ctx, s, target_user_id, reason):
    ctx.require("users_access.manage")
    if not (reason or "").strip():
        raise ServiceError("err.reason_required")
    target = s.get(User, target_user_id)
    if target is None or target.platform_role == "owner":
        raise PermissionDenied("owner.protected")
    return request(ctx, s, "user_suspend", "user", target.id,
                   {"user_id": str(target.id), "name": target.full_name, "reason": reason})


def request_company_suspend(ctx, s, reason):
    ctx.require("companies.manage")
    if not (reason or "").strip():
        raise ServiceError("err.reason_required")
    c = s.get(Company, ctx.company_id)
    return request(ctx, s, "company_suspend", "company", c.id, {"name": c.name, "reason": reason})


def request_permission_escalation(ctx, s, target_user_id, code, reason):
    ctx.require("users_access.manage")
    return request(ctx, s, "permission_escalation", "user", target_user_id,
                   {"user_id": str(target_user_id), "code": code, "reason": reason})


def list_pending(ctx, s):
    ctx.require("approvals.view")
    rows = list(s.scalars(select(Approval).where(Approval.company_id == ctx.company_id,
                                                 Approval.status == "pending").order_by(Approval.created_at)))
    return [(a, eligible(ctx, a.action_type) and (a.requested_by != ctx.user_id or _self_ok(ctx))) for a in rows]


def _self_ok(ctx):
    return ctx.is_owner and config.ALLOW_OWNER_SELF_APPROVAL


def approval_company(approval_prefix):
    """Trusted resolver for Approve/Reject buttons: which company does this approval belong to?"""
    from .. import db
    with db.platform_session("resolve approval -> company") as s:
        rows = [a for a in s.scalars(select(Approval).where(Approval.status == "pending"))
                if a.id.hex.startswith(approval_prefix)]
        return (rows[0].company_id, rows[0].id) if len(rows) == 1 else (None, None)


def decide(ctx, s, approval_id, approve, note=None):
    ctx.require("approvals.approve")
    a = s.get(Approval, approval_id)
    if a is None or a.company_id != ctx.company_id:
        raise NotFound()
    if a.status != "pending":
        raise ServiceError("appr.not_pending")
    if not eligible(ctx, a.action_type):
        raise PermissionDenied("approvals.approve")
    if a.requested_by == ctx.user_id and not _self_ok(ctx):
        audit.record(s, ctx=ctx, action="approval_self_blocked", object_type="approval", object_id=a.id)
        raise ServiceError("appr.self")
    if as_utc(a.created_at) < datetime.now(timezone.utc) - timedelta(days=config.APPROVAL_EXPIRY_DAYS):
        a.status = "expired"
        raise ServiceError("appr.expired")
    a.decision_by, a.decision_note, a.decided_at = ctx.user_id, note, utcnow()
    if not approve:
        a.status = "rejected"
        audit.record(s, ctx=ctx, action="approval_rejected", object_type="approval", object_id=a.id,
                     after={"type": a.action_type}, reason=note)
        ctx.outbox.append(Notify(a.requested_by, "appr.rejected", {"type": a.action_type}))
        return a
    a.status = "approved"
    a.execution_result = EXECUTORS[a.action_type](ctx, s, a)
    audit.record(s, ctx=ctx, action="approval_approved", object_type="approval", object_id=a.id,
                 after={"type": a.action_type, "result": a.execution_result}, reason=note)
    ctx.outbox.append(Notify(a.requested_by, "appr.approved", {"type": a.action_type}))
    return a


def expire_stale(s_platform):
    cutoff = datetime.now(timezone.utc) - timedelta(days=config.APPROVAL_EXPIRY_DAYS)
    n = 0
    for a in s_platform.scalars(select(Approval).where(Approval.status == "pending")):
        if as_utc(a.created_at) < cutoff:
            a.status = "expired"
            audit.record(s_platform, actor_type="system", company_id=a.company_id, action="approval_expired",
                         object_type="approval", object_id=a.id)
            n += 1
    return n


# ------------------------------------------------------------------ safe action executors (run only after approval)
def _exec_driver_terminate(ctx, s, a):
    from . import fleet
    d = s.get(Driver, a.target_id)
    if d is None or d.company_id != a.company_id:
        raise NotFound("driver.not_found")
    fleet.apply_driver_status(s, a.company_id, d, "terminated", a.payload.get("reason"), a.requested_by, ctx,
                              action="driver_terminated")
    for asg in s.scalars(select(DriverAssignment).where(DriverAssignment.company_id == a.company_id,
                                                        DriverAssignment.driver_id == d.id,
                                                        DriverAssignment.ended_at.is_(None))):
        asg.ended_at = utcnow()
    return "driver terminated"


def _exec_reassignment(ctx, s, a):
    from . import fleet
    import uuid as _uuid
    d = s.get(Driver, a.target_id)
    t = s.get(Truck, _uuid.UUID(a.payload["truck_id"]))
    if d is None or t is None or d.company_id != a.company_id or t.company_id != a.company_id:
        raise NotFound()
    if t.status != "active" or d.status in ("terminated", "inactive"):
        raise ServiceError("assign.not_available")
    fleet.apply_assignment(s, a.company_id, d.id, t.id, a.requested_by, a.payload.get("reason"), ctx)
    return "truck reassigned"


def _exec_user_suspend(ctx, s, a):
    n = 0
    for cu in s.scalars(select(CompanyUser).where(CompanyUser.company_id == a.company_id,
                                                  CompanyUser.user_id == a.target_id,
                                                  CompanyUser.status == "active")):
        cu.status, n = "suspended", n + 1
    return f"{n} membership(s) suspended"


def _exec_company_suspend(ctx, s, a):
    c = s.get(Company, a.target_id)
    if c is None or c.id != a.company_id:
        raise NotFound()
    c.status = "suspended"
    return "company suspended (data retained)"


def _exec_permission_escalation(ctx, s, a):
    import uuid as _uuid
    perm = s.scalar(select(Permission).where(Permission.code == a.payload["code"]))
    if perm is None:
        raise ServiceError("err.invalid")
    s.add(UserPermission(company_id=a.company_id, user_id=_uuid.UUID(a.payload["user_id"]),
                         permission_id=perm.id, granted_by=ctx.user_id))
    return f"granted {perm.code}"


EXECUTORS = {"driver_terminate": _exec_driver_terminate, "driver_truck_reassignment": _exec_reassignment,
             "user_suspend": _exec_user_suspend, "company_suspend": _exec_company_suspend,
             "permission_escalation": _exec_permission_escalation}
