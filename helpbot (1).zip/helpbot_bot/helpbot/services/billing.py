"""Plans, limits and the read-only rule for unpaid / expired companies. Payment collection itself (Stripe etc.)
is NOT included: the Owner records payment state by hand (/plan), and a provider can call set_plan/set_status later."""
from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select

from .. import audit
from ..models import Company, CompanyUser, Driver, Plan, Subscription, Truck, as_utc, utcnow
from .errors import NotFound, ServiceError

TRIAL_DAYS = 14
DEFAULT_PLANS = [("starter", "Starter", 5, 5, 5, 0), ("growth", "Growth", 25, 25, 25, 9900),
                 ("scale", "Scale", 100, 100, 100, 29900), ("unlimited", "Unlimited", 100000, 100000, 100000, 0)]


def seed_plans(s):
    have = {p.code for p in s.scalars(select(Plan))}
    for code, name, d, t, u, price in DEFAULT_PLANS:
        if code not in have:
            s.add(Plan(code=code, name=name, max_drivers=d, max_trucks=t, max_users=u, price_cents=price))
    s.flush()


def plan_by_code(s, code):
    return s.scalar(select(Plan).where(Plan.code == (code or "").lower(), Plan.is_active.is_(True)))


def effective(s, company_id):
    """Plan, status and limits of a company. No subscription yet = a 14-day trial on the Starter plan."""
    sub = s.scalar(select(Subscription).where(Subscription.company_id == company_id))
    if sub is not None:
        plan, status, end = s.get(Plan, sub.plan_id), sub.status, sub.period_end
    else:
        company = s.get(Company, company_id)
        plan, status = plan_by_code(s, "starter"), "trial"
        end = as_utc(company.created_at) + timedelta(days=TRIAL_DAYS) if company else None
    expired = status in ("trial", "active") and end is not None and as_utc(end) < datetime.now(timezone.utc)
    readonly = status in ("past_due", "canceled") or (status == "trial" and expired)
    return {"plan": plan, "status": "past_due" if (status == "active" and expired) else status,
            "period_end": end, "readonly": readonly or (status == "active" and expired),
            "limits": {"drivers": plan.max_drivers, "trucks": plan.max_trucks, "users": plan.max_users}}


def is_readonly(s, company_id):
    return effective(s, company_id)["readonly"]


def usage(s, company_id):
    drivers = s.scalar(select(func.count(Driver.id)).where(Driver.company_id == company_id,
                                                           Driver.status != "terminated")) or 0
    trucks = s.scalar(select(func.count(Truck.id)).where(Truck.company_id == company_id,
                                                         Truck.status != "sold")) or 0
    users = s.scalar(select(func.count(func.distinct(CompanyUser.user_id))).where(
        CompanyUser.company_id == company_id, CompanyUser.status == "active")) or 0
    return {"drivers": drivers, "trucks": trucks, "users": users}


def check_limit(s, company_id, kind):
    """Raise before creating one more driver / truck / member beyond the plan."""
    limit = effective(s, company_id)["limits"][kind]
    if usage(s, company_id)[kind] >= limit:
        raise ServiceError("billing.limit", what=kind, limit=limit)


def set_plan(ctx, s, company_id, plan_code, days=30):
    ctx.require_owner()
    plan = plan_by_code(s, plan_code)
    if plan is None or s.get(Company, company_id) is None:
        raise NotFound("billing.unknown_plan")
    sub = s.scalar(select(Subscription).where(Subscription.company_id == company_id))
    end = utcnow() + timedelta(days=max(1, min(int(days), 3650)))
    if sub is None:
        sub = Subscription(company_id=company_id, plan_id=plan.id, status="active", period_end=end)
        s.add(sub)
    else:
        sub.plan_id, sub.status, sub.period_end = plan.id, "active", end
    audit.record(s, ctx=ctx, company_id=company_id, action="plan_set", object_type="company", object_id=company_id,
                 after={"plan": plan.code, "days": days})
    return sub


def set_status(ctx, s, company_id, status):
    ctx.require_owner()
    if status not in ("trial", "active", "past_due", "canceled"):
        raise ServiceError("err.invalid")
    sub = s.scalar(select(Subscription).where(Subscription.company_id == company_id))
    if sub is None:
        starter = plan_by_code(s, "starter")
        sub = Subscription(company_id=company_id, plan_id=starter.id, status=status, period_end=utcnow())
        s.add(sub)
    sub.status = status
    audit.record(s, ctx=ctx, company_id=company_id, action="subscription_status", object_type="company",
                 object_id=company_id, after={"status": status})
    return sub
