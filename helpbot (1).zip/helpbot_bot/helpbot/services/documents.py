"""Document metadata with ownership checks. Files are never public; bytes stay in the storage backend."""
from sqlalchemy import select

from .. import audit
from ..models import Document, Driver, Load, PtiRequest
from ..rbac import PermissionDenied
from .errors import ServiceError

TYPES = ["BOL", "POD", "PTI", "RC", "CDL", "MEDICAL", "RECEIPT", "OTHER"]
CONFIDENTIAL_TYPES = {"CDL", "MEDICAL", "RECEIPT"}
RELATED = {"load", "driver", "truck", "ticket", "pti"}


def _own_driver_ids(ctx, s):
    return set(s.scalars(select(Driver.id).where(Driver.company_id == ctx.company_id, Driver.user_id == ctx.user_id)))


def _owns(ctx, s, related_type, related_id):
    """May this (driver) account attach files to / read files of this record?"""
    mine = _own_driver_ids(ctx, s)
    if not mine:
        return False
    if related_type == "driver":
        return related_id in mine
    if related_type == "load":
        ld = s.get(Load, related_id)
        return bool(ld and ld.company_id == ctx.company_id and ld.driver_id in mine)
    if related_type == "pti":
        p = s.get(PtiRequest, related_id)
        return bool(p and p.company_id == ctx.company_id and p.driver_id in mine)
    return False


def can_attach(ctx, s, doc_type, related_type, related_id):
    if ctx.can("documents.create"):
        return True
    if related_type == "load" and doc_type in ("BOL", "POD") and ctx.can("dispatch.edit"):
        return True
    own_ok = {"load": {"BOL", "POD"}, "pti": {"PTI"}}.get(related_type, set())      # drivers: only their own paperwork
    return doc_type in own_ok and _owns(ctx, s, related_type, related_id)


def add_document(ctx, s, doc_type, related_type, related_id, file_ref, file_name=None, mime_type=None,
                 size_bytes=None):
    if doc_type not in TYPES or related_type not in RELATED or not file_ref:
        raise ServiceError("err.invalid")
    if not can_attach(ctx, s, doc_type, related_type, related_id):
        raise PermissionDenied("documents.create")
    d = Document(company_id=ctx.company_id, doc_type=doc_type, related_type=related_type, related_id=related_id,
                 file_ref=file_ref[:300], file_name=(file_name or "")[:300] or None, mime_type=mime_type,
                 size_bytes=size_bytes, confidential=doc_type in CONFIDENTIAL_TYPES, uploaded_by=ctx.user_id)
    s.add(d)
    s.flush()
    audit.record(s, ctx=ctx, action="document_added", object_type="document", object_id=d.id,
                 after={"type": doc_type, "related": related_type})
    return d


def list_documents(ctx, s, related_type, related_id, doc_type=None):
    q = select(Document).where(Document.company_id == ctx.company_id, Document.related_type == related_type,
                               Document.related_id == related_id, Document.is_active.is_(True))
    if doc_type:
        q = q.where(Document.doc_type == doc_type)
    if related_type == "load" and (ctx.can("dispatch.view") or ctx.can("accounting.view")) \
            and not ctx.can("documents.view"):
        q = q.where(Document.doc_type.in_(["BOL", "POD"]))                  # paperwork, not rate confirmations
    elif not ctx.can("documents.view"):
        if not _owns(ctx, s, related_type, related_id):
            raise PermissionDenied("documents.view")
        q = q.where(Document.confidential.is_(False))
    return list(s.scalars(q.order_by(Document.created_at)))


def retire_documents(s, ctx, related_type, related_id, doc_type):
    """A redo replaces old files; they stay in the database, hidden."""
    for d in s.scalars(select(Document).where(Document.company_id == ctx.company_id,
                                              Document.related_type == related_type,
                                              Document.related_id == related_id, Document.doc_type == doc_type)):
        d.is_active = False
