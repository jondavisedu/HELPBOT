"""ELD malfunctions: a ticket for the ELD team plus an 8-day clock for the paper-log requirement."""
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from .. import audit
from ..models import Driver, EldMalfunction, as_utc, utcnow
from ..rbac import GroupPost, PermissionDenied
from . import tickets
from .errors import NotFound, ServiceError

DEADLINE_DAYS = 8
REMIND_FROM_DAY = 6


def deadline(m):
    return as_utc(m.started_at) + timedelta(days=DEADLINE_DAYS)


def report_malfunction(ctx, s, driver_id, fault, truck_id=None):
    d = s.get(Driver, driver_id)
    if d is None or d.company_id != ctx.company_id:
        raise NotFound("driver.not_found")
    if not (ctx.can("eld_service.create") or (d.user_id is not None and d.user_id == ctx.user_id)):
        raise PermissionDenied("eld_service.create")
    fault = (fault or "").strip()[:2000]
    if len(fault) < 3:
        raise ServiceError("err.invalid")
    tk = tickets.create_ticket(ctx, s, "eld", f"ELD malfunction: {d.full_name}", fault, "high")
    m = EldMalfunction(company_id=ctx.company_id, driver_id=d.id, truck_id=truck_id, fault=fault, ticket_id=tk.id,
                       reported_by=ctx.user_id)
    s.add(m)
    s.flush()
    audit.record(s, ctx=ctx, action="eld_malfunction", object_type="eld_malfunction", object_id=m.id,
                 after={"driver": d.full_name, "ticket": tk.ticket_number})
    for gtype in ("dispatch", "safety"):                      # heads-up for the teams that are affected
        ctx.outbox.append(GroupPost(ctx.company_id, gtype, "eld.group_fyi",
                                    {"driver": d.full_name, "deadline": f"{deadline(m):%Y-%m-%d}"}))
    return m, tk


def list_open(ctx, s):
    ctx.require("eld_service.view")
    return list(s.execute(select(EldMalfunction, Driver.full_name).join(Driver, Driver.id == EldMalfunction.driver_id)
                          .where(EldMalfunction.company_id == ctx.company_id, EldMalfunction.status == "open")
                          .order_by(EldMalfunction.started_at)).all())


def by_prefix(ctx, s, prefix):
    rows = [m for m in s.scalars(select(EldMalfunction).where(EldMalfunction.company_id == ctx.company_id))
            if m.id.hex.startswith(prefix)]
    if len(rows) != 1:
        raise NotFound()
    return rows[0]


def resolve(ctx, s, malfunction):
    ctx.require("eld_service.edit")
    malfunction.status, malfunction.resolved_at = "resolved", utcnow()
    audit.record(s, ctx=ctx, action="eld_resolved", object_type="eld_malfunction", object_id=malfunction.id)


def due_reminders(s_platform):
    """Open malfunctions at day >= 6, at most one reminder per day. Platform scope (job)."""
    now = datetime.now(timezone.utc)
    out = []
    for m in s_platform.scalars(select(EldMalfunction).where(EldMalfunction.status == "open")):
        age = (now - as_utc(m.started_at)).days
        last = as_utc(m.last_reminder_at) if m.last_reminder_at else None
        if age >= REMIND_FROM_DAY and (last is None or now - last >= timedelta(hours=23)):
            m.last_reminder_at = utcnow()
            d = s_platform.get(Driver, m.driver_id)
            out.append((m.company_id, d.full_name if d else "-", age, f"{deadline(m):%Y-%m-%d}"))
    return out
