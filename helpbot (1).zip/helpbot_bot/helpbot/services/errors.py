class ServiceError(Exception):
    """Business-rule error with a translation key (shown to the user)."""
    def __init__(self, key, **params):
        super().__init__(key)
        self.key = key
        self.params = params


class NotFound(ServiceError):
    def __init__(self, key="err.not_found", **params):
        super().__init__(key, **params)
