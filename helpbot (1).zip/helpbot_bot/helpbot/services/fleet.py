"""Drivers, trucks and their assignments. Critical changes go through the Approval Center."""
from sqlalchemy import func, or_, select

from .. import audit
from . import billing
from ..models import (CompanyUser, Driver, DriverAssignment, DriverStatusHistory, Role, Truck, User, utcnow)
from ..rbac import PermissionDenied
from .errors import NotFound, ServiceError

DRIVER_STATUSES = ["active", "inactive", "pick_up", "terminated", "returned", "truck_change", "shop", "accident",
                   "onboarding", "pending"]
TRUCK_STATUSES = ["active", "inactive", "shop", "sold"]


# ------------------------------------------------------------------ drivers
def add_driver(ctx, s, full_name, phone=None):
    ctx.require("drivers.create")
    billing.check_limit(s, ctx.company_id, "drivers")
    name = " ".join((full_name or "").split())[:200]
    if len(name) < 2:
        raise ServiceError("err.invalid")
    d = Driver(company_id=ctx.company_id, full_name=name, phone=(phone or "")[:40] or None, status="onboarding")
    s.add(d)
    s.flush()
    s.add(DriverStatusHistory(company_id=ctx.company_id, driver_id=d.id, from_status=None, to_status="onboarding",
                              reason="created", changed_by=ctx.user_id))
    audit.record(s, ctx=ctx, action="driver_created", object_type="driver", object_id=d.id, after={"name": name})
    return d


def list_drivers(ctx, s, status=None, limit=30):
    ctx.require("drivers.view")
    q = select(Driver).where(Driver.company_id == ctx.company_id)
    if status:
        q = q.where(Driver.status == status)
    return list(s.scalars(q.order_by(Driver.full_name).limit(limit)))


def driver_by_prefix(ctx, s, prefix):
    ctx.require("drivers.view")
    rows = [d for d in s.scalars(select(Driver).where(Driver.company_id == ctx.company_id))
            if d.id.hex.startswith(prefix)]
    if len(rows) != 1:
        raise NotFound("driver.not_found")
    return rows[0]


def my_driver(ctx, s):
    """A driver account sees only its own driver record."""
    d = s.scalar(select(Driver).where(Driver.company_id == ctx.company_id, Driver.user_id == ctx.user_id))
    if d is None:
        raise NotFound("driver.no_profile")
    return d


def current_assignment(ctx, s, driver_id):
    return s.execute(select(DriverAssignment, Truck).join(Truck, Truck.id == DriverAssignment.truck_id)
                     .where(DriverAssignment.company_id == ctx.company_id, DriverAssignment.driver_id == driver_id,
                            DriverAssignment.ended_at.is_(None))).first()


def status_history(ctx, s, driver_id, limit=5):
    ctx.require("drivers.view")
    return list(s.scalars(select(DriverStatusHistory).where(DriverStatusHistory.company_id == ctx.company_id,
                                                            DriverStatusHistory.driver_id == driver_id)
                          .order_by(DriverStatusHistory.created_at.desc()).limit(limit)))


def apply_driver_status(s, company_id, driver, new_status, reason, by_user_id, ctx=None, action="driver_status"):
    before = driver.status
    driver.status = new_status
    s.add(DriverStatusHistory(company_id=company_id, driver_id=driver.id, from_status=before, to_status=new_status,
                              reason=reason, changed_by=by_user_id))
    audit.record(s, ctx=ctx, company_id=company_id, actor_user_id=by_user_id, action=action, object_type="driver",
                 object_id=driver.id, before={"status": before}, after={"status": new_status}, reason=reason)


def change_driver_status(ctx, s, driver_id, new_status, reason):
    """Returns (driver, approval|None). A reason is mandatory. Terminating needs approval."""
    ctx.require("drivers.edit")
    d = s.get(Driver, driver_id)
    if d is None or d.company_id != ctx.company_id:
        raise NotFound("driver.not_found")
    if new_status not in DRIVER_STATUSES or new_status == d.status:
        raise ServiceError("err.invalid")
    if not (reason or "").strip():
        raise ServiceError("err.reason_required")
    if d.status == "terminated":
        ctx.require("drivers.manage")                       # rehire: managers/admins only
    if new_status == "terminated":
        from . import approvals
        ap = approvals.request(ctx, s, "driver_terminate", "driver", d.id, {"driver_id": str(d.id),
                                                                           "name": d.full_name, "reason": reason})
        return d, ap
    apply_driver_status(s, ctx.company_id, d, new_status, reason.strip(), ctx.user_id, ctx)
    return d, None


def link_driver_user(ctx, s, driver_id, target_user_id):
    """Connect a driver record to the driver's own (approved, member) account."""
    ctx.require("drivers.edit")
    d = s.get(Driver, driver_id)
    if d is None or d.company_id != ctx.company_id:
        raise NotFound("driver.not_found")
    ok = s.scalar(select(CompanyUser.id).join(Role, Role.id == CompanyUser.role_id)
                  .where(CompanyUser.company_id == ctx.company_id, CompanyUser.user_id == target_user_id,
                         CompanyUser.status == "active", Role.name == "driver"))
    if not ok:
        raise ServiceError("user.not_driver")
    d.user_id = target_user_id
    audit.record(s, ctx=ctx, action="driver_linked", object_type="driver", object_id=d.id,
                 after={"user_id": str(target_user_id)})
    return d


# ------------------------------------------------------------------ trucks
def add_truck(ctx, s, unit_number, vin=None, year=None, make=None, model=None):
    ctx.require("fleet.create")
    billing.check_limit(s, ctx.company_id, "trucks")
    unit = (unit_number or "").strip().upper()[:40]
    vin = (vin or "").strip().upper()[:40] or None
    if not unit:
        raise ServiceError("err.invalid")
    clash = select(Truck.id).where(Truck.company_id == ctx.company_id,
                                   or_(Truck.unit_number == unit, Truck.vin == vin) if vin
                                   else Truck.unit_number == unit)
    if s.scalar(clash):
        raise ServiceError("truck.exists")                  # unit number and VIN are unique inside a company
    t = Truck(company_id=ctx.company_id, unit_number=unit, vin=vin, year=year, make=make, model=model,
              status="active")
    s.add(t)
    s.flush()
    audit.record(s, ctx=ctx, action="truck_created", object_type="truck", object_id=t.id,
                 after={"unit": unit, "vin": vin})
    return t


def list_trucks(ctx, s, limit=30):
    ctx.require("fleet.view")
    return list(s.scalars(select(Truck).where(Truck.company_id == ctx.company_id)
                          .order_by(Truck.unit_number).limit(limit)))


def truck_by_prefix(ctx, s, prefix):
    ctx.require("fleet.view")
    rows = [t for t in s.scalars(select(Truck).where(Truck.company_id == ctx.company_id))
            if t.id.hex.startswith(prefix)]
    if len(rows) != 1:
        raise NotFound("truck.not_found")
    return rows[0]


def change_truck_status(ctx, s, truck_id, new_status, reason=None):
    ctx.require("fleet.edit")
    t = s.get(Truck, truck_id)
    if t is None or t.company_id != ctx.company_id:
        raise NotFound("truck.not_found")
    if new_status not in TRUCK_STATUSES:
        raise ServiceError("err.invalid")
    before, t.status = t.status, new_status
    audit.record(s, ctx=ctx, action="truck_status", object_type="truck", object_id=t.id,
                 before={"status": before}, after={"status": new_status}, reason=reason)
    return t


# ------------------------------------------------------------------ assignments
def apply_assignment(s, company_id, driver_id, truck_id, by_user_id, reason, ctx=None):
    """End every open assignment of this driver or truck, then open the new one (history is kept)."""
    now = utcnow()
    for a in s.scalars(select(DriverAssignment).where(DriverAssignment.company_id == company_id,
                                                      DriverAssignment.ended_at.is_(None),
                                                      or_(DriverAssignment.driver_id == driver_id,
                                                          DriverAssignment.truck_id == truck_id))):
        a.ended_at = now
    a = DriverAssignment(company_id=company_id, driver_id=driver_id, truck_id=truck_id, started_at=now,
                         changed_by=by_user_id, change_reason=reason)
    s.add(a)
    s.flush()
    audit.record(s, ctx=ctx, company_id=company_id, actor_user_id=by_user_id, action="truck_assigned",
                 object_type="driver", object_id=driver_id, after={"truck_id": str(truck_id)}, reason=reason)
    return a


def assign_truck(ctx, s, driver_id, truck_id, reason):
    """Returns (assignment|None, approval|None). First assignment is direct; replacing one needs approval."""
    ctx.require("fleet.assign")
    d, t = s.get(Driver, driver_id), s.get(Truck, truck_id)
    if d is None or t is None or d.company_id != ctx.company_id or t.company_id != ctx.company_id:
        raise NotFound()
    if t.status != "active" or d.status in ("terminated", "inactive"):
        raise ServiceError("assign.not_available")
    if not (reason or "").strip():
        raise ServiceError("err.reason_required")
    busy = s.scalar(select(DriverAssignment.id).where(
        DriverAssignment.company_id == ctx.company_id, DriverAssignment.ended_at.is_(None),
        or_(DriverAssignment.driver_id == d.id, DriverAssignment.truck_id == t.id)))
    if busy:
        from . import approvals
        ap = approvals.request(ctx, s, "driver_truck_reassignment", "driver", d.id,
                               {"driver_id": str(d.id), "truck_id": str(t.id), "driver": d.full_name,
                                "truck": t.unit_number, "reason": reason})
        return None, ap
    return apply_assignment(s, ctx.company_id, d.id, t.id, ctx.user_id, reason.strip(), ctx), None


def unassign_truck(ctx, s, driver_id, reason):
    ctx.require("fleet.assign")
    d = s.get(Driver, driver_id)
    if d is None or d.company_id != ctx.company_id:
        raise NotFound("driver.not_found")
    if not (reason or "").strip():
        raise ServiceError("err.reason_required")
    n = 0
    for a in s.scalars(select(DriverAssignment).where(DriverAssignment.company_id == ctx.company_id,
                                                      DriverAssignment.driver_id == d.id,
                                                      DriverAssignment.ended_at.is_(None))):
        a.ended_at, n = utcnow(), n + 1
    if not n:
        raise NotFound("assign.none")
    audit.record(s, ctx=ctx, action="truck_unassigned", object_type="driver", object_id=d.id, reason=reason)


def my_status(ctx, s):
    d = my_driver(ctx, s)
    cur = current_assignment(ctx, s, d.id)
    return d, (cur[1] if cur else None)
