"""Telegram group mapping: every group belongs to exactly ONE company. Commands never grant permissions."""
from sqlalchemy import select

from .. import audit, db
from ..models import TelegramGroup, TelegramGroupAdmin, User, utcnow
from ..rbac import PermissionDenied
from .errors import NotFound, ServiceError

GROUP_TYPES = ("operations", "dispatch", "maintenance", "eld", "safety", "hr", "accounting")


def resolve_group(chat_id):
    """Trusted resolver: Telegram chat -> (company_id, group_type, title) or None.
    This is the ONE place that looks a group up without a company scope; it returns no business data."""
    with db.platform_session("resolve telegram group -> company") as s:
        g = s.scalar(select(TelegramGroup).where(TelegramGroup.telegram_chat_id == chat_id,
                                                 TelegramGroup.is_active.is_(True)))
        return (g.company_id, g.group_type, g.title) if g else None


def link_group(ctx, s, chat_id, title, group_type="operations"):
    """Link the CALLING group to ctx.company_id. Owner, or a user holding the explicit telegram.link_group grant.
    A group already linked to another company can only be moved by the Owner."""
    ctx.require("telegram.link_group")
    if ctx.company_id is None:
        raise ServiceError("err.no_company")
    if group_type not in GROUP_TYPES:
        raise ServiceError("err.invalid")
    with db.platform_session("check group uniqueness across companies") as ps:
        other = ps.scalar(select(TelegramGroup).where(TelegramGroup.telegram_chat_id == chat_id))
        other_company = other.company_id if other else None
    if other_company is not None and other_company != ctx.company_id:
        if not ctx.is_owner:
            raise ServiceError("group.linked_elsewhere")
        with db.platform_session("owner moves a group between companies") as ps:
            og = ps.scalar(select(TelegramGroup).where(TelegramGroup.telegram_chat_id == chat_id))
            audit.record(ps, ctx=ctx, company_id=other_company, action="group_unlinked_by_move",
                         object_type="telegram_group", object_id=og.id)
            ps.delete(og)
    g = s.scalar(select(TelegramGroup).where(TelegramGroup.telegram_chat_id == chat_id))
    if g is None:
        g = TelegramGroup(company_id=ctx.company_id, telegram_chat_id=chat_id, title=title, group_type=group_type,
                          is_active=True, linked_by=ctx.user_id)
        s.add(g)
        s.flush()
    else:
        g.title, g.group_type, g.is_active = title, group_type, True
    audit.record(s, ctx=ctx, action="group_linked", object_type="telegram_group", object_id=g.id,
                 after={"chat_id": chat_id, "type": group_type})
    return g


def unlink_group(ctx, s, chat_id):
    ctx.require("telegram.link_group")
    g = s.scalar(select(TelegramGroup).where(TelegramGroup.telegram_chat_id == chat_id))
    if g is None:
        raise NotFound()
    g.is_active = False
    audit.record(s, ctx=ctx, action="group_unlinked", object_type="telegram_group", object_id=g.id)


def deactivate_if_linked(chat_id, reason):
    """Bot was removed from a chat: stop delivering to it (kept for history)."""
    with db.platform_session("bot removed from group") as s:
        g = s.scalar(select(TelegramGroup).where(TelegramGroup.telegram_chat_id == chat_id,
                                                 TelegramGroup.is_active.is_(True)))
        if g:
            g.is_active = False
            audit.record(s, actor_type="system", company_id=g.company_id, action="group_deactivated",
                         object_type="telegram_group", object_id=g.id, reason=reason)
        return g.company_id if g else None


def group_chat_for(s, company_id, group_type):
    """Chat id to post to: the group of that type, else the 'operations' group (scope must be the company)."""
    rows = list(s.scalars(select(TelegramGroup).where(TelegramGroup.company_id == company_id,
                                                      TelegramGroup.is_active.is_(True))))
    for want in (group_type, "operations"):
        for g in rows:
            if g.group_type == want:
                return g.telegram_chat_id
    return rows[0].telegram_chat_id if rows else None


def list_groups(ctx, s):
    ctx.require("telegram.view")
    return list(s.scalars(select(TelegramGroup).where(TelegramGroup.company_id == ctx.company_id)
                          .order_by(TelegramGroup.title)))


def update_admins(ctx, s, chat_id, tg_admins):
    """/updadmin: refresh the admin ROSTER of the calling, verified group. Needs the explicit Owner-granted
    permission (or the Owner). It never creates users, roles or permissions: it only records who the Telegram
    admins of THIS group are and which of them are already approved members of this company.
    tg_admins: [(telegram_user_id, display_name, is_creator)]"""
    ctx.require("telegram.update_admin")
    g = s.scalar(select(TelegramGroup).where(TelegramGroup.telegram_chat_id == chat_id,
                                             TelegramGroup.company_id == ctx.company_id,
                                             TelegramGroup.is_active.is_(True)))
    if g is None:
        raise ServiceError("group.not_linked")
    from .access import get_user_by_tg
    existing = {a.telegram_user_id: a for a in s.scalars(select(TelegramGroupAdmin)
                                                         .where(TelegramGroupAdmin.group_id == g.id))}
    seen, known = set(), 0
    for tg_id, name, is_creator in tg_admins:
        seen.add(tg_id)
        user = get_user_by_tg(s, tg_id)
        row = existing.get(tg_id)
        if row is None:
            row = TelegramGroupAdmin(company_id=g.company_id, group_id=g.id, telegram_user_id=tg_id)
            s.add(row)
        row.display_name, row.is_creator, row.synced_at = name, bool(is_creator), utcnow()
        row.user_id = user.id if (user and user.status == "active") else None
        known += 1 if row.user_id else 0
    for tg_id, row in existing.items():
        if tg_id not in seen:
            s.delete(row)
    audit.record(s, ctx=ctx, action="group_admins_updated", object_type="telegram_group", object_id=g.id,
                 after={"admins": len(seen), "registered": known})
    return len(seen), known


def group_admins(ctx, s, chat_id):
    ctx.require("telegram.view")
    g = s.scalar(select(TelegramGroup).where(TelegramGroup.telegram_chat_id == chat_id,
                                             TelegramGroup.company_id == ctx.company_id))
    if g is None:
        raise NotFound()
    return list(s.scalars(select(TelegramGroupAdmin).where(TelegramGroupAdmin.group_id == g.id)))
