"""Dispatch: loads. Money (rate) is visible only to people who may see accounting data."""
import re

from sqlalchemy import select

from .. import audit
from ..models import Document, Driver, Load, Truck
from ..rbac import GroupPost, Notify, PermissionDenied
from .errors import NotFound, ServiceError

STATUSES = ["assigned", "picked_up", "delivered", "pod_received", "invoiced", "cancelled"]
TRANSITIONS = {"assigned": {"picked_up", "cancelled"}, "picked_up": {"delivered", "cancelled"},
               "delivered": {"pod_received"}, "pod_received": {"invoiced"}, "invoiced": set(), "cancelled": set()}
DRIVER_MOVES = {("assigned", "picked_up"), ("picked_up", "delivered")}     # a driver may report these on own load


def _clean(v, n):
    v = " ".join((v or "").split())[:n]
    return v or None


def _own_driver_ids(ctx, s):
    return set(s.scalars(select(Driver.id).where(Driver.company_id == ctx.company_id, Driver.user_id == ctx.user_id)))


def _sees_all(ctx):
    """Dispatch and accounting read every load of the company (accounting needs them to invoice)."""
    return ctx.can("dispatch.view") or ctx.can("accounting.view")


def _can_see(ctx, s, ld):
    if _sees_all(ctx):
        return True
    return ld.driver_id is not None and ld.driver_id in _own_driver_ids(ctx, s)       # a driver sees own loads


def rate_visible(ctx):
    return ctx.can("accounting.view")


def create_load(ctx, s, load_number, pickup=None, delivery=None, broker=None, driver_id=None, rate_cents=None):
    ctx.require("dispatch.create")
    number = (load_number or "").strip().upper()[:40]
    if not re.fullmatch(r"[A-Z0-9._/-]{1,40}", number):                  # also safe inside Telegram button data
        raise ServiceError("err.invalid")
    if s.scalar(select(Load.id).where(Load.company_id == ctx.company_id, Load.load_number == number)):
        raise ServiceError("load.exists")
    if rate_cents is not None:
        ctx.require("accounting.edit")
    ld = Load(company_id=ctx.company_id, load_number=number, pickup_address=_clean(pickup, 300),
              delivery_address=_clean(delivery, 300), broker=_clean(broker, 200), status="assigned",
              rate_cents=rate_cents, created_by=ctx.user_id)
    s.add(ld)
    s.flush()
    audit.record(s, ctx=ctx, action="load_created", object_type="load", object_id=ld.id, after={"number": number})
    if driver_id:
        assign_driver(ctx, s, number, driver_id)
    return ld


def get_by_number(ctx, s, number):
    ld = s.scalar(select(Load).where(Load.company_id == ctx.company_id,
                                     Load.load_number == (number or "").strip().upper()))
    if ld is None or not _can_see(ctx, s, ld):
        raise NotFound("load.not_found")
    return ld


def list_loads(ctx, s, status=None, limit=20):
    q = select(Load).where(Load.company_id == ctx.company_id)
    if not _sees_all(ctx):
        mine = _own_driver_ids(ctx, s)
        if not mine:
            raise PermissionDenied("dispatch.view")
        q = q.where(Load.driver_id.in_(mine))
    if status == "active":
        q = q.where(Load.status.notin_(["invoiced", "cancelled"]))
    elif status:
        q = q.where(Load.status == status)
    return list(s.scalars(q.order_by(Load.created_at.desc()).limit(limit)))


def assign_driver(ctx, s, number, driver_id, truck_id=None):
    ctx.require("dispatch.assign")
    ld = get_by_number(ctx, s, number)
    d = s.get(Driver, driver_id)
    if d is None or d.company_id != ctx.company_id or d.status in ("terminated", "inactive"):
        raise ServiceError("assign.not_available")
    if truck_id:
        t = s.get(Truck, truck_id)
        if t is None or t.company_id != ctx.company_id:
            raise NotFound("truck.not_found")
    before = ld.driver_id
    ld.driver_id, ld.truck_id = d.id, truck_id
    audit.record(s, ctx=ctx, action="load_assigned", object_type="load", object_id=ld.id,
                 before={"driver_id": str(before) if before else None}, after={"driver_id": str(d.id)})
    if d.user_id and d.user_id != ctx.user_id:
        ctx.outbox.append(Notify(d.user_id, "load.assigned", {"number": ld.load_number,
                                                              "pickup": ld.pickup_address or "-",
                                                              "delivery": ld.delivery_address or "-"}))
    return ld


def _has_pod(s, ld):
    return bool(s.scalar(select(Document.id).where(Document.company_id == ld.company_id, Document.related_type == "load",
                                                   Document.related_id == ld.id, Document.doc_type == "POD",
                                                   Document.is_active.is_(True))))


def change_status(ctx, s, number, new_status):
    ld = get_by_number(ctx, s, number)
    if new_status not in STATUSES or new_status not in TRANSITIONS[ld.status]:
        raise ServiceError("load.bad_transition")
    driver_move = (ld.status, new_status) in DRIVER_MOVES and ld.driver_id in _own_driver_ids(ctx, s)
    if not driver_move:
        ctx.require("accounting.edit" if new_status == "invoiced" else "dispatch.edit")
    if new_status == "pod_received" and not _has_pod(s, ld):
        raise ServiceError("load.need_pod")                       # no POD file, no POD status
    before, ld.status = ld.status, new_status
    audit.record(s, ctx=ctx, action="load_status", object_type="load", object_id=ld.id,
                 before={"status": before}, after={"status": new_status})
    if new_status in ("delivered", "pod_received"):
        ctx.outbox.append(GroupPost(ctx.company_id, "accounting" if new_status == "pod_received" else "dispatch",
                                    "load.group_" + new_status, {"number": ld.load_number, "by": ctx.full_name}))
    return ld
