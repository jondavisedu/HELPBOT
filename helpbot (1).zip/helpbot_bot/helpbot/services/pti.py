"""PTI (pre-trip inspection): maintenance requests it, the driver sends photos, maintenance approves or asks to redo."""
from datetime import datetime, timezone

from sqlalchemy import select

from .. import audit
from ..models import Document, Driver, PtiRequest, utcnow
from ..rbac import GroupPost, Notify, PermissionDenied
from . import documents
from .errors import NotFound, ServiceError


def _own_driver_ids(ctx, s):
    return set(s.scalars(select(Driver.id).where(Driver.company_id == ctx.company_id, Driver.user_id == ctx.user_id)))


def request_pti(ctx, s, driver_ids=None):
    """driver_ids=None means every active driver. Returns the requests (existing open ones are reused)."""
    ctx.require("maintenance.create")
    q = select(Driver).where(Driver.company_id == ctx.company_id, Driver.status.in_(["active", "returned"]))
    if driver_ids is not None:
        q = q.where(Driver.id.in_(list(driver_ids)))
    drivers = list(s.scalars(q))
    if not drivers:
        raise ServiceError("pti.no_drivers")
    batch = datetime.now(timezone.utc).strftime("%Y%m%d%H%M")
    out = []
    for d in drivers:
        req = s.scalar(select(PtiRequest).where(PtiRequest.company_id == ctx.company_id, PtiRequest.driver_id == d.id,
                                                PtiRequest.status.in_(["requested", "redo"])))
        if req is None:
            req = PtiRequest(company_id=ctx.company_id, driver_id=d.id, requested_by=ctx.user_id, batch=batch)
            s.add(req)
            s.flush()
        out.append(req)
        if d.user_id:
            ctx.outbox.append(Notify(d.user_id, "pti.requested", {}, [("btn.pti_start", f"pt:go:{req.id.hex[:8]}")]))
    audit.record(s, ctx=ctx, action="pti_requested", object_type="pti", after={"drivers": len(out), "batch": batch})
    return out


def my_open_requests(ctx, s):
    mine = _own_driver_ids(ctx, s)
    if not mine:
        return []
    return list(s.scalars(select(PtiRequest).where(PtiRequest.company_id == ctx.company_id,
                                                   PtiRequest.driver_id.in_(mine),
                                                   PtiRequest.status.in_(["requested", "redo"]))))


def by_prefix(ctx, s, prefix):
    rows = [r for r in s.scalars(select(PtiRequest).where(PtiRequest.company_id == ctx.company_id))
            if r.id.hex.startswith(prefix)]
    if len(rows) != 1:
        raise NotFound()
    r = rows[0]
    if not (ctx.can("maintenance.view") or r.driver_id in _own_driver_ids(ctx, s)):
        raise NotFound()                                     # somebody else's PTI: same answer as "missing"
    return r


def request_company(prefix):
    """Trusted resolver for the driver's 'Start PTI' button: which company does this request belong to?"""
    from .. import db
    with db.platform_session("resolve pti request -> company") as s:
        rows = [r for r in s.scalars(select(PtiRequest).where(PtiRequest.status.in_(["requested", "redo"])))
                if r.id.hex.startswith(prefix)]
        return rows[0].company_id if len(rows) == 1 else None


def attach_photo(ctx, s, req, file_ref, file_name=None, mime_type=None, size=None):
    if req.status not in ("requested", "redo") or req.driver_id not in _own_driver_ids(ctx, s):
        raise PermissionDenied("pti.attach")
    return documents.add_document(ctx, s, "PTI", "pti", req.id, file_ref, file_name, mime_type, size)


def photo_count(ctx, s, req):
    return len(list(s.scalars(select(Document.id).where(Document.company_id == ctx.company_id,
                                                        Document.related_type == "pti", Document.related_id == req.id,
                                                        Document.is_active.is_(True)))))


def submit(ctx, s, req):
    if req.driver_id not in _own_driver_ids(ctx, s) or req.status not in ("requested", "redo"):
        raise PermissionDenied("pti.submit")
    n = photo_count(ctx, s, req)
    if n < 1:
        raise ServiceError("pti.need_photo")
    req.status, req.submitted_at = "submitted", utcnow()
    d = s.get(Driver, req.driver_id)
    audit.record(s, ctx=ctx, action="pti_submitted", object_type="pti", object_id=req.id, after={"files": n})
    ctx.outbox.append(GroupPost(ctx.company_id, "maintenance", "pti.group_submitted",
                                {"driver": d.full_name, "n": n},
                                [("btn.approve", f"pr:{req.id.hex[:8]}:ok"), ("btn.redo", f"pr:{req.id.hex[:8]}:redo")]))
    return n


def review(ctx, s, req, approve):
    ctx.require("maintenance.edit")
    if req.status != "submitted":
        raise ServiceError("pti.not_submitted")
    req.status = "approved" if approve else "redo"
    req.reviewed_by, req.reviewed_at = ctx.user_id, utcnow()
    if not approve:
        documents.retire_documents(s, ctx, "pti", req.id, "PTI")
    audit.record(s, ctx=ctx, action="pti_approved" if approve else "pti_redo", object_type="pti", object_id=req.id)
    d = s.get(Driver, req.driver_id)
    if d and d.user_id:
        ctx.outbox.append(Notify(d.user_id, "pti.approved" if approve else "pti.redo", {},
                                 None if approve else [("btn.pti_start", f"pt:go:{req.id.hex[:8]}")]))
    return req


def status_summary(ctx, s):
    ctx.require("maintenance.view")
    last = s.scalar(select(PtiRequest.batch).where(PtiRequest.company_id == ctx.company_id)
                    .order_by(PtiRequest.created_at.desc()))
    if last is None:
        return None
    rows = list(s.execute(select(PtiRequest, Driver.full_name).join(Driver, Driver.id == PtiRequest.driver_id)
                          .where(PtiRequest.company_id == ctx.company_id, PtiRequest.batch == last)).all())
    return {"ok": sum(1 for r, _ in rows if r.status == "approved"),
            "review": sum(1 for r, _ in rows if r.status == "submitted"),
            "wait": [n for r, n in rows if r.status in ("requested", "redo")]}
