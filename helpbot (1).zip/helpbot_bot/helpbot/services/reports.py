from sqlalchemy import func, select

from ..models import Approval, Driver, Ticket, Truck
from .tickets import _visibility_clause


def overview(ctx, s):
    """Company summary limited to what the caller may see."""
    ctx.require("overview.view")
    out = {}
    out["open_tickets"] = s.scalar(select(func.count(Ticket.id)).where(
        Ticket.company_id == ctx.company_id, Ticket.status != "done", _visibility_clause(ctx))) or 0
    if ctx.can("drivers.view"):
        out["drivers"] = dict(s.execute(select(Driver.status, func.count(Driver.id))
                                        .where(Driver.company_id == ctx.company_id).group_by(Driver.status)).all())
    if ctx.can("fleet.view"):
        out["trucks"] = dict(s.execute(select(Truck.status, func.count(Truck.id))
                                       .where(Truck.company_id == ctx.company_id).group_by(Truck.status)).all())
    if ctx.can("approvals.view"):
        out["pending_approvals"] = s.scalar(select(func.count(Approval.id)).where(
            Approval.company_id == ctx.company_id, Approval.status == "pending")) or 0
    return out


def report(ctx, s):
    ctx.require("reports.view")
    out = overview(ctx, s) if ctx.can("overview.view") else {}
    out["tickets_by_status"] = dict(s.execute(select(Ticket.status, func.count(Ticket.id))
                                              .where(Ticket.company_id == ctx.company_id, _visibility_clause(ctx))
                                              .group_by(Ticket.status)).all())
    out["tickets_by_category"] = dict(s.execute(select(Ticket.category, func.count(Ticket.id))
                                                .where(Ticket.company_id == ctx.company_id, _visibility_clause(ctx))
                                                .group_by(Ticket.category)).all())
    return out
