"""Tickets: categories route to departments; visibility follows role, ownership and category confidentiality."""
from datetime import datetime, timedelta, timezone

from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError

from .. import audit, config
from ..models import CompanyUser, Ticket, TicketMessage, User, as_utc, utcnow
from ..rbac import CATEGORY_MODULE, CONFIDENTIAL_CATEGORIES, GroupPost, Notify, PermissionDenied
from .errors import NotFound, ServiceError

CATEGORIES = list(CATEGORY_MODULE)
PRIORITIES = ["low", "normal", "high", "urgent"]
STATUSES = ["open", "in_progress", "waiting", "escalated", "done"]
TRANSITIONS = {                                    # Open -> In Progress -> Waiting -> Done, Escalated when needed
    "open": {"in_progress", "escalated", "done"},
    "in_progress": {"waiting", "done", "escalated"},
    "waiting": {"in_progress", "done", "escalated"},
    "escalated": {"in_progress", "done"},
    "done": {"open"},                              # reopen
}


def _can_see(ctx, t):
    if t.created_by == ctx.user_id or t.assigned_to == ctx.user_id:
        return True
    if ctx.self_scoped:
        return False
    return ctx.can("tickets.view") and ctx.can(f"{CATEGORY_MODULE.get(t.category, 'tickets')}.view")


def _visible_modules(ctx):
    return [cat for cat, mod in CATEGORY_MODULE.items() if ctx.can(f"{mod}.view")]


def _visibility_clause(ctx):
    own = or_(Ticket.created_by == ctx.user_id, Ticket.assigned_to == ctx.user_id)
    if ctx.self_scoped or not ctx.can("tickets.view"):
        return own
    return or_(own, Ticket.category.in_(_visible_modules(ctx) or ["__none__"]))


def _next_number(s, company_id):
    return (s.scalar(select(func.max(Ticket.ticket_number)).where(Ticket.company_id == company_id)) or 0) + 1


def create_ticket(ctx, s, category, subject, description=None, priority="normal"):
    ctx.require("tickets.create")
    if ctx.company_id is None:
        raise ServiceError("err.no_company")
    subject = " ".join((subject or "").split())[:300]
    if category not in CATEGORIES or priority not in PRIORITIES or len(subject) < 3:
        raise ServiceError("err.invalid")
    for attempt in range(3):
        t = Ticket(company_id=ctx.company_id, ticket_number=_next_number(s, ctx.company_id), created_by=ctx.user_id,
                   category=category, priority=priority, status="open", subject=subject,
                   description=(description or "")[:4000] or None)
        try:
            with s.begin_nested():
                s.add(t)
                s.flush()
            break
        except IntegrityError:
            if attempt == 2:
                raise
    audit.record(s, ctx=ctx, action="ticket_created", object_type="ticket", object_id=t.id,
                 after={"number": t.ticket_number, "category": category, "priority": priority})
    conf = category in CONFIDENTIAL_CATEGORIES
    ctx.outbox.append(GroupPost(ctx.company_id, "operations" if category == "other" else category,
                                "tk.group_new_conf" if conf else "tk.group_new",
                                {"n": t.ticket_number, "cat": category, "prio": priority, "subject": subject,
                                 "by": ctx.full_name},
                                [("btn.in_progress", f"tk:{t.ticket_number}:in_progress"),
                                 ("btn.assign_me", f"tk:{t.ticket_number}:me"),
                                 ("btn.open", f"tk:{t.ticket_number}:view")]))
    return t


def get_ticket(ctx, s, number):
    ctx.require("tickets.view")
    t = s.scalar(select(Ticket).where(Ticket.company_id == ctx.company_id, Ticket.ticket_number == number))
    if t is None or not _can_see(ctx, t):
        raise NotFound("tk.not_found")                    # same answer for "missing" and "not yours"
    return t


def list_tickets(ctx, s, flt="active", limit=15):
    ctx.require("tickets.view")
    q = select(Ticket).where(Ticket.company_id == ctx.company_id, _visibility_clause(ctx))
    if flt == "mine":
        q = q.where(or_(Ticket.created_by == ctx.user_id))
    elif flt == "assigned":
        q = q.where(Ticket.assigned_to == ctx.user_id)
    elif flt == "done":
        q = q.where(Ticket.status == "done")
    elif flt in STATUSES:
        q = q.where(Ticket.status == flt)
    else:                                             # "active" (default) = everything not done
        q = q.where(Ticket.status != "done")
    return list(s.scalars(q.order_by(Ticket.ticket_number.desc()).limit(limit)))


def messages(ctx, s, t):
    q = select(TicketMessage, User.full_name).join(User, User.id == TicketMessage.sender_id) \
        .where(TicketMessage.company_id == ctx.company_id, TicketMessage.ticket_id == t.id)
    if ctx.self_scoped:                               # clients/drivers never see internal notes
        q = q.where(TicketMessage.visibility == "public")
    return list(s.execute(q.order_by(TicketMessage.created_at)).all())


def add_message(ctx, s, number, body, internal=False):
    t = get_ticket(ctx, s, number)
    body = (body or "").strip()[:4000]
    if not body:
        raise ServiceError("err.invalid")
    if internal:
        if ctx.self_scoped:
            raise PermissionDenied("tickets.internal")
        ctx.require("tickets.edit")
    elif ctx.self_scoped and t.created_by != ctx.user_id:
        raise NotFound("tk.not_found")
    s.add(TicketMessage(company_id=ctx.company_id, ticket_id=t.id, sender_id=ctx.user_id, body=body,
                        visibility="internal" if internal else "public"))
    audit.record(s, ctx=ctx, action="ticket_note" if internal else "ticket_reply", object_type="ticket",
                 object_id=t.id)
    if not internal:                                  # tell the other side
        for uid in {t.created_by, t.assigned_to} - {ctx.user_id, None}:
            ctx.outbox.append(Notify(uid, "tk.reply", {"n": t.ticket_number, "by": ctx.full_name}))
    return t


def change_status(ctx, s, number, new_status, reason=None):
    t = get_ticket(ctx, s, number)
    if ctx.self_scoped:
        raise PermissionDenied("tickets.edit")
    ctx.require("tickets.edit")
    ctx.require(f"{CATEGORY_MODULE[t.category]}.view")
    if new_status not in STATUSES or new_status not in TRANSITIONS.get(t.status, set()):
        raise ServiceError("tk.bad_transition", old=t.status, new=new_status)
    if t.status == "done" and not (reason or "").strip():
        raise ServiceError("err.reason_required")
    before = t.status
    t.status = new_status
    audit.record(s, ctx=ctx, action="ticket_status", object_type="ticket", object_id=t.id,
                 before={"status": before}, after={"status": new_status}, reason=reason)
    for uid in {t.created_by, t.assigned_to} - {ctx.user_id, None}:
        ctx.outbox.append(Notify(uid, "tk.status", {"n": t.ticket_number, "status": new_status, "by": ctx.full_name}))
    return t


def assign(ctx, s, number, user_id):
    t = get_ticket(ctx, s, number)
    ctx.require("tickets.assign")
    member = s.scalar(select(CompanyUser).where(CompanyUser.company_id == ctx.company_id,
                                                CompanyUser.user_id == user_id, CompanyUser.status == "active"))
    target = s.get(User, user_id)
    if target is None or target.status != "active" or (member is None and target.platform_role != "owner"):
        raise ServiceError("user.not_member")
    before = t.assigned_to
    t.assigned_to = user_id
    audit.record(s, ctx=ctx, action="ticket_assigned", object_type="ticket", object_id=t.id,
                 before={"assigned_to": str(before) if before else None}, after={"assigned_to": str(user_id)})
    if user_id != ctx.user_id:
        ctx.outbox.append(Notify(user_id, "tk.assigned", {"n": t.ticket_number, "subject": t.subject}))
    return t


def set_priority(ctx, s, number, priority):
    t = get_ticket(ctx, s, number)
    ctx.require("tickets.edit")
    if priority not in PRIORITIES:
        raise ServiceError("err.invalid")
    before, t.priority = t.priority, priority
    audit.record(s, ctx=ctx, action="ticket_priority", object_type="ticket", object_id=t.id,
                 before={"priority": before}, after={"priority": priority})
    return t


def due_reminders(s_platform, minutes=None):
    """Open tickets nobody picked up for a while (idempotent: stamps last_reminder_at). Platform scope only."""
    minutes = config.REMINDER_MINUTES if minutes is None else minutes
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=minutes)
    out = []
    for t in s_platform.scalars(select(Ticket).where(Ticket.status == "open", Ticket.assigned_to.is_(None))):
        last = as_utc(t.last_reminder_at or t.created_at)
        if last <= cutoff:
            t.last_reminder_at = utcnow()
            out.append(t)
    return out
