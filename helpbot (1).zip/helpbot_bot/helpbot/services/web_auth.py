"""Web login: a one-time code delivered by Telegram (+ TOTP for privileged roles). Server-side sessions.
Nothing here reveals whether an account exists."""
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone

import pyotp
from sqlalchemy import func, select

from .. import audit, config, crypto
from ..models import CompanyUser, LoginCode, Role, User, WebSession, as_utc, utcnow

CODE_TTL = timedelta(minutes=5)
MAX_CODE_ATTEMPTS = 5


def _hash(value):
    return hashlib.sha256(value.encode()).hexdigest()


def find_user(s, identifier):
    ident = (identifier or "").strip().lstrip("@")
    if not ident:
        return None
    if ident.isdigit():
        return s.scalar(select(User).where(User.telegram_user_id == int(ident)))
    return s.scalar(select(User).where(func.lower(User.telegram_username) == ident.lower()))


def user_roles(s, user):
    names = set(s.scalars(select(Role.name).join(CompanyUser, CompanyUser.role_id == Role.id)
                          .where(CompanyUser.user_id == user.id, CompanyUser.status == "active")))
    if user.platform_role:
        names.add(user.platform_role)
    return names


def needs_2fa(s, user):
    return bool(user_roles(s, user) & config.WEB_REQUIRE_2FA)


def issue_code(s, identifier):
    """Returns (user, code) for an ACTIVE user, else (None, None). The caller sends the code through Telegram."""
    user = find_user(s, identifier)
    if user is None or user.status != "active" or not user.telegram_user_id:
        return None, None
    for old in s.scalars(select(LoginCode).where(LoginCode.user_id == user.id, LoginCode.used.is_(False))):
        old.used = True                                              # a new code replaces older ones
    code = f"{secrets.randbelow(10 ** 6):06d}"
    s.add(LoginCode(user_id=user.id, code_hash=_hash(code), expires_at=utcnow() + CODE_TTL))
    audit.record(s, actor_user_id=user.id, action="web_login_code_issued", object_type="user", object_id=user.id,
                 channel="web", actor_type="user")
    return user, code


def verify_login(s, identifier, code, totp=None):
    """Returns (user, None) on success or (None, reason). It never raises for a bad login: the caller must COMMIT
    the session either way, otherwise the attempt counter would be rolled back together with the error
    (that would allow unlimited guessing). A code can be tried 5 times, then it is burned."""
    user = find_user(s, identifier)
    if user is None or user.status != "active":
        return None, "invalid"
    row = s.scalar(select(LoginCode).where(LoginCode.user_id == user.id, LoginCode.used.is_(False))
                   .order_by(LoginCode.created_at.desc()))
    if row is None or as_utc(row.expires_at) < datetime.now(timezone.utc):
        return None, "invalid"
    row.attempts += 1
    if row.attempts > MAX_CODE_ATTEMPTS:
        row.used = True
        return None, "invalid"
    if not hmac.compare_digest(row.code_hash, _hash((code or "").strip())):
        return None, "invalid"
    if user.totp_enabled:
        if not verify_totp(user, totp):
            return None, "invalid"
    elif needs_2fa(s, user):
        return None, "2fa_setup_required"
    row.used = True
    audit.record(s, actor_user_id=user.id, action="web_login", object_type="user", object_id=user.id, channel="web")
    return user, None


def create_session(s, user, company_id=None):
    token = secrets.token_urlsafe(32)
    s.add(WebSession(user_id=user.id, token_hash=_hash(token), company_id=company_id or user.active_company_id,
                     expires_at=utcnow() + timedelta(hours=config.WEB_SESSION_HOURS)))
    return token


def session_user(s, token):
    """(user, web_session) for a valid token, else None. Touches last_seen."""
    if not token:
        return None
    ws = s.scalar(select(WebSession).where(WebSession.token_hash == _hash(token)))
    if ws is None or as_utc(ws.expires_at) < datetime.now(timezone.utc):
        return None
    user = s.get(User, ws.user_id)
    if user is None or user.status != "active":
        return None
    ws.last_seen_at = utcnow()
    return user, ws


def destroy_session(s, token):
    ws = s.scalar(select(WebSession).where(WebSession.token_hash == _hash(token or "")))
    if ws is not None:
        s.delete(ws)


def destroy_all_sessions(s, user_id):
    for ws in s.scalars(select(WebSession).where(WebSession.user_id == user_id)):
        s.delete(ws)


# ------------------------------------------------------------------ TOTP (2FA)
def verify_totp(user, code):
    if not user.totp_secret_enc or not code:
        return False
    return pyotp.TOTP(crypto.decrypt(user.totp_secret_enc)).verify(str(code).strip(), valid_window=1)


def totp_begin(s, user):
    """Create a fresh (not yet active) secret. Returns (secret, otpauth_uri)."""
    secret = pyotp.random_base32()
    user.totp_secret_enc, user.totp_enabled = crypto.encrypt(secret), False
    uri = pyotp.TOTP(secret).provisioning_uri(name=user.telegram_username or str(user.telegram_user_id),
                                              issuer_name="HELPBOT")
    return secret, uri


def totp_confirm(s, user, code):
    if user.totp_enabled or not verify_totp(user, code):
        return False
    user.totp_enabled = True
    audit.record(s, actor_user_id=user.id, action="2fa_enabled", object_type="user", object_id=user.id)
    return True


def totp_disable(s, user, code):
    if not user.totp_enabled or not verify_totp(user, code):
        return False
    user.totp_enabled, user.totp_secret_enc = False, None
    destroy_all_sessions(s, user.id)
    audit.record(s, actor_user_id=user.id, action="2fa_disabled", object_type="user", object_id=user.id)
    return True
