"""HELPBOT entry point: python main.py"""
import http.server
import logging
import os
import sys
import threading

from helpbot import bootstrap, config
from helpbot.bot import app as bot_app


def _health_server():
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"HELPBOT ok")

        def log_message(self, *a):
            pass

    srv = http.server.ThreadingHTTPServer(("0.0.0.0", config.PORT), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()


def main():
    logging.basicConfig(format="%(asctime)s %(levelname)s %(name)s: %(message)s", level=logging.INFO)
    logging.getLogger("httpx").setLevel(logging.WARNING)           # never log request URLs (they contain the token)
    if not config.BOT_TOKEN:
        sys.exit("BOT_TOKEN is not set")
    if not config.OWNER_IDS:
        sys.exit("OWNER_TELEGRAM_ID is not set (the platform Owner is defined only by this setting)")
    bootstrap.prepare()
    application = bot_app.build_application()
    if os.environ.get("PORT") and not config.WEBHOOK_URL:          # keep-alive endpoint for free web hosts
        _health_server()
    bot_app.run(application)


if __name__ == "__main__":
    main()
