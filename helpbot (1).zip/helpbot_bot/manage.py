"""Maintenance commands:
  python manage.py migrate | seed | check | revision "message"
  python manage.py backup [--keep N] | verify FILE | restore FILE --yes"""
import sys

from helpbot import config, db, migrate, ops, rbac


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"
    if cmd == "migrate":
        migrate.upgrade("head")
        print("database is up to date")
    elif cmd == "seed":
        with db.platform_session("manage seed") as s:
            rbac.seed_rbac(s)
        print("roles and permissions seeded")
    elif cmd == "revision":
        from alembic import command
        command.revision(migrate.alembic_config(), message=" ".join(sys.argv[2:]) or "change", autogenerate=True)
    elif cmd == "check":
        print("OWNER ids:", sorted(config.OWNER_IDS), "| environment:", config.ENVIRONMENT, "| db:",
              config.DATABASE_URL.split("@")[-1])
    elif cmd == "backup":
        keep = int(sys.argv[sys.argv.index("--keep") + 1]) if "--keep" in sys.argv else 14
        print("backup written:", ops.backup(keep))
    elif cmd == "verify" and len(sys.argv) > 2:
        ops.verify(sys.argv[2])
        print("backup is valid")
    elif cmd == "restore" and len(sys.argv) > 2:
        ops.restore(sys.argv[2], confirmed="--yes" in sys.argv)
        print("restored; start the app again")
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
