"""Smoke test of a DEPLOYED instance (staging first!):   python scripts/smoke_test.py https://your-staging-url"""
import json
import sys
import urllib.error
import urllib.request

base = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "http://127.0.0.1:8080"


def get(path):
    with urllib.request.urlopen(base + path, timeout=10) as r:
        return r.status, dict(r.headers), r.read()


ok = True
for path, check in (("/healthz", lambda s, h, b: json.loads(b)["ok"]),
                    ("/readyz", lambda s, h, b: json.loads(b)["ok"]),
                    ("/", lambda s, h, b: b"HELPBOT" in b and "script-src 'self'" in h.get("Content-Security-Policy", "")),
                    ("/static/app.js", lambda s, h, b: s == 200)):
    try:
        passed = bool(check(*get(path)))
    except Exception as e:
        passed = False
        print("  error:", type(e).__name__)
    print(("PASS " if passed else "FAIL ") + path)
    ok &= passed
try:
    urllib.request.urlopen(base + "/api/tickets", timeout=10)
    print("FAIL /api/tickets must require login")
    ok = False
except urllib.error.HTTPError as e:
    good = e.code == 401
    print(("PASS " if good else "FAIL ") + "/api/tickets is protected (HTTP %s)" % e.code)
    ok &= good
except Exception as e:
    print("FAIL /api/tickets: server not reachable (%s)" % type(e).__name__)
    ok = False
sys.exit(0 if ok else 1)
