"""Drives the real Application with fake Telegram updates; Telegram's network is replaced by a recorder."""
import itertools
import json
import logging
import os

os.environ.setdefault("BOT_TOKEN", "1:x")
os.environ["STRICT_I18N"] = "1"
os.environ["AUTO_MIGRATE"] = "false"

import telegram                                                       # noqa: E402
from telegram import Update, User as TgUser                            # noqa: E402

from helpbot import bootstrap, db, models                              # noqa: E402
from helpbot.bot import app as bot_app                                 # noqa: E402

BOT = {"id": 999, "is_bot": True, "first_name": "HELPBOT", "username": "HELPBOTbot"}
OWNER = 1


class FakeTelegram:
    def __init__(self):
        self.calls = []
        self.mid = itertools.count(100)
        self.admins = {}                       # chat_id -> list of (tg_id, name, status)

    async def post(self, bot, endpoint, data=None, **kw):
        data = dict(data or {})
        self.calls.append((endpoint, data))
        chat = {"id": data.get("chat_id", 0), "type": "private" if data.get("chat_id", 0) > 0 else "supergroup",
                "title": "g"}
        msg = lambda: {"message_id": next(self.mid), "date": 1700000000, "chat": chat, "text": data.get("text", "x")}
        if endpoint in ("sendMessage", "sendPhoto"):
            return msg()
        if endpoint == "getChatAdministrators":
            out = []
            for tg_id, name, status in self.admins.get(data["chat_id"], []):
                m = {"status": status, "user": {"id": tg_id, "is_bot": False, "first_name": name}}
                if status == "creator":
                    m["is_anonymous"] = False
                else:
                    m.update(can_be_edited=False, is_anonymous=False, can_manage_chat=True, can_delete_messages=True,
                             can_manage_video_chats=False, can_restrict_members=False, can_promote_members=False,
                             can_change_info=False, can_invite_users=True)
                out.append(m)
            return out
        return True


class Bot:
    def __init__(self):
        from conftest import fresh_db
        fresh_db()
        bootstrap.prepare()
        self.tg = FakeTelegram()
        telegram.Bot._post = lambda b, endpoint, data=None, **kw: self.tg.post(b, endpoint, data, **kw)
        self.app = bot_app.build_application()
        self.app.bot._bot_user = TgUser(**BOT)
        self.app.bot._initialized = True
        self.app._initialized = True
        self.uid = itertools.count(1)
        self.names = {}

    # -------------------------------------------------------------- sending updates
    def _from(self, user, lang="en"):
        return {"id": user, "is_bot": False, "first_name": self.names.get(user, f"User{user}"),
                "username": f"user{user}", "language_code": lang}

    async def _process(self, **payload):
        await self.app.process_update(Update.de_json({"update_id": next(self.uid), **payload}, self.app.bot))

    async def say(self, user, text, chat=None, args_ok=True):
        chat = chat or user
        m = {"message_id": next(self.tg.mid), "date": 1700000000, "from": self._from(user), "text": text,
             "chat": {"id": chat, "type": "private" if chat > 0 else "supergroup", "title": f"grp{chat}"}}
        if text.startswith("/"):
            m["entities"] = [{"type": "bot_command", "offset": 0, "length": len(text.split()[0])}]
        await self._process(message=m)

    async def click(self, user, data, chat=None):
        chat = chat or user
        cq = {"id": str(next(self.uid)), "chat_instance": "c", "data": data, "from": self._from(user),
              "message": {"message_id": 555, "date": 1700000000, "text": "x",
                          "chat": {"id": chat, "type": "private" if chat > 0 else "supergroup", "title": f"grp{chat}"}}}
        await self._process(callback_query=cq)

    async def member_update(self, chat, by, old, new, title="New group"):
        nm = {"user": BOT, "status": new}
        if new == "administrator":
            nm.update(can_be_edited=False, is_anonymous=False, can_manage_chat=True, can_delete_messages=True,
                      can_manage_video_chats=False, can_restrict_members=False, can_promote_members=False,
                      can_change_info=False, can_invite_users=True)
        if new == "kicked":
            nm["until_date"] = 0
        await self._process(my_chat_member={"chat": {"id": chat, "type": "supergroup", "title": title},
                                            "from": self._from(by), "date": 1700000000,
                                            "old_chat_member": {"user": BOT, "status": old}, "new_chat_member": nm})

    # -------------------------------------------------------------- reading what the bot sent
    def sent(self, chat, since=0):
        return [(e, d) for e, d in self.tg.calls[since:] if e in ("sendMessage", "editMessageText")
                and d.get("chat_id") == chat]

    def texts(self, chat, since=0):
        return [d.get("text", "") for _, d in self.sent(chat, since)]

    def last(self, chat):
        t = self.texts(chat)
        return t[-1] if t else None

    def mark(self):
        return len(self.tg.calls)

    def buttons(self, chat, since=0):
        out = []
        for _, d in self.sent(chat, since):
            rm = d.get("reply_markup")
            if rm:
                out += [(b.text, b.callback_data, b.url) for row in rm.inline_keyboard for b in row]
        return out

    def find_button(self, chat, since, needle):
        return next((cb for text, cb, url in self.buttons(chat, since) if cb and needle in (cb + text)), None)

    def all_callbacks(self):
        bad = []
        for _, d in self.tg.calls:
            rm = d.get("reply_markup")
            if rm:
                for row in rm.inline_keyboard:
                    for b in row:
                        if b.callback_data and len(b.callback_data.encode()) > 64:
                            bad.append(b.callback_data)
                        if not b.callback_data and not b.url:
                            bad.append("EMPTY")
        return bad

    # -------------------------------------------------------------- shortcuts for building a company
    def company(self, name):
        with db.platform_session("test") as s:
            c = models.Company(name=name)
            s.add(c)
            s.flush()
            return c.id

    def member(self, tg_id, name, role, company_id):
        from sqlalchemy import select
        from helpbot.services import access
        from conftest import tg_user
        self.names[tg_id] = name
        with db.platform_session("test") as s:
            u = access.upsert_user(s, tg_user(tg_id, name))
            u.status = "active"
            u.preferred_language = "en"
            u.active_company_id = company_id
            s.flush()
            r = s.scalar(select(models.Role).where(models.Role.name == role))
            s.add(models.CompanyUser(company_id=company_id, user_id=u.id, role_id=r.id))
            return u.id


async def _send_file(self, user, kind, chat=None, mime="application/pdf", size=1000, group=None):
    chat = chat or user
    m = {"message_id": next(self.tg.mid), "date": 1700000000, "from": self._from(user),
         "chat": {"id": chat, "type": "private" if chat > 0 else "supergroup", "title": "g"}}
    fid = f"FILE{next(self.uid)}"
    if kind == "photo":
        m["photo"] = [{"file_id": fid, "file_unique_id": "u" + fid, "width": 10, "height": 10, "file_size": size}]
    else:
        m["document"] = {"file_id": fid, "file_unique_id": "u" + fid, "file_name": "doc.pdf", "mime_type": mime,
                         "file_size": size}
    if group:
        m["media_group_id"] = group
    await self._process(message=m)
    return fid


def _alerts(self, since=0):
    return [d.get("text", "") for e, d in self.tg.calls[since:] if e == "answerCallbackQuery" and d.get("show_alert")]


Bot.send_file = _send_file
Bot.alerts = _alerts
