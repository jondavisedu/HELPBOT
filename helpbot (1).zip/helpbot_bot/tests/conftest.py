import os
import sys
import types

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("OWNER_TELEGRAM_ID", "1")
os.environ.setdefault("BOT_TOKEN", "1:x")
os.environ["STRICT_I18N"] = "1"
os.environ["DEFAULT_LANGUAGE"] = "en"
os.environ["AUTO_MIGRATE"] = "false"
os.environ.setdefault("SECRET_KEY", "test-secret-key-for-2fa")

from helpbot import config, db, models, rbac               # noqa: E402
from helpbot.services import access                         # noqa: E402

_tg = iter(range(1000, 10_000))


def tg_user(tg_id, name="User", username=None):
    return types.SimpleNamespace(id=tg_id, first_name=name, last_name=None, username=username, language_code="en")


def fresh_db():
    """Empty schema. In-memory SQLite by default; set TEST_DATABASE_URL to run the same tests on PostgreSQL."""
    url = os.environ.get("TEST_DATABASE_URL")
    db.init_engine(url or "sqlite://")
    if url:
        models.Base.metadata.drop_all(db.engine())
    models.Base.metadata.create_all(db.engine())


@pytest.fixture()
def env():
    """Fresh database, seeded roles/permissions and an Owner."""
    fresh_db()
    with db.platform_session("test seed") as s:
        rbac.seed_rbac(s)
        from helpbot.services import billing
        billing.seed_plans(s)
        access.ensure_owners(s)
    return Env()


class Env:
    def user(self, name, role=None, company=None, status="active", tg_id=None, extra_roles=()):
        """Create an approved user (optionally a member of `company` with `role`)."""
        tg_id = tg_id or next(_tg)
        with db.platform_session("test user") as s:
            u = access.upsert_user(s, tg_user(tg_id, name))
            u.status = status
            s.flush()
            from helpbot.models import CompanyUser, Role
            from sqlalchemy import select
            for r in ([role] if role else []) + list(extra_roles):
                role_row = s.scalar(select(Role).where(Role.name == r))
                s.add(CompanyUser(company_id=company, user_id=u.id, role_id=role_row.id))
            if company and not u.active_company_id:
                u.active_company_id = company
            return u.id

    def company(self, name):
        with db.platform_session("test company") as s:
            c = models.Company(name=name)
            s.add(c)
            s.flush()
            return c.id

    def ctx(self, user_id, company_id=None):
        with db.platform_session("test ctx") as s:
            u = s.get(models.User, user_id)
            return rbac.build_ctx(s, u, company_id)

    def owner_ctx(self, company_id=None):
        with db.platform_session("test owner ctx") as s:
            from sqlalchemy import select
            u = s.scalar(select(models.User).where(models.User.platform_role == "owner"))
            return rbac.build_ctx(s, u, company_id)

    def scope(self, ctx):
        return db.session_scope(ctx.company_id if ctx.company_id else db.NOSCOPE)
