"""Developer tool: run the whole suite (and the Alembic migration) on a real, throw-away PostgreSQL.
    pip install pgserver && python tests/run_on_postgres.py"""
import os
import sys
import tempfile

import pgserver
import pytest

os.environ.setdefault("BOT_TOKEN", "1:x")           # must be set before helpbot.config is imported
os.environ.setdefault("OWNER_TELEGRAM_ID", "1")
os.environ["STRICT_I18N"] = "1"
os.environ["DEFAULT_LANGUAGE"] = "en"
os.environ["AUTO_MIGRATE"] = "false"
os.environ.setdefault("SECRET_KEY", "test-secret-key-for-2fa")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path[:0] = [ROOT, os.path.join(ROOT, "tests")]

server = pgserver.get_server(tempfile.mkdtemp())
url = server.get_uri().replace("postgresql://", "postgresql+psycopg://", 1)
os.environ["TEST_DATABASE_URL"] = url
os.environ["DATABASE_URL"] = url

# 1) the migration must create exactly the schema of the models on PostgreSQL too
from alembic.autogenerate import compare_metadata
from alembic.migration import MigrationContext
from sqlalchemy import create_engine

from helpbot import migrate, models

migrate.upgrade("head")
with create_engine(url).connect() as conn:
    drift = compare_metadata(MigrationContext.configure(conn), models.Base.metadata)
print("PostgreSQL migration drift:", drift)
assert drift == [], drift

# 1b) backup -> disaster -> restore round trip with the real pg_dump / pg_restore
import glob
import pgserver as _pg
from sqlalchemy import text

_bin = os.path.join(os.path.dirname(_pg.__file__), "pginstall", "bin")
os.environ["PATH"] = _bin + os.pathsep + os.environ["PATH"]
os.environ["BACKUP_DIR"] = tempfile.mkdtemp()
from helpbot import ops

ops.BACKUP_DIR = os.environ["BACKUP_DIR"]
eng = create_engine(url)
with eng.begin() as c:
    c.execute(text("INSERT INTO companies (id, name, status, created_at, updated_at) VALUES "
                   "(gen_random_uuid(), 'BackupCo', 'active', now(), now())"))
dump = ops.backup()
with eng.begin() as c:
    c.execute(text("DELETE FROM companies"))
ops.restore(dump, confirmed=True)
with eng.connect() as c:
    names = [r[0] for r in c.execute(text("SELECT name FROM companies"))]
print("PostgreSQL backup/restore round trip:", names)
assert names == ["BackupCo"], names
with eng.begin() as c:
    c.execute(text("DELETE FROM companies"))

# 2) the whole test suite on PostgreSQL
sys.exit(pytest.main(["-q", "-x", "-p", "no:cacheprovider", os.path.join(ROOT, "tests")] + sys.argv[1:]))
