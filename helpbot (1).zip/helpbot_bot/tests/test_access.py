"""Registration is decided by the Owner only; permissions are deny-by-default."""
import pytest
from sqlalchemy import select

from conftest import tg_user
from helpbot import db, models
from helpbot.rbac import PermissionDenied, role_permission_codes
from helpbot.services import access
from helpbot.services.errors import ServiceError


def test_new_user_is_pending_and_has_no_access(env):
    c = env.company("A")
    with db.platform_session("t") as s:
        u = access.upsert_user(s, tg_user(555, "Newbie"))
        uid = u.id
        assert u.status == "pending"
    ctx = env.ctx(uid, c)
    assert not ctx.can("tickets.view") and not ctx.can("overview.view")
    assert ctx.company_id is None


def test_only_the_owner_can_approve(env):
    c = env.company("A")
    admin = env.user("Admin", "company_admin", c)
    with db.platform_session("t") as s:
        u = access.upsert_user(s, tg_user(556, "Newbie"))
        req, _ = access.request_access(s, u, "Acme", "hi")
        rid = req.id
    with pytest.raises(PermissionDenied):
        with db.platform_session("t") as s:
            access.decide_registration(env.ctx(admin, c), s, rid, True)     # even a Company Admin cannot
    with db.platform_session("t") as s:
        access.decide_registration(env.owner_ctx(), s, rid, True)
        assert s.scalar(select(models.User).where(models.User.telegram_user_id == 556)).status == "active"


def test_rejected_user_stays_without_access(env):
    with db.platform_session("t") as s:
        u = access.upsert_user(s, tg_user(557, "X"))
        req, _ = access.request_access(s, u)
        access.decide_registration(env.owner_ctx(), s, req.id, False)
        assert u.status == "rejected"
        uid = u.id
    assert not env.ctx(uid, None).can("tickets.view")


def test_registration_is_rate_limited_and_deduplicated(env):
    with db.platform_session("t") as s:
        u = access.upsert_user(s, tg_user(558, "X"))
        r1, created1 = access.request_access(s, u)
        r2, created2 = access.request_access(s, u)
        assert created1 and not created2 and r1.id == r2.id
        access.decide_registration(env.owner_ctx(), s, r1.id, False)
        with pytest.raises(ServiceError):                                   # cooldown after a decision
            access.request_access(s, u)


def test_owner_account_comes_only_from_env(env):
    with db.platform_session("t") as s:
        owner = access.get_user_by_tg(s, 1)
        assert owner.platform_role == "owner"
        other = access.upsert_user(s, tg_user(777, "Impostor"))
        assert other.platform_role is None and other.status == "pending"


def test_company_creation_needs_owner_granted_permission(env):
    c = env.company("A")
    admin = env.user("Admin", "company_admin", c)
    with pytest.raises(PermissionDenied):
        with db.platform_session("t") as s:
            access.create_company(env.ctx(admin, c), s, "Sneaky Co")
    with db.platform_session("t") as s:
        access.grant_permission(env.owner_ctx(), s, admin, "company.create")
    with db.platform_session("t") as s:
        co = access.create_company(env.ctx(admin, c), s, "Granted Co")
        assert co.name == "Granted Co"
    ctx = env.ctx(admin, co.id)                                              # creator administers the new company
    assert "company_admin" in ctx.roles


def test_only_owner_grants_permissions(env):
    c = env.company("A")
    admin = env.user("Admin", "company_admin", c)
    other = env.user("Other", "dispatcher", c)
    with pytest.raises(PermissionDenied):
        with db.platform_session("t") as s:
            access.grant_permission(env.ctx(admin, c), s, other, "telegram.link_group", c)


def test_company_admin_cannot_assign_admin_or_platform_roles_nor_outside_company(env):
    a, b = env.company("A"), env.company("B")
    admin = env.user("Admin", "company_admin", a)
    newbie = env.user("Newbie")
    for role in ("company_admin", "owner", "super_admin"):
        with pytest.raises(Exception):
            with db.platform_session("t") as s:
                access.assign_role(env.ctx(admin, a), s, newbie, role)
    with pytest.raises(PermissionDenied):
        with db.platform_session("t") as s:
            access.assign_role(env.ctx(admin, a), s, newbie, "dispatcher", b)   # other company
    with db.platform_session("t") as s:
        access.assign_role(env.ctx(admin, a), s, newbie, "dispatcher")          # allowed
    assert "dispatcher" in env.ctx(newbie, a).roles


def test_inactive_user_cannot_be_assigned(env):
    c = env.company("A")
    pending = env.user("P", status="pending")
    with pytest.raises(ServiceError):
        with db.platform_session("t") as s:
            access.assign_role(env.owner_ctx(), s, pending, "dispatcher", c)


def test_expired_grant_gives_nothing(env):
    from datetime import datetime, timedelta, timezone
    c = env.company("A")
    u = env.user("U", "viewer", c)
    with db.platform_session("t") as s:
        access.grant_permission(env.owner_ctx(), s, u, "company.create",
                                expires_at=datetime.now(timezone.utc) - timedelta(days=1))
    assert not env.ctx(u, c).can("company.create")


def test_role_matrix_follows_blueprint(env):
    assert "tickets.view" in role_permission_codes("driver") and "drivers.view" not in role_permission_codes("driver")
    assert role_permission_codes("viewer") == {"overview.view"}
    assert "audit.view" not in role_permission_codes("company_admin")           # audit: owner / super_admin only
    assert not any(c.startswith("billing.") for c in role_permission_codes("manager"))
    assert role_permission_codes("super_admin") == set()                       # only explicit Owner grants
    assert "eld_service.edit" in role_permission_codes("eld_support")


def test_suspended_company_denies_everything_but_keeps_data(env):
    c = env.company("A")
    u = env.user("U", "manager", c)
    with db.platform_session("t") as s:
        s.get(models.Company, c).status = "suspended"
    ctx = env.ctx(u, c)
    assert ctx.blocked and not ctx.can("tickets.view")
    assert env.owner_ctx(c).can("tickets.view")                                 # Owner can still reach it


def test_owner_cannot_be_suspended_through_the_service(env):
    with db.platform_session("t") as s:
        owner = access.get_user_by_tg(s, 1)
        with pytest.raises(PermissionDenied):
            access.suspend_platform_user(env.owner_ctx(), s, owner.id, "oops")
