"""REST API: login (Telegram code + 2FA), sessions, CSRF, tenant isolation, permissions, headers."""
import re
from datetime import datetime, timedelta, timezone

import pyotp
import pytest
from sqlalchemy import select

from helpbot import db, models
from helpbot.api.app import create_app
from helpbot.api.ratelimit import Limiter
from helpbot.services import groups, loads, web_auth

H = {"X-Requested-With": "HELPBOT"}


class FakeSender:
    def __init__(self):
        self.sent = []

    async def send_message(self, chat_id, text, parse_mode=None, reply_markup=None, **kw):
        self.sent.append((chat_id, text))

    def code_for(self, chat_id):
        for cid, text in reversed(self.sent):
            m = re.search(r"<b>(\d{6})</b>", text)
            if cid == chat_id and m:
                return m.group(1)


@pytest.fixture()
def web(env):
    sender = FakeSender()
    return env, create_app(sender=sender, limiter=Limiter()), sender


def login(app, sender, tg_id, totp=None, expect=200):
    c = app.test_client()
    assert c.post("/api/auth/request", json={"identifier": str(tg_id)}, headers=H).status_code == 200
    r = c.post("/api/auth/verify", json={"identifier": str(tg_id), "code": sender.code_for(tg_id), "totp": totp},
               headers=H)
    assert r.status_code == expect, r.get_json()
    return c


def enable_2fa(user_id):
    with db.platform_session("t") as s:
        user = s.get(models.User, user_id)
        secret, _ = web_auth.totp_begin(s, user)
        assert web_auth.totp_confirm(s, user, pyotp.TOTP(secret).now())
    return secret


def test_login_flow_cookie_flags_logout(web):
    env, app, sender = web
    c = env.company("Acme")
    env.user("Dan", "dispatcher", c, tg_id=5001)
    cl = app.test_client()
    assert cl.post("/api/auth/request", json={"identifier": "5001"}, headers=H).get_json() == {"ok": True}
    assert any("login code" in t for _, t in sender.sent)
    r = cl.post("/api/auth/verify", json={"identifier": "5001", "code": "000000"}, headers=H)
    assert r.status_code == 401 and r.get_json()["error"] == "invalid_login"
    r = cl.post("/api/auth/verify", json={"identifier": "5001", "code": sender.code_for(5001)}, headers=H)
    assert r.status_code == 200
    cookie = r.headers["Set-Cookie"]
    assert "HttpOnly" in cookie and "SameSite=Strict" in cookie
    me = cl.get("/api/me").get_json()
    assert me["company"]["name"] == "Acme" and "tickets.view" in me["permissions"]
    assert cl.post("/api/auth/logout", json={}, headers=H).status_code == 200
    assert cl.get("/api/me").status_code == 401


def test_no_account_enumeration(web):
    env, app, sender = web
    r = app.test_client().post("/api/auth/request", json={"identifier": "99999999"}, headers=H)
    assert r.status_code == 200 and r.get_json() == {"ok": True} and sender.sent == []
    env.user("Pending", status="pending", tg_id=5002)
    r = app.test_client().post("/api/auth/request", json={"identifier": "5002"}, headers=H)
    assert r.get_json() == {"ok": True} and sender.sent == []                      # pending users get no code either


def test_code_is_single_use_and_burns_after_five_wrong_attempts(web):
    env, app, sender = web
    c = env.company("Acme")
    env.user("Dan", "dispatcher", c, tg_id=5003)
    cl = app.test_client()
    cl.post("/api/auth/request", json={"identifier": "5003"}, headers=H)
    good = sender.code_for(5003)
    for _ in range(5):
        assert cl.post("/api/auth/verify", json={"identifier": "5003", "code": "111111"}, headers=H).status_code == 401
    assert cl.post("/api/auth/verify", json={"identifier": "5003", "code": good}, headers=H).status_code == 401
    login(app, sender, 5003)                                                         # a fresh code works once
    assert app.test_client().post("/api/auth/verify", json={"identifier": "5003", "code": sender.code_for(5003)},
                                  headers=H).status_code == 401


def test_expired_code_is_rejected(web):
    env, app, sender = web
    c = env.company("Acme")
    env.user("Dan", "dispatcher", c, tg_id=5004)
    cl = app.test_client()
    cl.post("/api/auth/request", json={"identifier": "5004"}, headers=H)
    with db.platform_session("t") as s:
        s.scalar(select(models.LoginCode)).expires_at = datetime.now(timezone.utc) - timedelta(minutes=1)
    assert cl.post("/api/auth/verify", json={"identifier": "5004", "code": sender.code_for(5004)},
                   headers=H).status_code == 401


def test_rate_limits(web):
    env, app, sender = web
    c = env.company("Acme")
    env.user("Dan", "dispatcher", c, tg_id=5005)
    cl = app.test_client()
    codes = [cl.post("/api/auth/request", json={"identifier": "5005"}, headers=H).status_code for _ in range(7)]
    assert codes[:5] == [200] * 5 and codes[5:] == [429, 429]
    codes = [cl.post("/api/auth/request", json={"identifier": f"x{i}"}, headers=H).status_code for i in range(12)]
    assert 429 in codes                                                              # per-IP limit too


def test_2fa_required_for_admins_and_checked_at_login(web):
    env, app, sender = web
    c = env.company("Acme")
    admin = env.user("Ann", "company_admin", c, tg_id=5006)
    env.user("Dan", "dispatcher", c, tg_id=5007)
    login(app, sender, 5007)                                                         # dispatcher: no 2FA needed
    cl = app.test_client()

    def attempt(totp=None):
        cl.post("/api/auth/request", json={"identifier": "5006"}, headers=H)
        return cl.post("/api/auth/verify", json={"identifier": "5006", "code": sender.code_for(5006), "totp": totp},
                       headers=H)

    r = attempt()
    assert r.status_code == 403 and r.get_json()["error"] == "2fa_setup_required"
    secret = enable_2fa(admin)
    assert attempt().status_code == 401 and attempt("000000").status_code == 401
    assert attempt(pyotp.TOTP(secret).now()).status_code == 200


def test_totp_secret_is_encrypted_at_rest(web):
    env, app, sender = web
    c = env.company("Acme")
    u = env.user("Ann", "company_admin", c, tg_id=5008)
    secret = enable_2fa(u)
    with db.platform_session("t") as s:
        stored = s.get(models.User, u).totp_secret_enc
    assert secret not in stored and stored.startswith("gAAAA")


def test_csrf_origin_and_content_type(web):
    env, app, sender = web
    c = env.company("Acme")
    env.user("Dan", "dispatcher", c, tg_id=5009)
    cl = login(app, sender, 5009)
    payload = {"category": "other", "subject": "hello"}
    assert cl.post("/api/tickets", json=payload).status_code == 403                  # no CSRF header
    assert cl.post("/api/tickets", json=payload, headers={**H, "Origin": "https://evil.example"}).status_code == 403
    r = cl.post("/api/tickets", data="category=other&subject=hello", headers=H,
                content_type="application/x-www-form-urlencoded")
    assert r.status_code == 415
    assert cl.post("/api/tickets", json=payload, headers={**H, "Origin": "http://localhost"}).status_code == 201


def test_tenant_isolation_over_http(web):
    env, app, sender = web
    a, b = env.company("Alpha"), env.company("Beta")
    env.user("Alice", "dispatcher", a, tg_id=5010)
    env.user("Bob", "dispatcher", b, tg_id=5011)
    ca, cb = login(app, sender, 5010), login(app, sender, 5011)
    assert ca.post("/api/tickets", json={"category": "dispatch", "subject": "Alpha secret"},
                   headers=H).status_code == 201
    assert cb.get("/api/tickets").get_json() == []
    assert cb.get("/api/tickets/1").status_code == 404
    assert cb.post("/api/tickets/1/status", json={"status": "in_progress"}, headers=H).status_code == 404
    assert cb.post("/api/company/switch", json={"company_id": a.hex}, headers=H).status_code == 403
    assert cb.get("/api/tickets/1").status_code == 404
    assert "Alpha" not in str(cb.get("/api/me").get_json())


def test_permissions_over_http(web):
    env, app, sender = web
    c = env.company("Acme")
    for tg, name, role in ((5020, "Vic", "viewer"), (5021, "Dan", "dispatcher"), (5022, "Dave", "driver")):
        env.user(name, role, c, tg_id=tg)
    viewer, disp, drv = login(app, sender, 5020), login(app, sender, 5021), login(app, sender, 5022)
    assert viewer.get("/api/tickets").status_code == 403 and viewer.get("/api/overview").status_code == 200
    assert disp.get("/api/audit").status_code == 403 and disp.get("/api/approvals").status_code == 403
    assert disp.get("/api/members").status_code == 403
    disp.post("/api/tickets", json={"category": "dispatch", "subject": "Dispatcher ticket"}, headers=H)
    drv.post("/api/tickets", json={"category": "other", "subject": "Driver ticket"}, headers=H)
    assert [t["subject"] for t in drv.get("/api/tickets").get_json()] == ["Driver ticket"]
    assert drv.post("/api/tickets/2/status", json={"status": "done"}, headers=H).status_code == 403
    with db.platform_session("t") as s:                                              # denials are audited
        assert s.scalar(select(models.AuditLog.id).where(models.AuditLog.action == "permission_denied"))


def test_rate_field_only_for_accounting_and_group_notification_is_sent(web):
    env, app, sender = web
    c = env.company("Acme")
    env.user("Dan", "dispatcher", c, tg_id=5030)
    env.user("Ann", "accountant", c, tg_id=5031)
    mgr = env.user("Mia", "manager", c, tg_id=5032)
    owner = env.owner_ctx(c)
    with env.scope(owner) as s:
        groups.link_group(owner, s, -100777, "Ops", "operations")
    mctx = env.ctx(mgr, c)
    with env.scope(mctx) as s:
        loads.create_load(mctx, s, "L-1", "A", "B", rate_cents=123456)
    disp, acc = login(app, sender, 5030), login(app, sender, 5031)
    assert "rate_cents" not in disp.get("/api/loads").get_json()[0]
    assert acc.get("/api/loads").get_json()[0]["rate_cents"] == 123456
    before = len(sender.sent)
    disp.post("/api/tickets", json={"category": "other", "subject": "Needs a group post"}, headers=H)
    assert any(cid == -100777 and "Needs a group post" in t for cid, t in sender.sent[before:])


def test_session_expiry_and_server_side_logout_all(web):
    env, app, sender = web
    c = env.company("Acme")
    u = env.user("Dan", "dispatcher", c, tg_id=5040)
    cl = login(app, sender, 5040)
    assert cl.get("/api/me").status_code == 200
    with db.platform_session("t") as s:
        s.scalar(select(models.WebSession)).expires_at = datetime.now(timezone.utc) - timedelta(minutes=1)
    assert cl.get("/api/me").status_code == 401
    cl = login(app, sender, 5040)
    with db.platform_session("t") as s:
        web_auth.destroy_all_sessions(s, u)
    assert cl.get("/api/me").status_code == 401


def test_suspended_user_loses_the_session(web):
    env, app, sender = web
    c = env.company("Acme")
    u = env.user("Dan", "dispatcher", c, tg_id=5041)
    cl = login(app, sender, 5041)
    with db.platform_session("t") as s:
        s.get(models.User, u).status = "suspended"
    assert cl.get("/api/me").status_code == 401


def test_headers_static_health_and_no_error_leak(web, monkeypatch):
    env, app, sender = web
    c = env.company("Acme")
    env.user("Dan", "dispatcher", c, tg_id=5050)
    cl = app.test_client()
    r = cl.get("/")
    assert r.status_code == 200 and b"HELPBOT" in r.data
    csp = r.headers["Content-Security-Policy"]
    assert "script-src 'self'" in csp and "unsafe-inline" not in csp
    assert r.headers["X-Frame-Options"] == "DENY" and r.headers["X-Content-Type-Options"] == "nosniff"
    assert cl.get("/static/app.js").status_code == 200 and cl.get("/static/../web.py").status_code == 404
    assert cl.get("/healthz").get_json()["ok"] and cl.get("/readyz").get_json()["ok"]
    assert cl.get("/api/tickets").status_code == 401
    logged = login(app, sender, 5050)

    def boom(*a, **k):
        raise RuntimeError("secret internals: password=hunter2")

    monkeypatch.setattr("helpbot.services.tickets.list_tickets", boom)
    r = logged.get("/api/tickets")
    assert r.status_code == 500 and "hunter2" not in r.get_data(as_text=True)


def test_owner_needs_2fa_then_can_switch_company_and_read_audit(web):
    env, app, sender = web
    c = env.company("Acme")
    with db.platform_session("t") as s:
        owner_id = s.scalar(select(models.User.id).where(models.User.platform_role == "owner"))
    cl = app.test_client()

    def attempt(totp=None):
        cl.post("/api/auth/request", json={"identifier": "1"}, headers=H)
        return cl.post("/api/auth/verify", json={"identifier": "1", "code": sender.code_for(1), "totp": totp},
                       headers=H)

    r = attempt()
    assert r.status_code == 403 and r.get_json()["error"] == "2fa_setup_required"
    secret = enable_2fa(owner_id)
    r = attempt(pyotp.TOTP(secret).now())
    assert r.status_code == 200 and r.get_json()["permissions"] == ["*"]
    assert cl.get("/api/tickets").status_code == 409                                  # no active company yet
    assert cl.post("/api/company/switch", json={"company_id": c.hex}, headers=H).status_code == 200
    assert cl.get("/api/tickets").status_code == 200 and cl.get("/api/audit").status_code == 200


def test_billing_and_ai_endpoints(web):
    env, app, sender = web
    c = env.company("Acme")
    env.user("Mia", "manager", c, tg_id=5060)
    env.user("Dan", "dispatcher", c, tg_id=5061)
    admin = env.user("Ann", "company_admin", c, tg_id=5062)
    mgr, disp = login(app, sender, 5060), login(app, sender, 5061)
    assert mgr.get("/api/billing").status_code == 403                                  # managers: no billing
    assert disp.get("/api/ai/proposals").status_code == 403
    assert mgr.get("/api/ai/proposals").get_json() == {"enabled": False, "proposals": []}
    disp.post("/api/tickets", json={"category": "dispatch", "subject": "Truck accident near Denver"}, headers=H)
    with env.scope(env.ctx(env.user("Tmp", "manager", c), c)) as s:
        pass
    # switch AI on through the service (the Telegram command does the same), then use the API
    from helpbot.services import ai
    mctx = env.ctx(db_user(env, 5060), c)
    with env.scope(mctx) as s:
        ai.set_enabled(mctx, s, True)
    assert mgr.post("/api/ai/run", json={}, headers=H).status_code == 200
    props = mgr.get("/api/ai/proposals").get_json()["proposals"]
    prio = next(p for p in props if p["agent"] == "ticket_triage")
    assert mgr.get("/api/tickets/1").get_json()["priority"] == "normal"                # nothing applied yet
    assert disp.post(f"/api/ai/proposals/{prio['id']}/apply", json={}, headers=H).status_code == 403
    assert mgr.post(f"/api/ai/proposals/{prio['id']}/apply", json={}, headers=H).status_code == 200
    assert mgr.get("/api/tickets/1").get_json()["priority"] == "urgent"
    assert mgr.post(f"/api/ai/proposals/{prio['id']}/apply", json={}, headers=H).status_code == 400   # only once
    secret = enable_2fa(admin)
    cl = app.test_client()
    cl.post("/api/auth/request", json={"identifier": "5062"}, headers=H)
    r = cl.post("/api/auth/verify", json={"identifier": "5062", "code": sender.code_for(5062),
                                          "totp": pyotp.TOTP(secret).now()}, headers=H)
    assert r.status_code == 200
    b = cl.get("/api/billing").get_json()
    assert b["plan"] == "Starter" and b["usage"]["users"] == 4 and b["limits"]["drivers"] == 5 and b["readonly"] is False


def db_user(env, tg_id):
    with db.platform_session("t") as s:
        return s.scalar(select(models.User.id).where(models.User.telegram_user_id == tg_id))
