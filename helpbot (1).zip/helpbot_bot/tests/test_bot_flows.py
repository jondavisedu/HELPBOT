"""End-to-end Telegram flows against the real handlers (fake Telegram network)."""
import logging

import pytest
from sqlalchemy import select

from botharness import OWNER, Bot
from helpbot import db, models

GROUP, GROUP2 = -1001000001, -1001000002


@pytest.fixture()
def bot(caplog):
    caplog.set_level(logging.ERROR)
    b = Bot()
    yield b
    errors = [r.getMessage() for r in caplog.records if r.levelno >= logging.ERROR]
    assert not errors, errors                               # no handler crashed (i18n is strict in tests)
    assert b.all_callbacks() == []                          # every button fits Telegram's 64-byte limit


@pytest.mark.asyncio
async def test_registration_owner_approval_and_role_assignment(bot):
    cid = bot.company("Acme Logistics")
    # a stranger writes to the bot
    await bot.say(2001, "/start")
    assert "Choose your language" in bot.last(2001) or "Tilni tanlang" in bot.last(2001)
    await bot.click(2001, "lang:uz")
    m = bot.mark()
    assert any("Owner" in t for t in bot.texts(2001))                                   # "ask the Owner" prompt
    await bot.click(2001, "ra:go")
    await bot.say(2001, "Acme Logistics — dispatcher, please")
    assert "Owner" in bot.last(2001)
    # the Owner got the request with Approve / Reject buttons
    approve = bot.find_button(OWNER, 0, "rr:")
    assert approve and approve.endswith(":ok") or bot.find_button(OWNER, 0, ":ok")
    ok = [cb for _, cb, _ in bot.buttons(OWNER) if cb and cb.startswith("rr:") and cb.endswith(":ok")][0]
    # an unapproved user cannot do anything yet
    m = bot.mark(); await bot.say(2001, "/tickets")
    assert "Owner" in bot.last(2001) or "tasdiq" in bot.last(2001).lower()
    # a non-owner cannot press the Owner's buttons
    bot.names[3001] = "Mallory"
    await bot.say(3001, "/start"); await bot.click(3001, "lang:en")
    m = bot.mark(); await bot.click(3001, ok)
    with db.platform_session("t") as s:
        assert s.scalar(select(models.User).where(models.User.telegram_user_id == 2001)).status == "pending"
    # the Owner approves, then picks the company and the role
    m = bot.mark(); await bot.click(OWNER, ok)
    co_btn = bot.find_button(OWNER, m, "ac:")
    assert co_btn
    m = bot.mark(); await bot.click(OWNER, co_btn)
    role_btn = [cb for _, cb, _ in bot.buttons(OWNER, m) if cb.startswith("ar:") and cb.endswith(":2")][0]   # dispatcher
    m = bot.mark(); await bot.click(OWNER, role_btn)
    with db.platform_session("t") as s:
        u = s.scalar(select(models.User).where(models.User.telegram_user_id == 2001))
        assert u.status == "active"
        roles = s.scalars(select(models.Role.name).join(models.CompanyUser, models.CompanyUser.role_id == models.Role.id)
                          .where(models.CompanyUser.user_id == u.id)).all()
        assert roles == ["dispatcher"]
    assert any("dispatcher" in t.lower() or "Dispatcher" in t for t in bot.texts(2001))   # user was told (in Uzbek)
    await bot.say(2001, "/menu")
    assert any("Menyu" in t for t in bot.texts(2001))                                      # Uzbek UI


@pytest.mark.asyncio
async def test_group_linking_and_strangers_are_ignored(bot):
    cid = bot.company("Acme")
    bot.member(2002, "Dana", "company_admin", cid)
    bot.member(2003, "Dispatch Dan", "dispatcher", cid)
    # a stranger in an unlinked group gets no answer at all
    m = bot.mark(); await bot.say(9999, "/tickets", chat=GROUP)
    assert bot.sent(GROUP, m) == []
    # a company admin WITHOUT the explicit grant cannot link
    m = bot.mark(); await bot.say(2002, "/linkgroup Acme dispatch", chat=GROUP)
    assert "permission" in bot.last(GROUP)
    with db.platform_session("t") as s:
        assert s.scalar(select(models.TelegramGroup)) is None
    # the Owner links it
    await bot.say(OWNER, "/linkgroup Acme dispatch", chat=GROUP)
    assert "linked" in bot.last(GROUP)
    with db.platform_session("t") as s:
        g = s.scalar(select(models.TelegramGroup))
        assert g.company_id == cid and g.group_type == "dispatch"
    # a member can use group commands; a non-member cannot
    m = bot.mark(); await bot.say(2003, "/tickets", chat=GROUP)
    assert bot.sent(GROUP, m)
    m = bot.mark(); await bot.say(9999, "/tickets", chat=GROUP)
    assert bot.sent(GROUP, m) == []
    # another company cannot take the group over
    cid2 = bot.company("Beta")
    bot.member(2004, "Beta Boss", "company_admin", cid2)
    m = bot.mark(); await bot.say(2004, "/linkgroup Beta", chat=GROUP)
    assert bot.sent(GROUP, m) == [] or "permission" in bot.last(GROUP)
    with db.platform_session("t") as s:
        assert s.scalar(select(models.TelegramGroup)).company_id == cid


@pytest.mark.asyncio
async def test_ticket_flow_group_post_and_confidentiality(bot):
    cid = bot.company("Acme")
    bot.member(2010, "Driver Dave", "driver", cid)
    bot.member(2011, "Dispatch Dan", "dispatcher", cid)
    bot.member(2012, "Hanna HR", "hr", cid)
    await bot.say(OWNER, "/linkgroup Acme dispatch", chat=GROUP)
    await bot.say(OWNER, "/linkgroup Acme hr", chat=GROUP2)
    # driver creates a dispatch ticket in a private chat
    await bot.say(2010, "/ticket")
    await bot.click(2010, "nt:dispatch")
    await bot.click(2010, "np:high")
    await bot.say(2010, "Load 1234 is late")
    m = bot.mark(); await bot.click(2010, "nd:skip")
    assert "#1" in bot.last(2010)
    post = [t for t in bot.texts(GROUP, m)]
    assert post and "Load 1234 is late" in post[0]
    # status button used from the group by the dispatcher
    m = bot.mark(); await bot.click(2011, "tk:1:in_progress", chat=GROUP)
    assert any("In progress" in t for t in bot.texts(GROUP, m))
    assert any("In progress" in t for t in bot.texts(2010, m))                  # the creator is told
    # a driver cannot move the status
    m = bot.mark(); await bot.click(2010, "tk:1:done")
    assert "permission" in bot.last(2010)
    # confidential HR ticket: the group never shows the content
    await bot.say(2010, "/ticket"); await bot.click(2010, "nt:hr"); await bot.click(2010, "np:normal")
    await bot.say(2010, "My salary was wrong"); m = bot.mark(); await bot.click(2010, "nd:skip")
    hr_posts = " ".join(bot.texts(GROUP2, m))
    assert "Confidential" in hr_posts and "salary" not in hr_posts
    # the dispatcher cannot open it, HR can
    m = bot.mark(); await bot.say(2011, "/ticket 2")
    assert "not found" in bot.last(2011).lower()
    m = bot.mark(); await bot.say(2012, "/ticket 2")
    assert "salary" in bot.last(2012)
    # the driver sees only own tickets
    m = bot.mark(); await bot.say(2010, "/tickets")
    assert "#1" in bot.last(2010) and "#2" in bot.last(2010)
    m = bot.mark(); await bot.say(2011, "/tickets")
    assert "#1" in bot.last(2011) and "#2" not in bot.last(2011)


@pytest.mark.asyncio
async def test_internal_notes_and_replies(bot):
    cid = bot.company("Acme")
    bot.member(2020, "Client Cathy", "client", cid)
    bot.member(2021, "Dispatch Dan", "dispatcher", cid)
    await bot.say(2020, "/ticket"); await bot.click(2020, "nt:other"); await bot.click(2020, "np:low")
    await bot.say(2020, "Question about invoice"); await bot.click(2020, "nd:skip")
    await bot.click(2021, "tk:1:note"); await bot.say(2021, "internal: check with boss")
    await bot.click(2021, "tk:1:reply"); await bot.say(2021, "We are on it")
    m = bot.mark(); await bot.say(2020, "/ticket 1")
    view = bot.last(2020)
    assert "We are on it" in view and "internal" not in view
    m = bot.mark(); await bot.click(2020, "tk:1:note")                               # a client cannot add notes
    assert "permission" in bot.last(2020)
    assert any("New reply" in t for t in bot.texts(2020))                            # and was notified of the reply


@pytest.mark.asyncio
async def test_driver_termination_needs_a_second_person(bot):
    cid = bot.company("Acme")
    mgr = bot.member(2030, "Manager Mia", "manager", cid)
    bot.member(2031, "Admin Ann", "company_admin", cid)
    await bot.say(2030, "/adddriver Ali Valiyev +998901234567")
    assert "added" in bot.last(2030)
    await bot.say(2030, "/drivers")
    dv = [cb for _, cb, _ in bot.buttons(2030) if cb.startswith("dv:")][0]
    await bot.click(2030, dv)
    idx = [cb for _, cb, _ in bot.buttons(2030) if cb.startswith("ds:") and cb.endswith(":3")][0]      # terminated
    await bot.click(2030, idx)
    await bot.say(2030, "")                                                         # empty text is ignored
    m = bot.mark(); await bot.say(2030, "no-show for a week")
    assert "approval" in bot.last(2030)
    with db.platform_session("t") as s:
        assert s.scalar(select(models.Driver)).status == "onboarding"                 # nothing happened yet
    ap = [cb for _, cb, _ in bot.buttons(2031) if cb.startswith("ap:") and cb.endswith(":y")][0]    # Ann was notified
    m = bot.mark(); await bot.click(2030, ap)                                       # requester tries to approve
    assert "own request" in bot.last(2030)
    m = bot.mark(); await bot.click(2031, ap)
    assert "Approved" in bot.last(2031)
    with db.platform_session("t") as s:
        assert s.scalar(select(models.Driver)).status == "terminated"


@pytest.mark.asyncio
async def test_denied_commands_are_audited_and_menu_hides_forbidden_items(bot):
    cid = bot.company("Acme")
    bot.member(2040, "Dispatch Dan", "dispatcher", cid)
    for cmd in ("/users", "/audit", "/requests", "/grant 1 company.create", "/approvals", "/suspendcompany x"):
        m = bot.mark(); await bot.say(2040, cmd)
        assert "permission" in (bot.last(2040) or ""), cmd
    with db.platform_session("t") as s:
        n = s.scalar(select(models.AuditLog.id).where(models.AuditLog.action == "permission_denied"))
        assert n is not None
    await bot.say(2040, "/menu")
    labels = " ".join(t for t, _, _ in bot.buttons(2040))
    assert "Tickets" in labels and "Approvals" not in labels
    await bot.say(2040, "/help")
    assert "/users" not in bot.last(2040) and "/tickets" in bot.last(2040)


@pytest.mark.asyncio
async def test_company_isolation_through_telegram(bot):
    a, b = bot.company("Alpha"), bot.company("Beta")
    bot.member(2050, "Alice", "dispatcher", a)
    bot.member(2051, "Bob", "dispatcher", b)
    await bot.say(2050, "/ticket"); await bot.click(2050, "nt:dispatch"); await bot.click(2050, "np:normal")
    await bot.say(2050, "Alpha secret load"); await bot.click(2050, "nd:skip")
    m = bot.mark(); await bot.say(2051, "/tickets")
    assert "Alpha" not in bot.last(2051) and "#1" not in bot.last(2051)
    m = bot.mark(); await bot.click(2051, "tk:1:view")                               # same number exists in Alpha only
    assert "not found" in bot.last(2051).lower()
    m = bot.mark(); await bot.click(2051, "tk:1:done")
    with db.platform_session("t") as s:
        assert s.scalar(select(models.Ticket)).status == "open"


@pytest.mark.asyncio
async def test_updadmin_roster_grants_nothing(bot):
    cid = bot.company("Acme")
    bot.member(2060, "Dispatch Dan", "dispatcher", cid)
    await bot.say(OWNER, "/linkgroup Acme", chat=GROUP)
    bot.tg.admins[GROUP] = [(7001, "Stranger Sam", "creator"), (2060, "Dispatch Dan", "administrator")]
    m = bot.mark(); await bot.say(2060, "/updadmin", chat=GROUP)
    assert "permission" in bot.last(GROUP)                                           # needs the explicit grant
    await bot.say(OWNER, "/updadmin", chat=GROUP)
    assert "2 admins, 1 registered" in bot.last(GROUP)
    with db.platform_session("t") as s:
        assert s.scalar(select(models.User).where(models.User.telegram_user_id == 7001)) is None   # nobody was created
        assert len(s.scalars(select(models.TelegramGroupAdmin)).all()) == 2


@pytest.mark.asyncio
async def test_bot_added_and_removed_notifications(bot):
    m = bot.mark(); await bot.member_update(GROUP, 5555, "left", "member", "Random chat")
    assert any("not linked" in t for t in bot.texts(OWNER, m))
    await bot.say(OWNER, "/linkgroup Nonexistent", chat=GROUP)
    cid = bot.company("Acme")
    await bot.say(OWNER, "/linkgroup Acme", chat=GROUP)
    m = bot.mark(); await bot.member_update(GROUP, 5555, "member", "kicked", "Random chat")
    assert any("removed" in t for t in bot.texts(OWNER, m))
    with db.platform_session("t") as s:
        assert s.scalar(select(models.TelegramGroup)).is_active is False


@pytest.mark.asyncio
async def test_language_switch_changes_ui(bot):
    cid = bot.company("Acme")
    bot.member(2070, "Rustam", "dispatcher", cid)
    await bot.click(2070, "lang:ru")
    await bot.say(2070, "/menu")
    assert any("Меню" in t for t in bot.texts(2070))
    await bot.click(2070, "lang:uz")
    await bot.say(2070, "/menu")
    assert any("Menyu" in t for t in bot.texts(2070))


@pytest.mark.asyncio
async def test_suspended_company_blocks_members_not_owner(bot):
    cid = bot.company("Acme")
    bot.member(2080, "Dispatch Dan", "dispatcher", cid)
    with db.platform_session("t") as s:
        s.get(models.Company, cid).status = "suspended"
    m = bot.mark(); await bot.say(2080, "/tickets")
    assert "suspended" in bot.last(2080)


@pytest.mark.asyncio
async def test_group_ticket_command_moves_to_private_chat_with_deep_link(bot):
    cid = bot.company("Acme")
    bot.member(2090, "Driver Dave", "driver", cid)
    await bot.say(OWNER, "/linkgroup Acme", chat=GROUP)
    m = bot.mark(); await bot.say(2090, "/ticket", chat=GROUP)
    urls = [u for _, _, u in bot.buttons(GROUP, m) if u]
    assert urls and urls[0].startswith("https://t.me/HELPBOTbot?start=tk_")
    payload = urls[0].split("start=")[1]
    await bot.say(2090, f"/start {payload}")                                  # opens the guided flow in private
    assert any("category" in t.lower() for t in bot.texts(2090))
