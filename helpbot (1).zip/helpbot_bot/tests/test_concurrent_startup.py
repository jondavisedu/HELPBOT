"""Regression: gunicorn workers / web + bot starting at the same moment on an EMPTY database must not collide."""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_three_processes_start_at_once_on_an_empty_database(tmp_path):
    pg = os.environ.get("TEST_DATABASE_URL")
    if pg:                                                   # make the PostgreSQL schema really empty
        from sqlalchemy import create_engine, text
        from helpbot import models
        eng = create_engine(pg)
        models.Base.metadata.drop_all(eng)
        with eng.begin() as c:
            c.execute(text("DROP TABLE IF EXISTS alembic_version"))
    url = pg or f"sqlite:///{tmp_path}/race.db"
    env = {**os.environ, "DATABASE_URL": url, "AUTO_MIGRATE": "true", "PYTHONPATH": ROOT, "BOT_TOKEN": "1:x"}
    code = "from helpbot import bootstrap; bootstrap.prepare(); print('ready')"
    procs = [subprocess.Popen([sys.executable, "-c", code], cwd=ROOT, env=env, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, text=True) for _ in range(3)]
    results = [p.communicate(timeout=120) + (p.returncode,) for p in procs]
    for out, err, rc in results:
        assert rc == 0, err[-800:]
        assert "ready" in out
