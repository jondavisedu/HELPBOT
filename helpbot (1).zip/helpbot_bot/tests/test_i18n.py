import os
import re

from helpbot.i18n import S

SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "helpbot")


def test_all_languages_have_the_same_keys_and_placeholders():
    en, uz, ru = S["en"], S["uz"], S["ru"]
    assert set(en) == set(uz) == set(ru)
    ph = lambda s: sorted(re.findall(r"\{(\w+)\}", s))
    assert [k for k in en if not (ph(en[k]) == ph(uz[k]) == ph(ru[k]))] == []


def test_every_translation_key_used_in_code_exists():
    used = set()
    for root, _, files in os.walk(SRC):
        for f in files:
            if f.endswith(".py") and f not in ("i18n.py",):
                text = open(os.path.join(root, f), encoding="utf-8").read()
                used |= set(re.findall(r'\bt\([^,()]+,\s*"([a-z_]+\.[a-z_]+)"', text))
                used |= set(re.findall(r'"((?:btn|err|tk|reg|drv|trk|appr|group|user|company|start)\.[a-z_]+)"', text))
    permission_codes = {"company.create", "company.switch"}          # look like keys but are permission codes
    missing = sorted(k for k in used if k not in S["en"] and k not in permission_codes)
    assert missing == [], missing
