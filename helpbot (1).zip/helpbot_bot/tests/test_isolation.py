"""Blueprint acceptance: Company A can never see or touch Company B data."""
import uuid

import pytest

from helpbot import db, models
from helpbot.db import AuditImmutable, TenantViolation
from helpbot.rbac import PermissionDenied
from helpbot.services import fleet, tickets
from sqlalchemy import select


@pytest.fixture()
def two(env):
    a, b = env.company("Company A"), env.company("Company B")
    ua = env.user("Alice", "company_admin", a)
    ub = env.user("Bob", "company_admin", b)
    return env, a, b, ua, ub


def test_tickets_are_invisible_across_companies(two):
    env, a, b, ua, ub = two
    ca, cb = env.ctx(ua, a), env.ctx(ub, b)
    with env.scope(ca) as s:
        tickets.create_ticket(ca, s, "dispatch", "Late load A")
    with env.scope(cb) as s:
        assert tickets.list_tickets(cb, s) == []
        with pytest.raises(Exception):
            tickets.get_ticket(cb, s, 1)           # same number exists only in A


def test_ticket_numbers_are_per_company(two):
    env, a, b, ua, ub = two
    ca, cb = env.ctx(ua, a), env.ctx(ub, b)
    with env.scope(ca) as s:
        assert tickets.create_ticket(ca, s, "other", "first A").ticket_number == 1
    with env.scope(cb) as s:
        assert tickets.create_ticket(cb, s, "other", "first B").ticket_number == 1


def test_raw_query_in_company_scope_never_returns_other_company(two):
    env, a, b, ua, ub = two
    ca, cb = env.ctx(ua, a), env.ctx(ub, b)
    with env.scope(cb) as s:
        fleet.add_driver(cb, s, "Driver of B")
    with env.scope(ca) as s:
        assert s.scalars(select(models.Driver)).all() == []            # no WHERE needed: the guard filters
        assert s.scalar(select(models.Driver).where(models.Driver.company_id == b)) is None


def test_no_scope_is_deny_by_default(two):
    env, a, b, ua, ub = two
    cb = env.ctx(ub, b)
    with env.scope(cb) as s:
        fleet.add_driver(cb, s, "Driver of B")
    with db.session_scope(db.NOSCOPE) as s:
        assert s.scalars(select(models.Driver)).all() == []


def test_write_into_another_company_is_blocked(two):
    env, a, b, ua, ub = two
    ca = env.ctx(ua, a)
    with pytest.raises(TenantViolation):
        with env.scope(ca) as s:
            s.add(models.Driver(company_id=b, full_name="Sneaky"))


def test_cannot_modify_other_company_row_even_with_its_id(two):
    env, a, b, ua, ub = two
    ca, cb = env.ctx(ua, a), env.ctx(ub, b)
    with env.scope(cb) as s:
        d = fleet.add_driver(cb, s, "Driver of B")
        did = d.id
    with env.scope(ca) as s:
        with pytest.raises(Exception):
            fleet.change_driver_status(ca, s, did, "active", "hacking")   # NotFound: invisible to A


def test_truck_unit_unique_per_company_not_global(two):
    env, a, b, ua, ub = two
    ca, cb = env.ctx(ua, a), env.ctx(ub, b)
    with env.scope(ca) as s:
        fleet.add_truck(ca, s, "T100", vin="VIN1")
    with env.scope(cb) as s:
        fleet.add_truck(cb, s, "T100", vin="VIN1")          # same unit/VIN in another company is fine
    with env.scope(ca) as s:
        with pytest.raises(Exception):
            fleet.add_truck(ca, s, "t100")                  # duplicate inside the same company


def test_user_cannot_get_context_for_a_company_they_do_not_belong_to(two):
    env, a, b, ua, ub = two
    c = env.ctx(ua, b)                                     # Alice asks for Company B
    assert c.company_id is None and not c.can("tickets.view")


def test_member_of_both_companies_is_scoped_per_session(env):
    a, b = env.company("A"), env.company("B")
    u = env.user("Multi", "manager", a)
    with db.platform_session("t") as s:
        from helpbot.services import access
        access.assign_role(env.owner_ctx(), s, u, "manager", b)
    ca, cb = env.ctx(u, a), env.ctx(u, b)
    with env.scope(ca) as s:
        tickets.create_ticket(ca, s, "other", "only in A")
    with env.scope(cb) as s:
        assert tickets.list_tickets(cb, s) == []


def test_audit_log_is_append_only(two):
    env, a, b, ua, ub = two
    ca = env.ctx(ua, a)
    with env.scope(ca) as s:
        tickets.create_ticket(ca, s, "other", "audit me")
    with pytest.raises(AuditImmutable):
        with db.platform_session("t") as s:
            row = s.scalar(select(models.AuditLog))
            row.action = "tampered"
    with pytest.raises(AuditImmutable):
        with db.platform_session("t") as s:
            s.delete(s.scalar(select(models.AuditLog)))
    with db.platform_session("t") as s:
        assert s.scalar(select(models.AuditLog).where(models.AuditLog.action == "tampered")) is None
