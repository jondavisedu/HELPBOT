import os
import subprocess
import sys

from alembic.autogenerate import compare_metadata
from alembic.migration import MigrationContext
from sqlalchemy import create_engine

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_migrations_build_the_same_schema_as_the_models(tmp_path):
    url = f"sqlite:///{tmp_path}/m.db"
    env = {**os.environ, "DATABASE_URL": url, "PYTHONPATH": ROOT}
    out = subprocess.run([sys.executable, "manage.py", "migrate"], cwd=ROOT, env=env, capture_output=True, text=True)
    assert out.returncode == 0, out.stderr
    from helpbot import models
    with create_engine(url).connect() as conn:
        assert compare_metadata(MigrationContext.configure(conn), models.Base.metadata) == []
