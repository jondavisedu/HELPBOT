import pytest
from sqlalchemy import select

from helpbot import config, db, models
from helpbot.rbac import GroupPost, Notify, PermissionDenied
from helpbot.services import approvals, fleet, groups, tickets
from helpbot.services.errors import NotFound, ServiceError


@pytest.fixture()
def co(env):
    c = env.company("Acme")
    ids = {r: env.user(r.title(), r, c) for r in ("company_admin", "manager", "dispatcher", "eld_support", "hr",
                                                   "accountant", "driver", "client", "viewer")}
    other_client = env.user("Client2", "client", c)
    return env, c, ids, other_client


# ------------------------------------------------------------------ tickets
def test_client_and_driver_see_only_their_own_tickets(co):
    env, c, ids, client2 = co
    cc, cd, c2 = env.ctx(ids["client"], c), env.ctx(ids["driver"], c), env.ctx(client2, c)
    with env.scope(cc) as s:
        t = tickets.create_ticket(cc, s, "other", "Client ticket")
        n = t.ticket_number
    with env.scope(c2) as s:
        assert tickets.list_tickets(c2, s) == []
        with pytest.raises(NotFound):
            tickets.get_ticket(c2, s, n)
    with env.scope(cd) as s:
        assert tickets.list_tickets(cd, s) == []                     # a driver does not see a client's ticket


def test_internal_notes_are_hidden_from_clients(co):
    env, c, ids, _ = co
    cc, cdisp = env.ctx(ids["client"], c), env.ctx(ids["dispatcher"], c)
    with env.scope(cc) as s:
        n = tickets.create_ticket(cc, s, "dispatch", "Where is my load").ticket_number
    with env.scope(cdisp) as s:
        tickets.add_message(cdisp, s, n, "secret internal note", internal=True)
        tickets.add_message(cdisp, s, n, "visible reply")
    with env.scope(cc) as s:
        t = tickets.get_ticket(cc, s, n)
        bodies = [m.body for m, _ in tickets.messages(cc, s, t)]
        assert bodies == ["visible reply"]
        with pytest.raises(PermissionDenied):
            tickets.add_message(cc, s, n, "client trying a note", internal=True)


def test_confidential_categories_are_limited_to_their_department(co):
    env, c, ids, _ = co
    cdriver, chr_, cdisp, cmgr = (env.ctx(ids[r], c) for r in ("driver", "hr", "dispatcher", "manager"))
    with env.scope(cdriver) as s:
        n = tickets.create_ticket(cdriver, s, "hr", "My pay question").ticket_number
    with env.scope(chr_) as s:
        assert tickets.get_ticket(chr_, s, n)
    with env.scope(cmgr) as s:
        assert tickets.get_ticket(cmgr, s, n)
    with env.scope(cdisp) as s:                                      # dispatcher has no HR access
        with pytest.raises(NotFound):
            tickets.get_ticket(cdisp, s, n)
        assert tickets.list_tickets(cdisp, s) == []


def test_group_post_for_confidential_ticket_has_no_content(co):
    env, c, ids, _ = co
    cd = env.ctx(ids["driver"], c)
    with env.scope(cd) as s:
        tickets.create_ticket(cd, s, "accounting", "Settlement dispute")
        tickets.create_ticket(cd, s, "dispatch", "Late load")
    posts = [p for p in cd.outbox if isinstance(p, GroupPost)]
    assert posts[0].key == "tk.group_new_conf" and posts[1].key == "tk.group_new"


def test_status_flow_and_reopen_needs_reason(co):
    env, c, ids, _ = co
    cdisp = env.ctx(ids["dispatcher"], c)
    with env.scope(cdisp) as s:
        n = tickets.create_ticket(cdisp, s, "dispatch", "Flow").ticket_number
        tickets.change_status(cdisp, s, n, "in_progress")
        tickets.change_status(cdisp, s, n, "waiting")
        tickets.change_status(cdisp, s, n, "done")
        with pytest.raises(ServiceError):
            tickets.change_status(cdisp, s, n, "waiting")            # invalid transition
        with pytest.raises(ServiceError):
            tickets.change_status(cdisp, s, n, "open")               # reopen without reason
        assert tickets.change_status(cdisp, s, n, "open", "customer called again").status == "open"


def test_driver_cannot_change_status_or_assign(co):
    env, c, ids, _ = co
    cd = env.ctx(ids["driver"], c)
    with env.scope(cd) as s:
        n = tickets.create_ticket(cd, s, "other", "mine").ticket_number
        with pytest.raises(PermissionDenied):
            tickets.change_status(cd, s, n, "done")
        with pytest.raises(PermissionDenied):
            tickets.assign(cd, s, n, ids["driver"])


def test_viewer_cannot_create_or_read_tickets(co):
    env, c, ids, _ = co
    cv = env.ctx(ids["viewer"], c)
    with env.scope(cv) as s:
        with pytest.raises(PermissionDenied):
            tickets.create_ticket(cv, s, "other", "nope")
        with pytest.raises(PermissionDenied):
            tickets.list_tickets(cv, s)


def test_assignee_must_belong_to_the_company(co):
    env, c, ids, _ = co
    outsider = env.user("Outsider", "dispatcher", env.company("Other Co"))
    cm = env.ctx(ids["manager"], c)
    with env.scope(cm) as s:
        n = tickets.create_ticket(cm, s, "dispatch", "assign me").ticket_number
        with pytest.raises(ServiceError):
            tickets.assign(cm, s, n, outsider)
        assert tickets.assign(cm, s, n, ids["dispatcher"]).assigned_to == ids["dispatcher"]


def test_reminders_are_idempotent(co):
    env, c, ids, _ = co
    cm = env.ctx(ids["manager"], c)
    with env.scope(cm) as s:
        tickets.create_ticket(cm, s, "dispatch", "unassigned")
    with db.platform_session("t") as s:
        assert tickets.due_reminders(s, minutes=0) != []
    with db.platform_session("t") as s:
        assert tickets.due_reminders(s, minutes=60) == []            # just stamped


# ------------------------------------------------------------------ fleet + approvals
def test_terminate_driver_requires_approval_and_no_self_approval(co):
    env, c, ids, _ = co
    cm, cadmin = env.ctx(ids["manager"], c), env.ctx(ids["company_admin"], c)
    with env.scope(cm) as s:
        d = fleet.add_driver(cm, s, "Ali Valiyev")
        did = d.id
        fleet.change_driver_status(cm, s, did, "active", "hired")
        _, ap = fleet.change_driver_status(cm, s, did, "terminated", "no-show")
        assert ap is not None and s.get(models.Driver, did).status == "active"      # nothing happened yet
        apid = ap.id
    with pytest.raises(ServiceError):
        with env.scope(cm) as s:
            approvals.decide(cm, s, apid, True)                                     # requester cannot approve
    with env.scope(cadmin) as s:
        approvals.decide(cadmin, s, apid, True)
        assert s.get(models.Driver, did).status == "terminated"
    with env.scope(cadmin) as s:
        hist = [h.to_status for h in fleet.status_history(cadmin, s, did)]
        assert "terminated" in hist


def test_dispatcher_cannot_decide_approvals_and_rejection_changes_nothing(co):
    env, c, ids, _ = co
    cm, cdisp, cadmin = (env.ctx(ids[r], c) for r in ("manager", "dispatcher", "company_admin"))
    with env.scope(cm) as s:
        d = fleet.add_driver(cm, s, "Bek")
        _, ap = fleet.change_driver_status(cm, s, d.id, "terminated", "x")
        apid, did = ap.id, d.id
    with pytest.raises(PermissionDenied):
        with env.scope(cdisp) as s:
            approvals.decide(cdisp, s, apid, True)
    with env.scope(cadmin) as s:
        approvals.decide(cadmin, s, apid, False)
        assert s.get(models.Driver, did).status == "onboarding"
        with pytest.raises(ServiceError):
            approvals.decide(cadmin, s, apid, True)                                 # already decided


def test_approval_of_another_company_is_invisible(co):
    env, c, ids, _ = co
    b = env.company("Beta")
    badmin = env.user("BAdmin", "company_admin", b)
    cm = env.ctx(ids["manager"], c)
    with env.scope(cm) as s:
        d = fleet.add_driver(cm, s, "Bek")
        _, ap = fleet.change_driver_status(cm, s, d.id, "terminated", "x")
        apid = ap.id
    cb = env.ctx(badmin, b)
    with pytest.raises(NotFound):
        with env.scope(cb) as s:
            approvals.decide(cb, s, apid, True)


def test_truck_reassignment_is_critical_first_assignment_is_direct(co):
    env, c, ids, _ = co
    cm, cadmin = env.ctx(ids["manager"], c), env.ctx(ids["company_admin"], c)
    with env.scope(cm) as s:
        d1, d2 = fleet.add_driver(cm, s, "One"), fleet.add_driver(cm, s, "Two")
        for d in (d1, d2):
            fleet.change_driver_status(cm, s, d.id, "active", "hired")
        t1 = fleet.add_truck(cm, s, "T1")
        a, ap = fleet.assign_truck(cm, s, d1.id, t1.id, "first")
        assert a is not None and ap is None                                         # direct
        a2, ap2 = fleet.assign_truck(cm, s, d2.id, t1.id, "swap")
        assert a2 is None and ap2 is not None                                       # truck busy -> approval
        ids_ = (d1.id, d2.id, t1.id, ap2.id)
    with env.scope(cadmin) as s:
        approvals.decide(cadmin, s, ids_[3], True)
        cur = fleet.current_assignment(cadmin, s, ids_[1])
        assert cur and cur[1].id == ids_[2]
        assert fleet.current_assignment(cadmin, s, ids_[0]) is None                 # old assignment ended, kept as history
        n = s.scalar(select(__import__("sqlalchemy").func.count(models.DriverAssignment.id)))
        assert n == 2


def test_status_change_requires_reason(co):
    env, c, ids, _ = co
    cm = env.ctx(ids["manager"], c)
    with env.scope(cm) as s:
        d = fleet.add_driver(cm, s, "NoReason")
        with pytest.raises(ServiceError):
            fleet.change_driver_status(cm, s, d.id, "active", "  ")


def test_driver_sees_only_own_profile(co):
    env, c, ids, _ = co
    cm, cd = env.ctx(ids["manager"], c), env.ctx(ids["driver"], c)
    with env.scope(cm) as s:
        mine = fleet.add_driver(cm, s, "Driver Himself")
        fleet.add_driver(cm, s, "Somebody Else")
        fleet.link_driver_user(cm, s, mine.id, ids["driver"])
    with env.scope(cd) as s:
        with pytest.raises(PermissionDenied):
            fleet.list_drivers(cd, s)                                               # no drivers.view
        d, truck = fleet.my_status(cd, s)
        assert d.full_name == "Driver Himself" and truck is None


def test_user_suspend_and_company_suspend_flow(co):
    env, c, ids, _ = co
    cadmin = env.ctx(ids["company_admin"], c)
    with env.scope(cadmin) as s:
        ap = approvals.request_user_suspend(cadmin, s, ids["dispatcher"], "policy breach")
        apid = ap.id
    owner = env.owner_ctx(c)
    with env.scope(owner) as s:
        approvals.decide(owner, s, apid, True)
    assert not env.ctx(ids["dispatcher"], c).can("tickets.view")                    # membership suspended
    # company suspend: owner is the only eligible approver; self-approval is off by default
    with env.scope(owner) as s:
        ap = approvals.request_company_suspend(owner, s, "unpaid")
        apid = ap.id
    with pytest.raises(ServiceError):
        with env.scope(owner) as s:
            approvals.decide(owner, s, apid, True)


def test_owner_self_approval_switch(co, monkeypatch):
    env, c, ids, _ = co
    monkeypatch.setattr(config, "ALLOW_OWNER_SELF_APPROVAL", True)
    owner = env.owner_ctx(c)
    with env.scope(owner) as s:
        apid = approvals.request_company_suspend(owner, s, "test").id
    with env.scope(owner) as s:
        approvals.decide(owner, s, apid, True)
        assert s.get(models.Company, c).status == "suspended"


def test_stale_approvals_expire(co):
    from datetime import datetime, timedelta, timezone
    env, c, ids, _ = co
    cm = env.ctx(ids["manager"], c)
    with env.scope(cm) as s:
        d = fleet.add_driver(cm, s, "Old")
        _, ap = fleet.change_driver_status(cm, s, d.id, "terminated", "x")
        ap.created_at = datetime.now(timezone.utc) - timedelta(days=30)
        apid = ap.id
    with db.platform_session("t") as s:
        assert approvals.expire_stale(s) == 1
    with db.platform_session("t") as s:
        assert s.get(models.Approval, apid).status == "expired"


# ------------------------------------------------------------------ telegram groups
def test_group_belongs_to_one_company_only(co):
    env, c, ids, _ = co
    b = env.company("Beta")
    owner_a, owner_b = env.owner_ctx(c), env.owner_ctx(b)
    admin_b = env.user("BA", "company_admin", b)
    with db.platform_session("t") as s:
        from helpbot.services import access
        access.grant_permission(env.owner_ctx(), s, admin_b, "telegram.link_group", b)
    with env.scope(owner_a) as s:
        groups.link_group(owner_a, s, -100111, "Acme ops")
    assert groups.resolve_group(-100111)[0] == c
    cb = env.ctx(admin_b, b)
    with pytest.raises(ServiceError):                                                # B cannot steal A's group
        with env.scope(cb) as s:
            groups.link_group(cb, s, -100111, "stolen")
    assert groups.resolve_group(-100111)[0] == c
    with env.scope(owner_b) as s:                                                    # only the Owner moves it
        groups.link_group(owner_b, s, -100111, "moved")
    assert groups.resolve_group(-100111)[0] == b


def test_linking_needs_explicit_permission_not_a_command_name(co):
    env, c, ids, _ = co
    cadmin = env.ctx(ids["company_admin"], c)
    with pytest.raises(PermissionDenied):
        with env.scope(cadmin) as s:
            groups.link_group(cadmin, s, -100222, "x")


def test_updadmin_only_updates_roster_and_grants_nothing(co):
    env, c, ids, _ = co
    owner = env.owner_ctx(c)
    with env.scope(owner) as s:
        groups.link_group(owner, s, -100333, "Acme ops")
    stranger_tg = 424242
    with db.platform_session("t") as s:
        from conftest import tg_user
        from helpbot.services import access
        access.upsert_user(s, tg_user(stranger_tg, "Stranger"))                      # pending account
    with env.scope(owner) as s:
        total, known = groups.update_admins(owner, s, -100333, [(stranger_tg, "Stranger", False),
                                                                 (999001, "Unregistered", True)])
        assert (total, known) == (2, 0)                                              # nobody becomes a member/admin
    with db.platform_session("t") as s:
        st = s.scalar(select(models.User).where(models.User.telegram_user_id == stranger_tg))
        assert st.status == "pending"
        assert s.scalar(select(models.CompanyUser).where(models.CompanyUser.user_id == st.id)) is None
    cadmin = env.ctx(ids["company_admin"], c)
    with pytest.raises(PermissionDenied):
        with env.scope(cadmin) as s:
            groups.update_admins(cadmin, s, -100333, [])                             # needs explicit grant


def test_updadmin_refuses_a_group_of_another_company(co):
    env, c, ids, _ = co
    b = env.company("Beta")
    with env.scope(env.owner_ctx(b)) as s:
        groups.link_group(env.owner_ctx(b), s, -100444, "Beta ops")
    owner_a = env.owner_ctx(c)
    with pytest.raises(ServiceError):
        with env.scope(owner_a) as s:
            groups.update_admins(owner_a, s, -100444, [(1, "x", False)])


def test_unknown_or_removed_group_resolves_to_nothing(co):
    env, c, ids, _ = co
    assert groups.resolve_group(-1) is None
    owner = env.owner_ctx(c)
    with env.scope(owner) as s:
        groups.link_group(owner, s, -100555, "x")
    assert groups.deactivate_if_linked(-100555, "removed") == c
    assert groups.resolve_group(-100555) is None
