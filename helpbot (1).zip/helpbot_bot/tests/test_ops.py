import os
import sqlite3
import subprocess
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def manage(*args, env):
    return subprocess.run([sys.executable, "manage.py", *args], cwd=ROOT, env=env, capture_output=True, text=True)


def test_backup_verify_and_restore_round_trip(tmp_path):
    db_file = tmp_path / "live.db"
    env = {**os.environ, "DATABASE_URL": f"sqlite:///{db_file}", "BACKUP_DIR": str(tmp_path / "bk"), "PYTHONPATH": ROOT}
    assert manage("migrate", env=env).returncode == 0
    con = sqlite3.connect(db_file)
    con.execute("INSERT INTO companies (id, name, status, created_at, updated_at) VALUES "
                "('a'*1, 'Acme', 'active', '2026-01-01', '2026-01-01')".replace("'a'*1", "'11111111111111111111111111111111'"))
    con.commit(); con.close()
    out = manage("backup", env=env)
    assert out.returncode == 0, out.stderr
    backup_file = out.stdout.strip().split(": ")[1]
    assert manage("verify", backup_file, env=env).returncode == 0
    con = sqlite3.connect(db_file); con.execute("DELETE FROM companies"); con.commit(); con.close()   # disaster
    refused = manage("restore", backup_file, env=env)
    assert refused.returncode != 0                                             # needs an explicit --yes
    assert manage("restore", backup_file, "--yes", env=env).returncode == 0
    con = sqlite3.connect(db_file)
    assert con.execute("SELECT name FROM companies").fetchall() == [("Acme",)]
    con.close()
    assert os.path.exists(str(db_file) + ".before-restore")                    # a safety copy was kept


def test_a_corrupt_backup_is_rejected(tmp_path):
    bad = tmp_path / "helpbot-bad.db"
    bad.write_bytes(b"not a database")
    env = {**os.environ, "DATABASE_URL": f"sqlite:///{tmp_path}/x.db", "PYTHONPATH": ROOT}
    assert manage("verify", str(bad), env=env).returncode != 0
