import logging

import pytest
from sqlalchemy import select

from botharness import OWNER, Bot
from helpbot import db, models

OPS, MAINT, ACC, ELD = -1001000011, -1001000012, -1001000013, -1001000014


@pytest.fixture()
def bot(caplog):
    caplog.set_level(logging.ERROR)
    b = Bot()
    yield b
    assert not [r.getMessage() for r in caplog.records if r.levelno >= logging.ERROR]
    assert b.all_callbacks() == []


def driver_row(company_id, user_tg, name):
    with db.platform_session("t") as s:
        u = s.scalar(select(models.User).where(models.User.telegram_user_id == user_tg))
        d = models.Driver(company_id=company_id, user_id=u.id, full_name=name, status="active")
        s.add(d)
        s.flush()
        return d.id


async def link_groups(bot):
    for chat, gtype in ((OPS, "operations"), (MAINT, "maintenance"), (ACC, "accounting"), (ELD, "eld")):
        await bot.say(OWNER, f"/linkgroup Acme {gtype}", chat=chat)


@pytest.mark.asyncio
async def test_load_lifecycle_through_telegram(bot):
    cid = bot.company("Acme")
    bot.member(3001, "Dispatch Dan", "dispatcher", cid)
    bot.member(3002, "Driver Dave", "driver", cid)
    bot.member(3003, "Accountant Amy", "accountant", cid)
    driver_row(cid, 3002, "Driver Dave")
    await link_groups(bot)
    await bot.say(3001, "/newload")
    await bot.say(3001, "L-5001"); await bot.say(3001, "Dallas TX"); await bot.say(3001, "Atlanta GA")
    await bot.click(3001, "lb:skip")
    assert "L-5001" in bot.last(3001) and "Rate: —" in bot.last(3001)             # dispatcher never sees money
    await bot.click(3001, "lg:L-5001")
    pick = [cb for _, cb, _ in bot.buttons(3001) if cb.startswith("la:L-5001:")][0]
    m = bot.mark(); await bot.click(3001, pick)
    assert any("New load" in t for t in bot.texts(3002, m))
    await bot.say(3002, "/loads")
    assert any("L-5001" in cb for _, cb, _ in bot.buttons(3002))
    await bot.click(3002, "ls:L-5001:1")                                             # picked_up
    await bot.click(3002, "ls:L-5001:2")                                             # delivered
    assert any("POD is needed" in t for t in bot.texts(OPS))
    await bot.click(3001, "ls:L-5001:3")                                             # POD status without a file
    assert "POD" in bot.last(3001)
    await bot.click(3001, "lf:L-5001:POD")
    await bot.send_file(3001, "photo")
    assert "saved" in bot.last(3001)
    m = bot.mark(); await bot.click(3001, "ls:L-5001:3")
    assert any("POD received" in t for t in bot.texts(ACC, m))                       # accounting group is told
    await bot.click(3003, "ls:L-5001:4")
    assert "Invoiced" in bot.last(3003)
    m = bot.mark(); await bot.send_file(3002, "photo")                               # a file with no flow started
    assert bot.sent(3002, m) == []
    await bot.click(3001, "lf:L-5001:BOL")
    await bot.send_file(3001, "document", mime="application/zip")
    assert "Only photos and PDF" in bot.last(3001)


@pytest.mark.asyncio
async def test_pti_flow_with_photos_and_review(bot):
    cid = bot.company("Acme")
    bot.member(3010, "Mechanic Max", "maintenance", cid)
    bot.member(3011, "Driver Dave", "driver", cid)
    bot.member(3012, "Driver Dina", "driver", cid)
    driver_row(cid, 3011, "Driver Dave"); driver_row(cid, 3012, "Driver Dina")
    await link_groups(bot)
    await bot.say(3010, "/pti")
    m = bot.mark(); await bot.click(3010, "pq:all")
    assert "2 driver" in bot.last(3010)
    start = [cb for _, cb, _ in bot.buttons(3011, m) if cb.startswith("pt:go:")][0]
    await bot.click(3011, start)
    m = bot.mark()
    await bot.send_file(3011, "photo", group="album1"); await bot.send_file(3011, "photo", group="album1")
    assert len([t for t in bot.texts(3011, m) if "Saved" in t]) == 1                # one reply for the whole album
    await bot.click(3011, "pt:done")
    assert "submitted" in bot.last(3011)
    posts = [t for t in bot.texts(MAINT) if "PTI submitted" in t]
    assert posts and "Driver Dave" in posts[-1] and "2 file" in posts[-1]
    approve = [cb for _, cb, _ in bot.buttons(MAINT) if cb.startswith("pr:") and cb.endswith(":ok")][-1]
    bot.member(3013, "Dispatch Dan", "dispatcher", cid)
    m = bot.mark(); await bot.click(3013, approve, chat=MAINT)
    assert any("permission" in a for a in bot.alerts(m))                              # popup: not allowed
    m = bot.mark(); await bot.click(3010, approve, chat=MAINT)
    assert any("approved" in t for t in bot.texts(3011, m))
    await bot.say(3010, "/ptistatus")
    assert "✅ 1" in bot.last(3010) and "Driver Dina" in bot.last(3010)
    m = bot.mark(); await bot.click(3012, f"pt:go:{start.split(':')[2]}")             # Dina tries Dave's request
    assert not any("Send your PTI photos" in t for t in bot.texts(3012, m))


@pytest.mark.asyncio
async def test_eld_report_by_driver(bot):
    cid = bot.company("Acme")
    bot.member(3020, "Driver Dave", "driver", cid)
    bot.member(3021, "ELD Eli", "eld_support", cid)
    driver_row(cid, 3020, "Driver Dave")
    await link_groups(bot)
    await bot.say(3020, "/eld")
    m = bot.mark(); await bot.say(3020, "Device shows fault 33 since this morning")
    assert "ELD problem reported" in bot.last(3020) and "ticket #1" in bot.last(3020)
    assert any("ELD malfunction" in t for t in bot.texts(ELD, m))
    await bot.say(3021, "/eldopen")
    res = [cb for _, cb, _ in bot.buttons(3021) if cb.startswith("er:")][0]
    await bot.click(3021, res)
    assert "resolved" in bot.last(3021)
    await bot.say(3021, "/eldopen")
    assert "No open ELD" in bot.last(3021)
    await bot.say(3021, "/ticket 1")
    assert "ELD malfunction" in bot.last(3021)


@pytest.mark.asyncio
async def test_billing_plan_and_read_only_mode_through_telegram(bot):
    cid = bot.company("Acme")
    bot.member(3030, "Admin Ann", "company_admin", cid)
    bot.member(3031, "Manager Mia", "manager", cid)
    await bot.say(3030, "/billing")
    assert "Starter" in bot.last(3030) and "Drivers 0/5" in bot.last(3030)
    await bot.say(3031, "/billing")
    assert "permission" in bot.last(3031)                                            # managers do not see billing
    await bot.say(3030, "/plan growth")
    assert "permission" in bot.last(3030) or "not allowed" in bot.last(3030).lower()   # only the Owner sets plans
    await bot.say(OWNER, "/menu")
    with db.platform_session("t") as s:
        owner = s.scalar(select(models.User).where(models.User.platform_role == "owner"))
        owner.active_company_id = cid
    await bot.say(OWNER, "/plan growth 30")
    assert "Growth" in bot.last(OWNER) and "0/25" in bot.last(OWNER)
    with db.platform_session("t") as s:
        sub = s.scalar(select(models.Subscription))
        sub.status = "past_due"
    await bot.say(3031, "/adddriver Late Payer")
    assert "permission" in bot.last(3031)                                             # read-only: nothing can be created
    await bot.say(3031, "/drivers")
    assert "No drivers" in bot.last(3031) or bot.buttons(3031) == []                  # reading still works


@pytest.mark.asyncio
async def test_ai_suggestions_are_applied_by_a_human_only(bot):
    cid = bot.company("Acme")
    bot.member(3040, "Manager Mia", "manager", cid)
    bot.member(3041, "Dispatch Dan", "dispatcher", cid)
    await bot.say(3041, "/ticket"); await bot.click(3041, "nt:dispatch"); await bot.click(3041, "np:normal")
    await bot.say(3041, "Truck had an accident on the highway"); await bot.click(3041, "nd:skip")
    await bot.say(3041, "/ai")
    assert "permission" in bot.last(3041)                                             # dispatcher: no AI access
    await bot.say(3040, "/ai")
    assert "OFF" in bot.last(3040)
    await bot.say(3040, "/ai on")
    assert "ON" in bot.last(3040)
    await bot.say(3040, "/airun")
    assert "new suggestion" in bot.last(3040)
    with db.platform_session("t") as s:
        assert s.scalar(select(models.Ticket.priority)) == "normal"                    # the AI changed nothing
    await bot.say(3040, "/ai")
    apply_cb = [cb for _, cb, _ in bot.buttons(3040) if cb.startswith("aa:") and cb.endswith(":ok")]
    assert apply_cb
    prio_cb = None
    for cb in apply_cb:
        m = bot.mark(); await bot.click(3040, cb)
        with db.platform_session("t") as s:
            if s.scalar(select(models.Ticket.priority)) == "urgent":
                prio_cb = cb
                break
    assert prio_cb                                                                    # applying the priority suggestion worked
