import pytest
from sqlalchemy import func, select

from helpbot import db, models
from helpbot.rbac import GroupPost, Notify, PermissionDenied
from helpbot.services import documents, eld, fleet, loads, pti
from helpbot.services.errors import NotFound, ServiceError


@pytest.fixture()
def co(env):
    c = env.company("Acme")
    ids = {r: env.user(r.title(), r, c) for r in ("company_admin", "manager", "dispatcher", "maintenance", "eld_support",
                                                   "accountant", "driver", "hr")}
    other = env.user("Other Driver", "driver", c)
    mgr = env.ctx(ids["manager"], c)
    with env.scope(mgr) as s:
        d1, d2 = fleet.add_driver(mgr, s, "Driver One"), fleet.add_driver(mgr, s, "Driver Two")
        for d in (d1, d2):
            fleet.change_driver_status(mgr, s, d.id, "active", "hired")
        fleet.link_driver_user(mgr, s, d1.id, ids["driver"])
        fleet.link_driver_user(mgr, s, d2.id, other)
        ids["d1"], ids["d2"], ids["other"] = d1.id, d2.id, other
    return env, c, ids


def test_load_flow_pod_gate_and_money_visibility(co):
    env, c, ids = co
    disp, drv, acc = env.ctx(ids["dispatcher"], c), env.ctx(ids["driver"], c), env.ctx(ids["accountant"], c)
    with env.scope(disp) as s:
        ld = loads.create_load(disp, s, "L-100", "Dallas TX", "Atlanta GA", "ACME Broker", ids["d1"])
        assert ld.status == "assigned"
        assert any(isinstance(o, Notify) for o in disp.outbox)                         # the driver is told
        with pytest.raises(PermissionDenied):
            loads.create_load(disp, s, "L-101", rate_cents=250000)                     # money needs accounting.edit
        with pytest.raises(ServiceError):
            loads.create_load(disp, s, "bad number!")                                  # not safe for buttons
        with pytest.raises(ServiceError):
            loads.create_load(disp, s, "l-100")                                        # duplicate, case-insensitive
    with env.scope(drv) as s:                                                          # driver: own load only
        assert [x.load_number for x in loads.list_loads(drv, s)] == ["L-100"]
        loads.change_status(drv, s, "L-100", "picked_up")
        loads.change_status(drv, s, "L-100", "delivered")
        with pytest.raises(PermissionDenied):
            loads.change_status(drv, s, "L-100", "pod_received")                       # a driver cannot confirm POD
    with env.scope(disp) as s:
        with pytest.raises(ServiceError) as e:
            loads.change_status(disp, s, "L-100", "pod_received")
        assert e.value.key == "load.need_pod"                                          # no file, no status
        ld = loads.get_by_number(disp, s, "L-100")
        documents.add_document(disp, s, "POD", "load", ld.id, "file-ref-1")
        loads.change_status(disp, s, "L-100", "pod_received")
        assert any(isinstance(o, GroupPost) and o.group_type == "accounting" for o in disp.outbox)
        with pytest.raises(PermissionDenied):
            loads.change_status(disp, s, "L-100", "invoiced")                          # invoicing is accounting's job
    with env.scope(acc) as s:                                                          # accounting can see and invoice
        loads.change_status(acc, s, "L-100", "invoiced")
        assert loads.rate_visible(acc) and not loads.rate_visible(disp)


def test_driver_cannot_see_or_touch_someone_elses_load(co):
    env, c, ids = co
    disp, other = env.ctx(ids["dispatcher"], c), env.ctx(ids["other"], c)
    with env.scope(disp) as s:
        loads.create_load(disp, s, "L-200", driver_id=ids["d1"])
    with env.scope(other) as s:
        assert loads.list_loads(other, s) == []
        with pytest.raises(NotFound):
            loads.get_by_number(other, s, "L-200")
        with pytest.raises(NotFound):
            loads.change_status(other, s, "L-200", "picked_up")


def test_loads_are_isolated_between_companies(co):
    env, c, ids = co
    b = env.company("Beta")
    bd = env.user("BDisp", "dispatcher", b)
    disp, bdisp = env.ctx(ids["dispatcher"], c), env.ctx(bd, b)
    with env.scope(disp) as s:
        loads.create_load(disp, s, "L-300")
    with env.scope(bdisp) as s:
        assert loads.list_loads(bdisp, s) == []
        loads.create_load(bdisp, s, "L-300")                                           # same number is fine in Beta
        with pytest.raises(ServiceError):
            loads.assign_driver(bdisp, s, "L-300", ids["d1"])                          # Acme's driver is not available


def test_documents_ownership_and_confidential_types(co):
    env, c, ids = co
    disp, drv, other, hr = (env.ctx(ids[k], c) for k in ("dispatcher", "driver", "other", "hr"))
    with env.scope(disp) as s:
        lid = loads.create_load(disp, s, "L-400", driver_id=ids["d1"]).id
    with env.scope(drv) as s:
        documents.add_document(drv, s, "BOL", "load", lid, "ref-a")                    # own load: allowed
        with pytest.raises(PermissionDenied):
            documents.add_document(drv, s, "CDL", "driver", ids["d1"], "ref-x")        # drivers do not upload CDLs
    with env.scope(other) as s:
        with pytest.raises(PermissionDenied):
            documents.add_document(other, s, "BOL", "load", lid, "ref-b")              # not their load
        with pytest.raises(PermissionDenied):
            documents.list_documents(other, s, "load", lid)
    with env.scope(hr) as s:
        documents.add_document(hr, s, "CDL", "driver", ids["d1"], "ref-cdl")
        assert documents.list_documents(hr, s, "driver", ids["d1"])[0].confidential
    with env.scope(disp) as s:                                                          # dispatch: paperwork yes, CDL no
        assert [d.doc_type for d in documents.list_documents(disp, s, "load", lid)] == ["BOL"]
        with pytest.raises(PermissionDenied):
            documents.list_documents(disp, s, "driver", ids["d1"])


def test_pti_flow_request_submit_redo_approve(co):
    env, c, ids = co
    tech, drv, other, disp = (env.ctx(ids[k], c) for k in ("maintenance", "driver", "other", "dispatcher"))
    with pytest.raises(PermissionDenied):
        with env.scope(disp) as s:
            pti.request_pti(disp, s)                                                   # dispatch cannot request PTI
    with env.scope(tech) as s:
        reqs = pti.request_pti(tech, s)                                                # all active drivers
        assert len(reqs) == 2 and len([o for o in tech.outbox if isinstance(o, Notify)]) == 2
        r1 = next(r for r in reqs if r.driver_id == ids["d1"]).id
        assert len(pti.request_pti(tech, s)) == 2                                      # re-request reuses open ones
        assert s.scalar(select(func.count(models.PtiRequest.id))) == 2
    with env.scope(drv) as s:
        req = pti.my_open_requests(drv, s)[0]
        with pytest.raises(ServiceError):
            pti.submit(drv, s, req)                                                    # needs a photo
        pti.attach_photo(drv, s, req, "photo-1")
        pti.attach_photo(drv, s, req, "photo-2")
        assert pti.submit(drv, s, req) == 2
    with env.scope(other) as s:
        with pytest.raises(NotFound):
            pti.by_prefix(other, s, r1.hex[:8])                                       # another driver's PTI is hidden
    with env.scope(tech) as s:
        req = pti.by_prefix(tech, s, r1.hex[:8])
        pti.review(tech, s, req, False)                                                # redo: old photos retired
        assert req.status == "redo"
        assert s.scalar(select(models.Document.id).where(models.Document.is_active.is_(True),
                                                         models.Document.related_id == r1)) is None
        assert s.scalar(select(models.Document.id).where(models.Document.related_id == r1)) is not None  # but kept
    with env.scope(drv) as s:
        req = pti.my_open_requests(drv, s)[0]
        pti.attach_photo(drv, s, req, "photo-3")
        pti.submit(drv, s, req)
    with env.scope(tech) as s:
        pti.review(tech, s, pti.by_prefix(tech, s, r1.hex[:8]), True)
        sm = pti.status_summary(tech, s)
        assert sm["ok"] == 1 and len(sm["wait"]) == 1


def test_eld_malfunction_creates_ticket_clock_and_reminders(co):
    from datetime import datetime, timedelta, timezone
    env, c, ids = co
    drv, other, tech = env.ctx(ids["driver"], c), env.ctx(ids["other"], c), env.ctx(ids["eld_support"], c)
    with env.scope(drv) as s:
        m, tk = eld.report_malfunction(drv, s, ids["d1"], "Device shows fault 33 since morning")
        assert tk.category == "eld" and tk.priority == "high"
        assert (eld.deadline(m) - m.started_at.replace(tzinfo=timezone.utc)).days == 8
        types = {o.group_type for o in drv.outbox if isinstance(o, GroupPost)}
        assert {"eld", "dispatch", "safety"} <= types                                  # ELD team + fyi groups
    with env.scope(other) as s:
        with pytest.raises(PermissionDenied):
            eld.report_malfunction(other, s, ids["d1"], "Not my truck")                # only for yourself
    with env.scope(tech) as s:
        assert len(eld.list_open(tech, s)) == 1
    with db.platform_session("t") as s:
        assert eld.due_reminders(s) == []                                              # day 0: no reminder yet
        s.scalar(select(models.EldMalfunction)).started_at = datetime.now(timezone.utc) - timedelta(days=6)
    with db.platform_session("t") as s:
        assert len(eld.due_reminders(s)) == 1
    with db.platform_session("t") as s:
        assert eld.due_reminders(s) == []                                              # at most one per day
    with env.scope(tech) as s:
        mid = s.scalar(select(models.EldMalfunction.id)).hex[:8]
        eld.resolve(tech, s, eld.by_prefix(tech, s, mid))
        assert eld.list_open(tech, s) == []
