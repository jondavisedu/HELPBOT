"""Billing limits / read-only rule, and the AI manager (it only proposes; humans decide)."""
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import select

from helpbot import db, models
from helpbot.rbac import PermissionDenied
from helpbot.services import access, ai, billing, fleet, loads, tickets
from helpbot.services.errors import NotFound, ServiceError


@pytest.fixture()
def co(env):
    c = env.company("Acme")
    ids = {r: env.user(r.title(), r, c) for r in ("company_admin", "manager", "dispatcher", "driver")}
    return env, c, ids


# ------------------------------------------------------------------ billing
def test_plan_limit_blocks_the_sixth_driver_and_an_upgrade_lifts_it(co):
    env, c, ids = co
    adm = env.ctx(ids["company_admin"], c)
    with env.scope(adm) as s:
        for i in range(5):
            fleet.add_driver(adm, s, f"Driver {i}")
        with pytest.raises(ServiceError) as e:
            fleet.add_driver(adm, s, "Driver 6")
        assert e.value.key == "billing.limit" and e.value.params["limit"] == 5
    owner = env.owner_ctx(c)
    with env.scope(owner) as s:
        billing.set_plan(owner, s, c, "growth", 30)
    with env.scope(adm) as s:
        fleet.add_driver(adm, s, "Driver 6")                                          # allowed now


def test_trucks_and_users_are_limited_too_and_terminated_drivers_do_not_count(co):
    env, c, ids = co
    adm = env.ctx(ids["company_admin"], c)
    with env.scope(adm) as s:
        for i in range(5):
            fleet.add_truck(adm, s, f"T{i}")
        with pytest.raises(ServiceError):
            fleet.add_truck(adm, s, "T6")
    with db.platform_session("t") as s:                                               # 4 members exist; the 5th is fine
        extra = [access.upsert_user(s, __import__("conftest").tg_user(9000 + i, f"U{i}")) for i in range(3)]
        for u in extra:
            u.status = "active"
        s.flush()
        ids_ = [u.id for u in extra]
    owner = env.owner_ctx(c)
    with db.platform_session("t") as s:
        access.assign_role(owner, s, ids_[0], "viewer", c)                            # 5th member
    with pytest.raises(ServiceError) as e:
        with db.platform_session("t") as s:
            access.assign_role(owner, s, ids_[1], "viewer", c)                        # 6th member
    assert e.value.key == "billing.limit"
    with db.platform_session("t") as s:                                               # the same person may get a 2nd role
        access.assign_role(owner, s, ids_[0], "client", c)


def test_past_due_and_expired_trial_make_the_company_read_only(co):
    env, c, ids = co
    mgr = env.ctx(ids["manager"], c)
    assert mgr.can("tickets.create") and not mgr.readonly
    owner = env.owner_ctx(c)
    with env.scope(owner) as s:
        billing.set_status(owner, s, c, "past_due")
    mgr = env.ctx(ids["manager"], c)
    assert mgr.readonly and mgr.can("tickets.view") and not mgr.can("tickets.create") and not mgr.can("drivers.create")
    with env.scope(mgr) as s:
        assert tickets.list_tickets(mgr, s) == []                                      # reading still works
        with pytest.raises(PermissionDenied):
            tickets.create_ticket(mgr, s, "other", "blocked while read-only")
    assert env.owner_ctx(c).can("tickets.create")                                      # the Owner can still act
    with env.scope(owner) as s:
        billing.set_plan(owner, s, c, "starter", 30)                                   # paid: back to normal
    assert env.ctx(ids["manager"], c).can("tickets.create")
    with db.platform_session("t") as s:                                                # trial of a 20-day-old company
        s.get(models.Company, c).created_at = datetime.now(timezone.utc) - timedelta(days=20)
        sub = s.scalar(select(models.Subscription))
        s.delete(sub)
    assert env.ctx(ids["manager"], c).readonly


def test_only_the_owner_manages_plans_and_companies_are_billed_separately(co):
    env, c, ids = co
    b = env.company("Beta")
    adm = env.ctx(ids["company_admin"], c)
    with pytest.raises(PermissionDenied):
        with env.scope(adm) as s:
            billing.set_plan(adm, s, c, "unlimited")
    owner = env.owner_ctx(c)
    with env.scope(owner) as s:
        billing.set_status(owner, s, c, "past_due")
        with pytest.raises(NotFound):
            billing.set_plan(owner, s, c, "nonsense")
    bu = env.user("BM", "manager", b)
    assert not env.ctx(bu, b).readonly                                                 # Beta is unaffected


# ------------------------------------------------------------------ AI manager
class SpyProvider:
    name = "spy"

    def __init__(self):
        self.seen = []

    def classify_priority(self, subject):
        self.seen.append(subject)
        return "urgent" if "accident" in subject.lower() else None


def seed_tickets(env, c, ids):
    disp = env.ctx(ids["dispatcher"], c)
    with env.scope(disp) as s:
        tickets.create_ticket(disp, s, "dispatch", "Truck had an ACCIDENT on I-80")
        tickets.create_ticket(disp, s, "dispatch", "Question about the schedule")
        tickets.create_ticket(disp, s, "hr", "ACCIDENT compensation question", "very private details")
        tickets.create_ticket(disp, s, "accounting", "Settlement dispute")


def test_ai_is_off_by_default_and_needs_permission_to_switch_on(co):
    env, c, ids = co
    mgr, disp, adm = env.ctx(ids["manager"], c), env.ctx(ids["dispatcher"], c), env.ctx(ids["company_admin"], c)
    with env.scope(mgr) as s:
        with pytest.raises(ServiceError) as e:
            ai.run(mgr, s)
        assert e.value.key == "ai.disabled"
    with pytest.raises(PermissionDenied):
        with env.scope(disp) as s:
            ai.set_enabled(disp, s, True)                                              # dispatcher has no AI access
    with pytest.raises(PermissionDenied):
        with env.scope(adm) as s:
            ai.set_enabled(adm, s, True)                                               # not in the ai_agents module roles
    with env.scope(mgr) as s:
        ai.set_enabled(mgr, s, True)
        assert ai.is_enabled(s, c)


def test_agents_only_propose_never_change_anything_and_skip_confidential_tickets(co):
    env, c, ids = co
    seed_tickets(env, c, ids)
    mgr = env.ctx(ids["manager"], c)
    spy = SpyProvider()
    with env.scope(mgr) as s:
        ai.set_enabled(mgr, s, True)
        n = ai.run(mgr, s, provider=spy)
        assert n >= 2
        assert spy.seen == ["Truck had an ACCIDENT on I-80", "Question about the schedule"]     # subjects only
        assert not any("private" in x or "compensation" in x or "Settlement" in x for x in spy.seen)
        props = ai.list_proposals(mgr, s)
        assert [p.payload["ticket"] for p in props if p.kind == "priority"] == [1]
        assert all(p.status == "proposed" for p in props)
        assert s.scalar(select(models.Ticket.priority).where(models.Ticket.ticket_number == 1)) == "normal"   # untouched
        assert ai.run(mgr, s, provider=spy) == 0                                        # idempotent: no duplicates


def test_applying_uses_the_humans_permissions_and_audits_the_human(co):
    env, c, ids = co
    seed_tickets(env, c, ids)
    mgr, disp = env.ctx(ids["manager"], c), env.ctx(ids["dispatcher"], c)
    with env.scope(mgr) as s:
        ai.set_enabled(mgr, s, True)
        ai.run(mgr, s, provider=SpyProvider())
        pid = next(p.id for p in ai.list_proposals(mgr, s) if p.kind == "priority")
    with pytest.raises(PermissionDenied):
        with env.scope(disp) as s:
            ai.apply(disp, s, s.get(models.AiProposal, pid))                           # dispatcher cannot apply
    with env.scope(mgr) as s:
        ai.apply(mgr, s, s.get(models.AiProposal, pid))
        assert s.scalar(select(models.Ticket.priority).where(models.Ticket.ticket_number == 1)) == "urgent"
        with pytest.raises(ServiceError):
            ai.apply(mgr, s, s.get(models.AiProposal, pid))                            # only once
    with db.platform_session("t") as s:
        row = s.scalar(select(models.AuditLog).where(models.AuditLog.action == "ai_proposal_applied"))
        assert row.actor_user_id == ids["manager"] and row.after_data["agent"] == "ticket_triage"


def test_a_human_without_ticket_edit_cannot_use_ai_to_change_tickets(co, env=None):
    env, c, ids = co
    seed_tickets(env, c, ids)
    mgr = env.ctx(ids["manager"], c)
    with env.scope(mgr) as s:
        ai.set_enabled(mgr, s, True)
        ai.run(mgr, s, provider=SpyProvider())
        pid = next(p.id for p in ai.list_proposals(mgr, s) if p.kind == "priority")
    owner = env.owner_ctx(c)                                                            # grant approve but not tickets.edit
    viewer = env.user("Grace", "viewer", c)
    with db.platform_session("t") as s:
        access.grant_permission(owner, s, viewer, "ai_agents.approve", c)
        access.grant_permission(owner, s, viewer, "ai_agents.view", c)
    vctx = env.ctx(viewer, c)
    with pytest.raises(PermissionDenied):
        with env.scope(vctx) as s:
            ai.apply(vctx, s, s.get(models.AiProposal, pid))                            # AI cannot exceed the human


def test_dismiss_summary_and_reminders_and_company_isolation(co):
    env, c, ids = co
    seed_tickets(env, c, ids)
    mgr = env.ctx(ids["manager"], c)
    with env.scope(mgr) as s:
        ai.set_enabled(mgr, s, True)
        ai.run(mgr, s, provider=SpyProvider())
        summary = next(p for p in ai.list_proposals(mgr, s) if p.kind == "summary")
        assert summary.payload["open"] == 2                                             # confidential tickets not counted
        ai.apply(mgr, s, summary)
        assert any(o.key == "ai.group_text" for o in mgr.outbox)
        other = next(p for p in ai.list_proposals(mgr, s))
        ai.dismiss(mgr, s, other)
    b = env.company("Beta")
    bm = env.user("BM", "manager", b)
    bctx = env.ctx(bm, b)
    with env.scope(bctx) as s:
        assert ai.list_proposals(bctx, s) == []                                         # Beta sees nothing of Acme's
        assert not ai.is_enabled(s, b)
    with db.platform_session("t") as s:
        assert ai.enabled_company_ids(s) == [c]


def test_risk_watch_finds_stale_pod_eld_and_unassigned(co):
    env, c, ids = co
    disp, mgr = env.ctx(ids["dispatcher"], c), env.ctx(ids["manager"], c)
    with env.scope(disp) as s:
        loads.create_load(disp, s, "L-9")
        tickets.create_ticket(disp, s, "other", "nobody picked this up")
    with db.platform_session("t") as s:
        ld = s.scalar(select(models.Load))
        ld.status, ld.updated_at = "delivered", datetime.now(timezone.utc) - timedelta(hours=30)
        tk = s.scalar(select(models.Ticket))
        tk.created_at = datetime.now(timezone.utc) - timedelta(hours=30)
    with env.scope(mgr) as s:
        ai.set_enabled(mgr, s, True)
        ai.run(mgr, s, provider=SpyProvider())
        whats = {p.payload.get("what") for p in ai.list_proposals(mgr, s) if p.kind == "reminder"}
        assert {"pod", "ticket"} <= whats


def test_provider_failure_falls_back_to_rules(monkeypatch, co):
    env, c, ids = co
    from helpbot import config
    monkeypatch.setattr(config, "ANTHROPIC_API_KEY", "sk-test")
    import httpx

    def broken(*a, **k):
        raise httpx.ConnectError("no network")

    monkeypatch.setattr(httpx, "post", broken)
    assert isinstance(ai.get_provider(), ai.AnthropicProvider)
    assert ai.get_provider().classify_priority("Driver had an accident") == "urgent"   # rules answer instead
    monkeypatch.setattr(config, "ANTHROPIC_API_KEY", "")
    assert type(ai.get_provider()) is ai.RuleProvider                                   # default: nothing leaves the server
