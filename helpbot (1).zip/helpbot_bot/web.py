"""Web process: REST API + dashboard.   gunicorn web:app   (or: python web.py for local use)"""
import logging

from helpbot import bootstrap, config
from helpbot.api.app import create_app

logging.basicConfig(format="%(asctime)s %(levelname)s %(name)s: %(message)s", level=logging.INFO)
logging.getLogger("httpx").setLevel(logging.WARNING)
bootstrap.prepare()
app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=config.PORT)
